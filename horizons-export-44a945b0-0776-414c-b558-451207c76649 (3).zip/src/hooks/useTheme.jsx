import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const ThemeContext = createContext();

export const useTheme = () => useContext(ThemeContext);

const defaultSettings = {
  mode: 'auto', // 'light', 'dark', or 'auto'
  follow_system: true,
};

export const ThemeProvider = ({ children }) => {
  const authContext = useAuth();
  const user = authContext ? authContext.user : null;
  const [theme, setTheme] = useState('dark');
  const [settings, setSettings] = useState(defaultSettings);
  const [loading, setLoading] = useState(true);

  const applyTheme = useCallback((activeTheme) => {
    // Apply to HTML root for CSS variable scope
    document.documentElement.setAttribute('data-theme', activeTheme);
    
    // Persist local state
    localStorage.setItem('theme', activeTheme);
    
    // Update meta theme color for mobile browsers
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (metaThemeColor) {
      metaThemeColor.setAttribute('content', activeTheme === 'dark' ? '#1E2023' : '#E0E5EC');
    }
    setTheme(activeTheme);
  }, []);

  const resolveTheme = useCallback((currentSettings) => {
    if (currentSettings.mode === 'light' || currentSettings.mode === 'dark') {
      return currentSettings.mode;
    }

    if (currentSettings.mode === 'auto' || currentSettings.follow_system) {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }

    return 'dark'; // Fallback
  }, []);

  // Initial Load
  useEffect(() => {
    setLoading(true);
    let userSettings = defaultSettings;

    if (user) {
      const storedSettings = localStorage.getItem(`theme_settings_${user.id}`);
      if (storedSettings) {
        userSettings = { ...defaultSettings, ...JSON.parse(storedSettings) };
      }
    } else {
      const storedTheme = localStorage.getItem('theme');
      if (storedTheme) {
          // If they manually toggled before login, respect it, but keep auto logic
          userSettings = { ...defaultSettings, mode: storedTheme === 'light' ? 'light' : 'dark', follow_system: false };
      }
    }

    setSettings(userSettings);
    const activeTheme = resolveTheme(userSettings);
    applyTheme(activeTheme);
    setLoading(false);
  }, [user, applyTheme, resolveTheme]);

  // Listen for System Changes
  useEffect(() => {
    if (settings.mode !== 'auto') return;

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    
    const handleChange = (e) => {
      const newSystemTheme = e.matches ? 'dark' : 'light';
      applyTheme(newSystemTheme);
    };
    
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [settings.mode, applyTheme]);
  
  const updateSettings = (newSettings) => {
    const updated = { ...settings, ...newSettings };
    if (user) {
        localStorage.setItem(`theme_settings_${user.id}`, JSON.stringify(updated));
    }
    
    setSettings(updated);
    const activeTheme = resolveTheme(updated);
    applyTheme(activeTheme);
  };
  
  const cycleThemeMode = () => {
    const modes = ['light', 'dark', 'auto'];
    const currentIndex = modes.indexOf(settings.mode);
    const nextMode = modes[(currentIndex + 1) % modes.length];
    
    let newSettings = { mode: nextMode };
    if (nextMode === 'auto') {
        newSettings.follow_system = true;
    } else {
        newSettings.follow_system = false;
    }
    
    updateSettings(newSettings);
  }

  return (
    <ThemeContext.Provider value={{ theme, settings, loading, updateSettings, cycleThemeMode }}>
      {children}
    </ThemeContext.Provider>
  );
};