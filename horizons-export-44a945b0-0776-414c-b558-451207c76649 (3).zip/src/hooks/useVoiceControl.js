import { useState, useEffect, useCallback } from 'react';
import { toast } from '@/components/ui/use-toast';

export const useVoiceControl = (commands = {}) => {
  const [isListening, setIsListening] = useState(false);
  const [support, setSupport] = useState(true);
  const [transcript, setTranscript] = useState('');

  useEffect(() => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      setSupport(false);
      return;
    }
  }, []);

  const toggleListening = useCallback(() => {
    if (!support) {
      toast({ title: "No soportado", description: "Tu navegador no soporta reconocimiento de voz.", variant: "destructive" });
      return;
    }

    if (isListening) {
      window.recognition?.stop();
      setIsListening(false);
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    window.recognition = new SpeechRecognition();
    window.recognition.continuous = true;
    window.recognition.interimResults = false;
    window.recognition.lang = 'es-ES';

    window.recognition.onstart = () => {
      setIsListening(true);
      toast({ title: "🎙️ Voz Activa", description: "Di 'Completado' o 'Siguiente'" });
    };

    window.recognition.onresult = (event) => {
      const last = event.results.length - 1;
      const text = event.results[last][0].transcript.toLowerCase().trim();
      setTranscript(text);
      
      console.log("Voz detectada:", text);

      // Simple fuzzy matching
      Object.keys(commands).forEach(key => {
        if (text.includes(key)) {
          commands[key]();
          toast({ title: "Comando Recibido", description: `Ejecutando: ${key}`, className: "bg-green-500 text-black border-none" });
        }
      });
    };

    window.recognition.onerror = (event) => {
      console.error("Speech error", event.error);
      setIsListening(false);
    };

    window.recognition.onend = () => {
      // Auto-restart if it cuts off but user wanted it on (simple keep-alive)
      if (isListening) window.recognition.start();
    };

    window.recognition.start();
  }, [isListening, support, commands]);

  // Cleanup
  useEffect(() => {
    return () => {
      if (window.recognition) window.recognition.stop();
    };
  }, []);

  return { isListening, toggleListening, transcript, support };
};