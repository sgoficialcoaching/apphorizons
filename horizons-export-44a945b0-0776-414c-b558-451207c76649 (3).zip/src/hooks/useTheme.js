import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';

const ThemeContext = createContext();

export const useTheme = () => useContext(ThemeContext);

const defaultSettings = {
  mode: 'auto',
  follow_system: true,
  day_start_hour: 7,
  night_start_hour: 19,
  timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'Europe/Madrid',
};

export const ThemeProvider = ({ children }) => {
  const { user } = useAuth();
  const [theme, setTheme] = useState('dark');
  const [settings, setSettings] = useState(defaultSettings);
  const [loading, setLoading] = useState(true);

  const applyTheme = useCallback((activeTheme) => {
    document.documentElement.setAttribute('data-theme', activeTheme);
    localStorage.setItem('theme', activeTheme);
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (metaThemeColor) {
      metaThemeColor.setAttribute('content', activeTheme === 'dark' ? '#0E0F11' : '#FFFFFF');
    }
    setTheme(activeTheme);
  }, []);

  const resolveTheme = useCallback((currentSettings) => {
    if (currentSettings.mode === 'light' || currentSettings.mode === 'dark') {
      return currentSettings.mode;
    }

    if (currentSettings.follow_system) {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }

    const now = new Date();
    const currentHour = now.getHours();
    if (currentHour >= currentSettings.day_start_hour && currentHour < currentSettings.night_start_hour) {
      return 'light';
    }
    return 'dark';
  }, []);

  const fetchSettings = useCallback(() => {
    if (!user) {
      const storedTheme = localStorage.getItem('theme') || 'dark';
      applyTheme(storedTheme);
      setSettings(defaultSettings);
      setLoading(false);
      return;
    }

    const storedSettings = localStorage.getItem(`theme_settings_${user.id}`);
    let userSettings = defaultSettings;
    
    if (storedSettings) {
      userSettings = { ...defaultSettings, ...JSON.parse(storedSettings) };
    }
    
    setSettings(userSettings);
    const activeTheme = resolveTheme(userSettings);
    applyTheme(activeTheme);
    setLoading(false);
  }, [user, applyTheme, resolveTheme]);

  useEffect(() => {
    fetchSettings();
  }, [fetchSettings, user]);

  useEffect(() => {
    if (loading || !settings || settings.mode !== 'auto' || !settings.follow_system) return;

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = () => {
      const activeTheme = resolveTheme(settings);
      applyTheme(activeTheme);
    };
    
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [settings, applyTheme, resolveTheme, loading]);
  
  const updateSettings = (newSettings) => {
    if (!user) return;
    
    localStorage.setItem(`theme_settings_${user.id}`, JSON.stringify(newSettings));
    setSettings(newSettings);
    const activeTheme = resolveTheme(newSettings);
    applyTheme(activeTheme);
  };

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    updateSettings({ ...settings, mode: newTheme });
  };
  
  const cycleThemeMode = () => {
    const modes = ['light', 'dark', 'auto'];
    const currentIndex = settings ? modes.indexOf(settings.mode) : 2;
    const nextMode = modes[(currentIndex + 1) % modes.length];
    updateSettings({ ...settings, mode: nextMode });
  };

  return (
    <ThemeContext.Provider value={{ theme, settings, loading, updateSettings, cycleThemeMode, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};