import React, { useState, useEffect, Suspense, lazy } from 'react';
import { Helmet } from 'react-helmet';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { checkSubscriptionStatus } from '@/lib/subscription';
import LoadingScreen from '@/components/common/LoadingScreen';
import { toast } from '@/components/ui/use-toast';
import { initializeCommunityData } from '@/lib/community';
import { useTheme } from '@/hooks/useTheme';
import { 
  performDailyCheckin, 
  initializeDatabase, 
  seedAnalyticsData, 
  getNutritionProfile, 
  getBoostChallengeStatus 
} from '@/lib/database.js';
import { addXpAndBoosties } from '@/lib/gamification';

// Lazy load admin components to prevent bundle bloat
const AdminRoute = lazy(() => import('@/components/admin/AdminRoute'));
const AdminDashboard = lazy(() => import('@/components/admin/AdminDashboard'));

// Lazy load components to prevent bundle bloat and circular dependencies
const LandingScreen = lazy(() => import('@/components/screens/LandingScreen'));
const SelectionScreen = lazy(() => import('@/components/screens/SelectionScreen'));
const AuthScreen = lazy(() => import('@/components/auth/AuthScreen'));
const OnboardingWizard = lazy(() => import('@/components/onboarding/OnboardingWizard'));
const PlanSelectionScreen = lazy(() => import('@/components/onboarding/PlanSelectionScreen'));
const MainLayout = lazy(() => import('@/components/layout/MainLayout'));
const BoostChallengeModal = lazy(() => import('@/components/challenge/BoostChallengeModal'));
const UserProfileScreen = lazy(() => import('@/components/community/UserProfileScreen'));
const WorkoutTemplatesScreen = lazy(() => import('@/components/screens/WorkoutTemplatesScreen'));
const ExerciseDetailScreen = lazy(() => import('@/components/screens/ExerciseDetailScreen'));
const Dashboard = lazy(() => import('@/components/screens/Dashboard'));
const CommunityScreen = lazy(() => import('@/components/screens/CommunityScreen'));
const BoostScreen = lazy(() => import('@/components/screens/BoostScreen'));
const ProfileScreen = lazy(() => import('@/components/screens/ProfileScreen'));
const ContentScreen = lazy(() => import('@/components/screens/ContentScreen'));
const StoreScreen = lazy(() => import('@/components/screens/StoreScreen'));
const PostDetailScreen = lazy(() => import('@/components/community/PostDetailScreen'));
const RecipeDetailScreen = lazy(() => import('@/components/nutrition/RecipeDetailScreen'));
const AnalyticsScreen = lazy(() => import('@/components/screens/AnalyticsScreen'));
const SessionPrepScreen = lazy(() => import('@/components/workout/SessionPrepScreen'));
const WorkoutScreen = lazy(() => import('@/components/screens/WorkoutScreen'));
const PreviewBoost = lazy(() => import('@/components/screens/PreviewBoost'));
const NutritionScreen = lazy(() => import('@/components/screens/NutritionScreen'));
const WorkoutPreviewScreen = lazy(() => import('@/components/workout/WorkoutPreviewScreen'));

function App() {
  const { user, session, loading: authLoading, refreshUser } = useAuth();
  const location = useLocation();
  const [needsOnboarding, setNeedsOnboarding] = useState(false);
  const [needsPlanSelection, setNeedsPlanSelection] = useState(false);
  const [showChallengeModal, setShowChallengeModal] = useState(false);
  const { theme, loading: themeLoading } = useTheme();
  const [showAuth, setShowAuth] = useState(false);

  useEffect(() => {
    // Ensure DB is initialized before anything else
    initializeDatabase();
  }, []);

  useEffect(() => {
    const publicPaths = ['/', '/selection', '/preview-boost'];
    // Allow /admin to handle its own auth check
    if (location.pathname.startsWith('/admin')) {
       setShowAuth(false);
       return;
    }

    if (publicPaths.includes(location.pathname)) {
        if (!user) setShowAuth(false);
    } else if (!user) {
      setShowAuth(true);
    } else {
      setShowAuth(false);
    }
  }, [location, user]);

  useEffect(() => {
    const checkOnboarding = async () => {
      if (user && session) {
        setShowAuth(false);
        const profile = getNutritionProfile(user.id);
        
        if (!profile) {
          setNeedsOnboarding(true);
        } else {
          setNeedsOnboarding(false);
        }

        const planSelected = localStorage.getItem(`plan_selected_${user.id}`);
        setNeedsPlanSelection(!planSelected && !needsOnboarding);

        if (localStorage.getItem('seed_analytics_v1') !== 'true') {
          seedAnalyticsData(user.id);
        }
        
        try { checkSubscriptionStatus(user.id); } catch (e) { console.warn("Sub check failed", e); }

        // GAMIFICATION CHECK-IN
        const { newTokens } = performDailyCheckin(user.id);
        if (newTokens > 0) {
           // Also add XP for login via new system
           const reward = await addXpAndBoosties(user.id, 'LOGIN');
           toast({
            title: '🎁 ¡Bono Diario!',
            description: `+${reward.earnedBoosties} Boosties | +${reward.earnedXp} XP`,
           });
        }
        
        const hasSeenBoostsModal = localStorage.getItem('hasSeenBoostsModal');
        if (!hasSeenBoostsModal) {
          localStorage.setItem('hasSeenBoostsModal', 'true');
        }

        const challengeStatus = getBoostChallengeStatus(user.id);
        const hasSeenChallengeModal = sessionStorage.getItem('hasSeenChallengeModal');
        if (!challengeStatus.isActive && !challengeStatus.isCompleted && !hasSeenChallengeModal) {
          setShowChallengeModal(true);
          sessionStorage.setItem('hasSeenChallengeModal', 'true');
        }
      }
    };
    
    try { initializeCommunityData(); } catch (e) { console.warn("Community init failed", e); }
    checkOnboarding();
  }, [user, session, needsOnboarding]);

  const handleOnboardingComplete = () => {
    setNeedsOnboarding(false);
    setNeedsPlanSelection(true);
    if(refreshUser) refreshUser();
  };

  const handlePlanSelectionComplete = () => {
    if (user) localStorage.setItem(`plan_selected_${user.id}`, 'true');
    setNeedsPlanSelection(false);
  };

  if (authLoading || themeLoading) {
    return <LoadingScreen initialTransition={true} />;
  }
  
  const renderMainRoutes = () => (
    <>
      <MainLayout>
        <Suspense fallback={<LoadingScreen />}>
          <Routes>
            <Route path="/home" element={<Dashboard />} />
            <Route path="/nutrition" element={<NutritionScreen />} />
            <Route path="/community" element={<CommunityScreen />} />
            <Route path="/community/callback" element={<CommunityScreen />} />
            <Route path="/boost" element={<BoostScreen />} />
            <Route path="/analytics" element={<AnalyticsScreen />} />
            <Route path="/store" element={<StoreScreen />} />
            <Route path="/profile" element={<ProfileScreen />} />
            <Route path="/content/:contentId" element={<ContentScreen />} />
            <Route path="/user/:userId" element={<UserProfileScreen />} />
            <Route path="/templates" element={<WorkoutTemplatesScreen />} />
            <Route path="/exercise/:exerciseId" element={<ExerciseDetailScreen />} />
            <Route path="/workout/:workoutId" element={<WorkoutScreen />} />
            <Route path="/workout-preview/:date" element={<WorkoutPreviewScreen />} />
            <Route path="/post/:postId" element={<PostDetailScreen />} />
            <Route path="/recipe/:recipeId" element={<RecipeDetailScreen />} />
            <Route path="/session-prep/:date/:level" element={<SessionPrepScreen />} />
            <Route path="/" element={<Navigate to="/home" replace />} />
            <Route path="*" element={<Navigate to="/home" replace />} />
          </Routes>
        </Suspense>
      </MainLayout>
      {showChallengeModal && <BoostChallengeModal onClose={() => setShowChallengeModal(false)} />}
    </>
  );

  const getActiveScreen = () => {
    if (location.pathname.startsWith('/admin')) {
       return (
          <AdminRoute>
              <AdminDashboard />
          </AdminRoute>
       );
    }

    if (showAuth) {
      return <AuthScreen />;
    }
    if (user) {
        if (needsOnboarding) {
            return <OnboardingWizard user={user} onComplete={handleOnboardingComplete} />;
        }
        if (needsPlanSelection) {
            return <PlanSelectionScreen user={user} onComplete={handlePlanSelectionComplete} />;
        }
        return renderMainRoutes();
    }
    
    return (
        <Routes>
            <Route path="/" element={<LandingScreen />} />
            <Route path="/selection" element={<SelectionScreen />} />
            <Route path="/preview-boost" element={<PreviewBoost />} />
            <Route path="*" element={<AuthScreen />} />
        </Routes>
    );
  };

  return (
    <>
      <Helmet>
        <title>Sergi Constance App</title>
        <meta name="description" content="Tu panel de control personal de entrenamiento y nutrición." />
        <meta name="theme-color" content={theme === 'dark' ? '#0E0F11' : '#FFFFFF'} />
      </Helmet>
      <Suspense fallback={<LoadingScreen initialTransition={true} />}>
        {getActiveScreen()}
      </Suspense>
      <Toaster />
    </>
  );
}

export default App;