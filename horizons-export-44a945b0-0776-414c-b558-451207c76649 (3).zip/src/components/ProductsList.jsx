import React, { useCallback, useMemo, useState, useEffect } from 'react';
    import { motion } from 'framer-motion';
    import { Link, useNavigate } from 'react-router-dom';
    import { Button } from '@/components/ui/button';
    import { ShoppingCart, Loader2 } from 'lucide-react';
    import { useCart } from '@/hooks/useCart';
    import { useToast } from '@/components/ui/use-toast';
    import { getProducts, getProductQuantities } from '@/api/EcommerceApi';
    import { Helmet } from 'react-helmet';
    
    const placeholderImage = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjMzc0MTUxIi8+CiAgPHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzlDQTNBRiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5vIEltYWdlPC90ZXh0Pgo8L3N2Zz4K";
    
    const ProductCard = ({ product, index }) => {
      const { addToCart } = useCart();
      const { toast } = useToast();
      const navigate = useNavigate();
    
      const displayVariant = useMemo(() => product.variants[0], [product]);
      const hasSale = useMemo(() => displayVariant && displayVariant.sale_price_in_cents !== null, [displayVariant]);
      const displayPrice = useMemo(() => hasSale ? displayVariant.sale_price_formatted : displayVariant.price_formatted, [displayVariant, hasSale]);
      const originalPrice = useMemo(() => hasSale ? displayVariant.price_formatted : null, [displayVariant, hasSale]);
    
      const handleAddToCart = useCallback(async (e) => {
        e.preventDefault();
        e.stopPropagation();
    
        if (product.variants.length > 1) {
          navigate(`/product/${product.id}`);
          return;
        }
    
        const defaultVariant = product.variants[0];
    
        try {
          await addToCart(product, defaultVariant, 1, defaultVariant.inventory_quantity);
          toast({
            title: "Added to Cart! 🛒",
            description: `${product.title} has been added to your cart.`,
          });
        } catch (error) {
          toast({
            title: "Error adding to cart",
            description: error.message,
          });
        }
      }, [product, addToCart, toast, navigate]);
    
      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.05 }}
          className="bg-card rounded-2xl overflow-hidden shadow-lg transition-all duration-300 hover:shadow-primary/20 hover:-translate-y-1 group"
        >
          <Link to={`/product/${product.id}`} className="block">
            <div className="relative">
              <img
                src={product.image || placeholderImage}
                alt={product.title}
                className="w-full h-56 sm:h-64 object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/10 group-hover:bg-black/30 transition-all duration-300" />
              {product.ribbon_text && (
                <div className="absolute top-3 left-3 bg-primary/90 text-primary-foreground text-xs font-bold px-3 py-1 rounded-full shadow-lg">
                  {product.ribbon_text}
                </div>
              )}
            </div>
            <div className="p-4">
              <h3 className="text-md sm:text-lg font-bold truncate text-foreground">{product.title}</h3>
              <p className="text-xs sm:text-sm text-muted-foreground h-10 overflow-hidden">{product.subtitle || 'Check out this amazing product!'}</p>
              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-lg sm:text-xl font-bold text-primary">{displayPrice}</span>
                {hasSale && (
                  <span className="line-through text-muted-foreground">{originalPrice}</span>
                )}
              </div>
              <Button onClick={handleAddToCart} className="w-full mt-4 btn-primary">
                <ShoppingCart className="mr-2 h-4 w-4" /> 
                {product.variants.length > 1 ? 'View Options' : 'Add to Cart'}
              </Button>
            </div>
          </Link>
        </motion.div>
      );
    };
    
    const ProductsList = () => {
      const [products, setProducts] = useState([]);
      const [loading, setLoading] = useState(true);
      const [error, setError] = useState(null);
    
      useEffect(() => {
        const fetchProductsWithQuantities = async () => {
          try {
            setLoading(true);
            setError(null);
    
            const productsResponse = await getProducts();
    
            if (productsResponse.products.length === 0) {
              setProducts([]);
              setLoading(false);
              return;
            }
    
            const productIds = productsResponse.products.map(product => product.id);
    
            const quantitiesResponse = await getProductQuantities({
              fields: 'inventory_quantity',
              product_ids: productIds
            });
    
            const variantQuantityMap = new Map();
            quantitiesResponse.variants.forEach(variant => {
              variantQuantityMap.set(variant.id, variant.inventory_quantity);
            });
    
            const productsWithQuantities = productsResponse.products.map(product => ({
              ...product,
              variants: product.variants.map(variant => ({
                ...variant,
                inventory_quantity: variantQuantityMap.get(variant.id) ?? variant.inventory_quantity
              }))
            }));
    
            setProducts(productsWithQuantities);
          } catch (err) {
            setError(err.message || 'Failed to load products');
          } finally {
            setLoading(false);
          }
        };
    
        fetchProductsWithQuantities();
      }, []);
    
      if (loading) {
        return (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="h-16 w-16 text-primary animate-spin" />
          </div>
        );
      }
    
      if (error) {
        return (
          <div className="text-center text-red-500 p-8 glass-effect rounded-2xl">
            <p>Error loading products: {error}</p>
          </div>
        );
      }
    
      return (
        <>
          <Helmet>
            <title>Store - Sergi Constance App</title>
            <meta name="description" content="Browse the official Sergi Constance store." />
          </Helmet>
          <div className="space-y-8">
            <div>
                <h1 className="text-3xl sm:text-4xl font-bold text-foreground">Official Store</h1>
                <p className="text-muted-foreground mt-2 text-sm sm:text-base">Exclusive products curated by Sergi Constance.</p>
            </div>
            {products.length === 0 ? (
              <div className="text-center text-muted-foreground p-8 glass-effect rounded-2xl">
                <p>No products available at the moment.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
                {products.map((product, index) => (
                  <ProductCard key={product.id} product={product} index={index} />
                ))}
              </div>
            )}
          </div>
        </>
      );
    };
    
    export default ProductsList;