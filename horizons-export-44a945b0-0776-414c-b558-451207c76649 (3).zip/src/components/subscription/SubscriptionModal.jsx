import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Check, Crown, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { SUBSCRIPTION_PLANS } from '@/lib/subscription';
import { toast } from '@/components/ui/use-toast';

const SubscriptionModal = ({ user, onClose, onSubscribe }) => {
  const [selectedPlan, setSelectedPlan] = useState('pro');
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState(null);

  const plans = [
    {
      ...SUBSCRIPTION_PLANS.PRO,
      icon: Crown,
      color: 'from-purple-600 to-pink-600',
      popular: true
    },
    {
      ...SUBSCRIPTION_PLANS.ELITE,
      icon: Zap,
      color: 'from-yellow-600 to-orange-600',
      popular: false
    }
  ];

  const handleApplyCoupon = () => {
    if (couponCode.toUpperCase() === 'SERGI10') {
      setAppliedCoupon({ code: 'SERGI10', discount: 0.1 });
      toast({
        title: '✅ Coupon applied!',
        description: '10% discount on your first month'
      });
    } else {
      toast({
        title: 'Invalid coupon',
        description: 'Please check the code and try again',
        variant: 'destructive'
      });
    }
  };

  const handleSubscribe = () => {
    toast({
      title: '🚧 Stripe Integration Required',
      description: 'To enable payments, you need to integrate Stripe. Check out this article to learn how: https://www.hostinger.com/support/hostinger-horizons-how-to-sell-subscriptions-with-stripe/'
    });
  };

  const selectedPlanData = plans.find(p => p.id === selectedPlan);
  const finalPrice = appliedCoupon
    ? (selectedPlanData.price * (1 - appliedCoupon.discount)).toFixed(2)
    : selectedPlanData.price;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="glass-effect rounded-3xl p-8 max-w-4xl w-full max-h-[90vh] overflow-y-auto"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-3xl font-bold gradient-text">Choose Your Plan</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/5 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="mb-6 p-4 bg-purple-500/10 border border-purple-500/30 rounded-xl">
          <p className="text-center font-semibold">
            🎉 7-Day Free Trial • Cancel Anytime • Use code <span className="text-yellow-400">SERGI10</span> for 10% off
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-6">
          {plans.map((plan) => (
            <motion.div
              key={plan.id}
              whileHover={{ scale: 1.02 }}
              onClick={() => setSelectedPlan(plan.id)}
              className={`relative p-6 rounded-2xl border-2 cursor-pointer transition-all ${
                selectedPlan === plan.id
                  ? 'border-purple-500 bg-purple-500/10'
                  : 'border-slate-700 bg-slate-800/30 hover:border-slate-600'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="premium-badge">MOST POPULAR</span>
                </div>
              )}

              <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-4`}>
                <plan.icon className="w-8 h-8" />
              </div>

              <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
              <div className="flex items-baseline gap-2 mb-4">
                <span className="text-4xl font-bold">€{plan.price}</span>
                <span className="text-slate-400">/month</span>
              </div>

              <ul className="space-y-3">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        <div className="glass-effect rounded-2xl p-6 mb-6">
          <h3 className="font-semibold mb-3">Have a coupon code?</h3>
          <div className="flex gap-3">
            <input
              type="text"
              value={couponCode}
              onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
              placeholder="Enter code"
              className="flex-1 px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl"
            />
            <Button
              onClick={handleApplyCoupon}
              variant="outline"
              className="border-slate-700"
            >
              Apply
            </Button>
          </div>
          {appliedCoupon && (
            <p className="text-green-400 text-sm mt-2">
              ✓ {appliedCoupon.code} applied - {appliedCoupon.discount * 100}% off
            </p>
          )}
        </div>

        <div className="flex items-center justify-between p-6 bg-slate-800/30 rounded-2xl mb-6">
          <div>
            <p className="text-slate-400 text-sm">Total today</p>
            <p className="text-3xl font-bold">
              €0.00
              <span className="text-lg text-slate-400 ml-2">(7-day trial)</span>
            </p>
            {appliedCoupon && (
              <p className="text-sm text-slate-400 mt-1">
                Then €{finalPrice}/month
              </p>
            )}
          </div>
          <Button
            onClick={handleSubscribe}
            className={`bg-gradient-to-r ${selectedPlanData.color} hover:opacity-90 px-8 py-6 text-lg`}
          >
            Start Free Trial
          </Button>
        </div>

        <p className="text-xs text-center text-slate-500">
          By subscribing, you agree to our Terms of Service. Your subscription will automatically renew after the trial period. Cancel anytime.
        </p>
      </motion.div>
    </motion.div>
  );
};

export default SubscriptionModal;