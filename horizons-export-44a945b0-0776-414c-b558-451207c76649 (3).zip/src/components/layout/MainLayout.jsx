import React, { useState, useEffect, useCallback, Suspense, lazy } from 'react';
import { Home, Users, User, Menu, X, LogOut, Bell, Sun, Moon, Sparkles, Bot, Search, AreaChart, Zap, ShoppingBag } from 'lucide-react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useTheme } from '@/hooks/useTheme';
import { getQueuedNotifications, markAllNotificationsAsRead as markSystemNotificationsAsRead } from '@/lib/database.js';
import { getNotifications as getCommunityNotifications, markNotificationsAsRead as markCommunityNotificationsAsRead } from '@/lib/community';
import { getUserProgress } from '@/lib/gamification';
import ParticleBackground from '@/components/common/ParticleBackground';
import BoostMenuOverlay from '@/components/layout/BoostMenuOverlay';

const Chatbot = lazy(() => import('@/components/chatbot/Chatbot'));
const NotificationsSheet = lazy(() => import('@/components/community/NotificationsSheet'));
const SearchCenter = lazy(() => import('@/components/common/SearchCenter'));

const MainLayout = ({ children }) => {
  const { user, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isChatbotOpen, setChatbotOpen] = useState(false);
  const [isNotificationsOpen, setNotificationsOpen] = useState(false);
  const [isSearchOpen, setSearchOpen] = useState(false);
  const [isBoostMenuOpen, setBoostMenuOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [boosties, setBoosties] = useState(0);
  const { settings, cycleThemeMode } = useTheme();

  const isWorkoutMode = location.pathname.startsWith('/workout/');

  const refreshNotifications = useCallback(() => {
    if (user) {
      try {
        const communityNotifs = getCommunityNotifications(user.id).map(n => ({ ...n, source: 'community' }));
        const systemNotifs = getQueuedNotifications(user.id).map(n => ({ ...n, source: 'system' }));
        
        const combined = [...systemNotifs, ...communityNotifs].sort((a, b) => 
          new Date(b.created_at || b.scheduled_at) - new Date(a.created_at || a.scheduled_at)
        );
        
        const uniqueNotifications = combined.map((notif, index) => ({
          ...notif,
          unique_id: `${notif.source}-${notif.id}-${new Date(notif.created_at || notif.scheduled_at).getTime()}-${index}`
        }));
        
        setNotifications(uniqueNotifications);
        
        const unreadSystem = systemNotifs.filter(n => n.status === 'pending').length;
        const unreadCommunity = communityNotifs.filter(n => !n.read_at).length;
        setUnreadNotifications(unreadSystem + unreadCommunity);
      } catch (error) {
        console.error("Error refreshing notifications:", error);
      }
    }
  }, [user]);
  
  const refreshBoosties = useCallback(async () => {
      if(user) {
          const progress = await getUserProgress(user.id);
          setBoosties(progress?.boosties || 0);
      }
  }, [user]);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
      if (e.key === '/') {
        if (document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
          e.preventDefault();
          setSearchOpen(true);
        }
      }
      if (e.key === 'Escape') {
        setSearchOpen(false);
        setBoostMenuOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    
    // Custom event listener for boosting updates across components
    window.addEventListener('boosties_updated', refreshBoosties);
    
    const handleClickOutside = (e) => {
        if (isBoostMenuOpen && !e.target.closest('.boost-menu-trigger') && !e.target.closest('.boost-menu-container')) {
            setBoostMenuOpen(false);
        }
    }
    window.addEventListener('click', handleClickOutside);
    
    return () => {
        window.removeEventListener('keydown', handleKeyDown);
        window.removeEventListener('boosties_updated', refreshBoosties);
        window.removeEventListener('click', handleClickOutside);
    };
  }, [refreshBoosties, isBoostMenuOpen]);

  useEffect(() => {
    refreshNotifications();
    refreshBoosties();
    const currentPath = location.pathname.split('/')[1] || 'home';
    setActiveTab(currentPath);
    setMobileMenuOpen(false);
  }, [location.pathname, user, refreshNotifications, refreshBoosties]);

  const handleLogout = async () => {
    await signOut();
    navigate('/');
  };
  
  const handleTabClick = (tabId) => {
    if (tabId === 'boost') {
        navigate('/boost');
    } else {
        setActiveTab(tabId);
        navigate(`/${tabId}`);
    }
    setMobileMenuOpen(false);
    setBoostMenuOpen(false);
  }

  const handleOpenNotifications = () => {
    if (user) {
      setNotificationsOpen(true);
      setMobileMenuOpen(false);
      markSystemNotificationsAsRead(user.id);
      markCommunityNotificationsAsRead(user.id);
      refreshNotifications();
    }
  };
  
  const ThemeIcon = () => {
    if (settings.mode === 'light') return <Sun className="w-5 h-5"/>;
    if (settings.mode === 'dark') return <Moon className="w-5 h-5"/>;
    return <Sparkles className="w-5 h-5"/>;
  }

  const tabs = [
    { id: 'home', label: 'Inicio', icon: Home },
    { id: 'community', label: 'Comunidad', icon: Users },
    { id: 'boost', label: 'Boost', icon: Zap },
    { id: 'analytics', label: 'Analíticas', icon: AreaChart },
    { id: 'store', label: 'Tienda', icon: ShoppingBag },
  ];

  const NavButton = ({ id, label, icon: Icon }) => {
    const isSubPathActive = location.pathname.startsWith(`/${id}`);
    const isBoost = id === 'boost';
    const finalIsActive = activeTab === id || isSubPathActive || (isBoost && isWorkoutMode);

    return (
      <motion.button
        whileHover={{ scale: 1.05, x: 5 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => handleTabClick(id)}
        className={`relative flex flex-col items-center justify-center gap-1 p-3 rounded-2xl transition-all duration-300 w-full h-20 group ${
          finalIsActive 
            ? 'text-[var(--neon-yellow)] shadow-[var(--shadow-active)]' 
            : 'text-muted-foreground hover:text-[var(--text-main)] hover:shadow-[var(--shadow-light),var(--shadow-dark)]'
        }`}
      >
        <div className={`relative z-10 ${finalIsActive ? 'drop-shadow-[0_0_8px_rgba(255,214,0,0.6)]' : ''}`}>
           {isBoost && isWorkoutMode ? (
               <motion.div
                 animate={{ 
                   scale: [1, 1.1, 1],
                   filter: ["drop-shadow(0 0 2px rgba(255,214,0,0.5))", "drop-shadow(0 0 8px rgba(255,214,0,0.8))", "drop-shadow(0 0 2px rgba(255,214,0,0.5))"]
                 }}
                 transition={{ duration: 2, repeat: Infinity }}
               >
                   <Icon className="w-6 h-6" />
               </motion.div>
           ) : (
               <Icon className="w-6 h-6 transition-transform duration-300 group-hover:-translate-y-1" />
           )}
        </div>
        {finalIsActive && (
          <motion.div 
            layoutId="active-pill"
            className="absolute right-0 h-8 w-1 bg-[var(--neon-yellow)] rounded-l-full shadow-[0_0_10px_rgba(255,214,0,0.5)]"
          />
        )}
        <span className="text-xs font-medium tracking-wide">{label}</span>
      </motion.button>
    );
  };

  const IconButton = ({ onClick, icon: Icon, badge, className }) => (
    <motion.button 
        whileHover={{ scale: 1.1, rotate: 5 }}
        whileTap={{ scale: 0.9 }}
        onClick={onClick} 
        className={`relative p-3 rounded-full text-muted-foreground hover:text-[var(--neon-yellow)] bg-[var(--bg-base)] shadow-[var(--shadow-light),var(--shadow-dark)] active:shadow-[var(--shadow-active)] transition-all border border-transparent hover:border-white/5 ${className}`}
    >
        <Icon className="w-6 h-6" />
        {badge > 0 && (
          <motion.span 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center rounded-full neo-badge shadow-[0_0_10px_rgba(255,214,0,0.5)]"
          >
            {badge}
          </motion.span>
        )}
    </motion.button>
  );

  return (
    <div className="flex min-h-screen bg-[var(--bg-base)] text-foreground overflow-hidden relative transition-colors duration-500">
      <ParticleBackground />
      
      <aside className="hidden md:flex flex-col items-center w-24 py-6 bg-[var(--bg-base)] backdrop-blur-md border-r-0 shadow-[5px_0_25px_rgba(0,0,0,0.1)] z-20 relative">
        <Link to="/home" className="w-16 h-16 mb-10 flex items-center justify-center cursor-pointer hover:scale-105 transition-transform duration-300">
          <img src="https://horizons-cdn.hostinger.com/44a945b0-0776-414c-b558-451207c76649/fb087dd1803a43139c7109f55ed3d3a5.png" alt="Boost Logo" className="max-w-full max-h-full drop-shadow-[0_0_15px_rgba(255,214,0,0.3)]" />
        </Link>
        <nav className="flex flex-col items-center gap-5 flex-1 w-full px-3">
          {tabs.map((tab) => <NavButton key={tab.id} {...tab} />)}
        </nav>
        <div className="flex flex-col items-center gap-5 w-full px-3 pb-4">
           <IconButton onClick={() => setSearchOpen(true)} icon={Search} />
           <IconButton onClick={() => setChatbotOpen(true)} icon={Bot} />
           <IconButton onClick={handleOpenNotifications} icon={Bell} badge={unreadNotifications} />
           <motion.button 
             whileHover={{ scale: 1.1 }} 
             onClick={() => handleTabClick('profile')}
             className="relative p-1 rounded-full shadow-[var(--shadow-light),var(--shadow-dark)] overflow-hidden border border-white/10"
           >
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FFD600] to-amber-600 flex items-center justify-center text-black font-bold text-lg">
                {user?.user_metadata?.full_name?.charAt(0) || <User className="w-6 h-6 text-black" />}
              </div>
           </motion.button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col pb-0 min-w-0 relative z-10">
        <header className="md:hidden bg-[var(--bg-base)]/90 backdrop-blur-xl sticky top-0 z-40 px-4 py-3 shadow-[0_5px_20px_rgba(0,0,0,0.1)] flex items-center justify-between border-b border-white/5 safe-area-top">
            <Link to="/home" className="flex items-center gap-3">
              <div className="w-10 h-10">
                 <img src="https://horizons-cdn.hostinger.com/44a945b0-0776-414c-b558-451207c76649/fb087dd1803a43139c7109f55ed3d3a5.png" alt="Boost Logo" className="w-full h-full object-contain drop-shadow-[0_0_10px_rgba(255,214,0,0.4)]" />
              </div>
            </Link>
            <div className="flex items-center gap-3">
              <IconButton onClick={() => setChatbotOpen(true)} icon={Bot} className="text-[var(--neon-yellow)]" />

              <motion.div 
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/store')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[var(--bg-surface)] border border-[var(--neon-yellow)]/20 shadow-[var(--shadow-light),var(--shadow-dark)] cursor-pointer"
              >
                <Zap className="w-4 h-4 text-[var(--neon-yellow)] fill-[var(--neon-yellow)]" />
                <span className="text-xs font-black text-[var(--text-main)]">{boosties}</span>
              </motion.div>

              <IconButton onClick={() => setMobileMenuOpen(!mobileMenuOpen)} icon={mobileMenuOpen ? X : Menu} />
            </div>
        </header>

        <AnimatePresence>
            {mobileMenuOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                className="md:hidden bg-[var(--bg-base)] z-30 absolute top-[64px] left-0 right-0 shadow-2xl border-t border-white/5 backdrop-blur-xl"
              >
                <nav className="p-4 space-y-3">
                   <motion.button 
                    whileTap={{ scale: 0.98 }}
                    onClick={() => { setSearchOpen(true); setMobileMenuOpen(false); }}
                    className="w-full flex items-center gap-3 px-4 py-4 rounded-2xl shadow-[var(--shadow-light),var(--shadow-dark)] text-muted-foreground hover:text-[var(--neon-yellow)] bg-[var(--bg-surface)]"
                  >
                    <Search className="w-5 h-5" />
                    <span className="font-medium">Buscar</span>
                  </motion.button>
                  
                  <motion.button 
                    whileTap={{ scale: 0.98 }}
                    onClick={handleOpenNotifications} 
                    className="w-full flex items-center gap-3 px-4 py-4 rounded-2xl shadow-[var(--shadow-light),var(--shadow-dark)] text-muted-foreground hover:text-[var(--neon-yellow)] bg-[var(--bg-surface)] relative"
                  >
                    <div className="relative">
                        <Bell className="w-5 h-5" />
                        {unreadNotifications > 0 && (
                             <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[var(--neon-yellow)] rounded-full" />
                        )}
                    </div>
                    <span className="font-medium">Notificaciones</span>
                    {unreadNotifications > 0 && <span className="ml-auto text-xs font-bold bg-[var(--neon-yellow)] text-black px-2 py-0.5 rounded-full">{unreadNotifications}</span>}
                  </motion.button>

                  <div className="w-full h-px bg-white/5 my-2"></div>

                  <motion.button 
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleTabClick('profile')} 
                    className="w-full flex items-center gap-3 px-4 py-4 rounded-2xl shadow-[var(--shadow-light),var(--shadow-dark)] text-muted-foreground hover:text-[var(--neon-yellow)] bg-[var(--bg-surface)]"
                  >
                    <User className="w-5 h-5" />
                    <span className="font-medium">Mi Perfil</span>
                  </motion.button>
                  <motion.button 
                     whileTap={{ scale: 0.98 }}
                     onClick={cycleThemeMode} 
                     className="w-full flex items-center gap-3 px-4 py-4 rounded-2xl shadow-[var(--shadow-light),var(--shadow-dark)] text-muted-foreground hover:text-[var(--neon-yellow)] bg-[var(--bg-surface)]"
                  >
                    <ThemeIcon />
                    <span className="font-medium capitalize">Tema {settings.mode}</span>
                  </motion.button>
                  <motion.button 
                     whileTap={{ scale: 0.98 }}
                     onClick={handleLogout} 
                     className="w-full flex items-center gap-3 px-4 py-4 rounded-2xl shadow-[var(--shadow-light),var(--shadow-dark)] text-red-500 bg-[var(--bg-surface)]"
                  >
                    <LogOut className="w-5 h-5" />
                    <span className="font-medium">Cerrar Sesión</span>
                  </motion.button>
                </nav>
              </motion.div>
            )}
        </AnimatePresence>

        {/* Main Content Area - Added pb-nav-safe for mobile scroll clearance */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto scrollbar-hide pb-nav-safe md:pb-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3, ease: "easeInOut" }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Mobile Bottom Nav */}
      <motion.nav 
        className={`md:hidden fixed bottom-4 left-4 right-4 bg-[var(--bg-base)]/95 backdrop-blur-xl z-50 shadow-[0_8px_32px_rgba(0,0,0,0.4)] rounded-3xl border transition-all duration-500 safe-area-bottom ${
            isWorkoutMode ? 'border-[var(--neon-yellow)]/50 shadow-[0_0_25px_rgba(255,214,0,0.3)]' : 'border-white/10'
        }`}
        animate={isWorkoutMode ? { 
             boxShadow: ["0px 8px 32px rgba(0,0,0,0.2)", "0px 8px 32px rgba(255,214,0,0.3)", "0px 8px 32px rgba(0,0,0,0.2)"] 
        } : {}}
        transition={{ duration: 3, repeat: Infinity }}
      >
        {isWorkoutMode && (
             <motion.div 
                className="absolute inset-0 rounded-3xl bg-[var(--neon-yellow)]/5 z-0 pointer-events-none"
                animate={{ opacity: [0.3, 0.6, 0.3] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
             />
        )}

        <div className="flex justify-around items-center p-2 relative z-10">
          {tabs.map(tab => {
            const isSubPathActive = location.pathname.startsWith(`/${tab.id}`);
            const isBoost = tab.id === 'boost';
            const finalIsActive = activeTab === tab.id || isSubPathActive || (isBoost && isBoostMenuOpen) || (isBoost && isWorkoutMode);
            const isTrainingActive = isBoost && isWorkoutMode;

            return (
              <button
                key={tab.id}
                onClick={(e) => {
                    if (isBoost) {
                        e.stopPropagation();
                        if (isWorkoutMode) {
                             navigate('/boost'); 
                        } else {
                             setBoostMenuOpen(!isBoostMenuOpen);
                        }
                    } else {
                        handleTabClick(tab.id);
                    }
                }}
                className={`relative flex flex-col items-center justify-center w-12 h-12 rounded-2xl transition-all duration-300 ${
                  finalIsActive 
                    ? 'text-[var(--neon-yellow)] -translate-y-3 shadow-[0_10px_20px_rgba(0,0,0,0.15)] bg-[var(--bg-surface)] border border-[var(--neon-yellow)]/20' 
                    : 'text-muted-foreground'
                } ${isBoost ? 'boost-menu-trigger' : ''}`}
              >
                 <div className={`absolute inset-0 rounded-2xl opacity-0 transition-opacity duration-300 ${finalIsActive ? 'opacity-100 shadow-[0_0_15px_rgba(255,214,0,0.2)]' : ''}`} />
                 
                 {isTrainingActive && (
                     <>
                        <motion.div 
                            className="absolute inset-0 bg-[var(--neon-yellow)]/20 rounded-2xl z-[-1]"
                            animate={{ scale: [1, 1.6], opacity: [0.8, 0] }}
                            transition={{ duration: 1.5, repeat: Infinity, ease: "easeOut" }}
                        />
                        <motion.div 
                            className="absolute inset-0 bg-[var(--neon-yellow)]/20 rounded-2xl z-[-1]"
                            animate={{ scale: [1, 1.6], opacity: [0.8, 0] }}
                            transition={{ duration: 1.5, repeat: Infinity, delay: 0.75, ease: "easeOut" }}
                        />
                     </>
                 )}

                 <motion.div
                    animate={isTrainingActive ? {
                        scale: [1, 1.15, 1],
                        filter: ["drop-shadow(0 0 0px rgba(255,214,0,0))", "drop-shadow(0 0 8px rgba(255,214,0,0.8))", "drop-shadow(0 0 0px rgba(255,214,0,0))"]
                    } : {}}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                 >
                    <tab.icon className={`w-6 h-6 z-10 ${finalIsActive ? 'drop-shadow-[0_0_5px_rgba(255,214,0,0.8)]' : ''}`} />
                 </motion.div>

                 {finalIsActive && <span className="absolute -bottom-5 text-[10px] font-bold text-[var(--neon-yellow)] tracking-wide">{tab.label}</span>}
                 
              </button>
            )
          })}
        </div>
      </motion.nav>
      
      <AnimatePresence>
          {isBoostMenuOpen && !isWorkoutMode && <BoostMenuOverlay onClose={() => setBoostMenuOpen(false)} />}
      </AnimatePresence>
      
      <Suspense fallback={null}>
        <AnimatePresence>
          {isChatbotOpen && user && <Chatbot onClose={() => setChatbotOpen(false)} user={{ name: user.user_metadata.full_name || 'User' }} />}
        </AnimatePresence>
        
        {isNotificationsOpen && <NotificationsSheet onClose={() => setNotificationsOpen(false)} notifications={notifications} onRefresh={refreshNotifications} userId={user?.id} />}
        
        <SearchCenter isOpen={isSearchOpen} onClose={() => setSearchOpen(false)} />
      </Suspense>
    </div>
  );
};

export default MainLayout;