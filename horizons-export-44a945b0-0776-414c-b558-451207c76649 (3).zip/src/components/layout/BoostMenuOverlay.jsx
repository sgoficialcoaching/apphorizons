import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Flame, Apple, Dumbbell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getNutritionProfile, getMealsForDate, getMealItems, getBoostChallengeStatus } from '@/lib/database';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const MenuCluster = ({ title, subText, image, badge, onClick, buttonText, delay = 0, accentColor = "var(--neon-yellow)" }) => (
    <motion.div 
        initial={{ opacity: 0, y: 20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.95 }}
        transition={{ delay, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full h-64 md:h-80 rounded-[2rem] overflow-hidden cursor-pointer group shadow-[0_10px_30px_rgba(0,0,0,0.5)] border border-white/10 hover:border-[var(--neon-yellow)]/50 transition-all duration-500"
        onClick={(e) => {
            e.stopPropagation();
            onClick();
        }}
    >
        <img 
            src={image} 
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 group-hover:brightness-110"
            alt="Background"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/95 via-black/60 to-transparent" />
        
        <div className="absolute inset-0 p-8 flex flex-col justify-center items-start z-10">
            <motion.div 
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: delay + 0.2 }}
                className="text-black text-xs font-black px-3 py-1 rounded-full mb-4 uppercase tracking-widest shadow-[0_0_15px_rgba(255,255,255,0.2)]"
                style={{ backgroundColor: accentColor, boxShadow: `0 0 15px ${accentColor}60` }}
            >
                {badge}
            </motion.div>
            <h2 className="text-3xl md:text-4xl font-black text-white uppercase leading-none mb-2 drop-shadow-[0_4px_4px_rgba(0,0,0,0.8)] italic">
                {title}
            </h2>
            <p className="text-gray-300 max-w-xs text-sm font-medium mb-6 drop-shadow-md line-clamp-2">
                {subText}
            </p>
            <Button 
                className="btn-primary border-none text-black font-bold uppercase tracking-wide pointer-events-none group-hover:scale-105 transition-transform"
                style={{ backgroundColor: accentColor }}
            >
                {buttonText} <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
        </div>
    </motion.div>
);

const BoostMenuOverlay = ({ onClose }) => {
    const navigate = useNavigate();
    const { user } = useAuth();
    const [data, setData] = useState({
        programName: 'Cargando...',
        challengeSubtext: '',
        nutritionSubtext: 'Calculando macros...',
        nutritionTitle: 'Nutrición',
        nutritionBadge: 'Diario',
        loading: true
    });

    useEffect(() => {
        if (!user) return;

        // Training Data
        const challengeStatus = getBoostChallengeStatus(user.id);
        const storedLevel = localStorage.getItem(`workout_level_${user.id}`);
        const programName = challengeStatus?.isActive 
            ? 'Reto Boost' 
            : (storedLevel ? storedLevel.charAt(0).toUpperCase() + storedLevel.slice(1) : 'Programa Base');
        
        const challengeSubtext = challengeStatus?.isActive 
            ? `Semana ${challengeStatus.currentWeek} en curso. ¡Mantén la racha!` 
            : "Supera tus límites con el plan definitivo.";

        // Nutrition Data
        const nutritionProfile = getNutritionProfile(user.id);
        let nutritionSubtext = "Configura tus objetivos para empezar.";
        let nutritionTitle = "Nutrición";
        
        if (nutritionProfile) {
            const dailyMeals = getMealsForDate(user.id, new Date());
            const allItems = dailyMeals.flatMap(meal => getMealItems(user.id, meal.id));
            const totals = allItems.reduce((acc, item) => {
                acc.kcal += item.kcal_calc || 0;
                acc.protein += item.p_calc || 0;
                return acc;
            }, { kcal: 0, protein: 0 });

            nutritionTitle = "Plan Diario";
            nutritionSubtext = `${Math.round(totals.kcal)} / ${nutritionProfile.tmb || nutritionProfile.kcal_objetivo} kcal • ${Math.round(totals.protein)} / ${nutritionProfile.p_gramos}g Prot`;
        }

        setData({
            programName,
            challengeSubtext,
            nutritionSubtext,
            nutritionTitle,
            nutritionBadge: nutritionProfile ? 'Objetivo Activo' : 'Sin Configurar',
            loading: false
        });

    }, [user]);

    const handleNavigate = (path) => {
        onClose();
        // Small delay to allow overlay exit animation if needed, but immediate is usually snappier
        navigate(path);
    };

    return (
        <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center bg-black/90 backdrop-blur-md p-4 boost-menu-container overflow-y-auto"
            onClick={onClose}
        >
            <div className="w-full max-w-5xl grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 p-4">
                <MenuCluster 
                    title={data.programName}
                    subText={data.challengeSubtext}
                    badge="Programa Activo"
                    buttonText="Entrenar"
                    image="https://sergiconstance-9fn0dyoiqm.live-website.com/wp-content/uploads/2025/12/ShottingAtlas-137-1-scaled.jpg"
                    onClick={() => handleNavigate('/boost')}
                    delay={0}
                />

                <MenuCluster 
                    title={data.nutritionTitle}
                    subText={data.nutritionSubtext}
                    badge={data.nutritionBadge}
                    buttonText="Gestionar Dieta"
                    image="https://sergiconstance-9fn0dyoiqm.live-website.com/wp-content/uploads/2025/12/ShottingAtlas-139-scaled.jpg"
                    onClick={() => handleNavigate('/nutrition')}
                    delay={0.1}
                    accentColor="#4ade80" // Green accent for nutrition
                />
            </div>
        </motion.div>
    );
};

export default BoostMenuOverlay;