import React from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, ShoppingBag, DollarSign, Package, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/components/ui/use-toast';

const StatCard = ({ icon, title, value, color }) => (
    <div className="glass-effect p-4 rounded-lg flex items-center space-x-4">
        <div className={`p-3 rounded-full bg-${color}-500/20 text-${color}-400`}>
            {icon}
        </div>
        <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-xl font-bold">{value}</p>
        </div>
    </div>
);

const EcommerceCampus = () => {
    const navigate = useNavigate();

    const comingSoon = () => {
        toast({
            title: "🚧 ¡Próximamente!",
            description: "Esta funcionalidad estará disponible muy pronto.",
        });
    };

    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => navigate('/finance')}>
                    <ArrowLeft />
                </Button>
                <div>
                    <h2 className="text-2xl font-bold">Campus de E-commerce</h2>
                    <p className="text-muted-foreground">Construye y gestiona tu imperio online.</p>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard icon={<DollarSign/>} title="Ingresos (30d)" value="$0.00" color="green" />
                <StatCard icon={<ShoppingBag/>} title="Ventas (30d)" value="0" color="blue" />
                <StatCard icon={<Package/>} title="Pedidos Pendientes" value="0" color="amber" />
                <StatCard icon={<Users/>} title="Nuevos Clientes" value="0" color="purple" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="glass-effect p-6 rounded-lg">
                    <h3 className="font-bold text-lg mb-4">Mis Tiendas</h3>
                    <div className="text-center py-8 text-muted-foreground">
                        <p>Aún no has conectado ninguna tienda.</p>
                        <Button onClick={comingSoon} className="mt-4">Conectar Tienda (Shopify, etc.)</Button>
                    </div>
                </div>
                <div className="glass-effect p-6 rounded-lg">
                    <h3 className="font-bold text-lg mb-4">Productos más vendidos</h3>
                    <div className="text-center py-8 text-muted-foreground">
                        <p>No hay datos de productos disponibles.</p>
                        <Button onClick={comingSoon} variant="secondary" className="mt-4">Importar Productos</Button>
                    </div>
                </div>
            </div>

             <div className="text-center p-4 bg-secondary rounded-lg">
                <h4 className="font-bold">El campus de E-commerce está en desarrollo.</h4>
                <p className="text-sm text-muted-foreground">Pronto podrás gestionar tus tiendas, productos, y analíticas directamente desde aquí.</p>
            </div>
        </motion.div>
    );
};

export default EcommerceCampus;