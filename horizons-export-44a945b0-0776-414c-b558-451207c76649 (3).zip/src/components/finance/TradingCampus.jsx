import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, TrendingUp, TrendingDown, DollarSign, BarChart2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/components/ui/use-toast';

const MOCK_ASSETS = [
    { symbol: 'BTC/USD', price: 68500.50, change: 1.25 },
    { symbol: 'ETH/USD', price: 3550.75, change: -0.80 },
    { symbol: 'SOL/USD', price: 170.20, change: 2.50 },
    { symbol: 'EUR/USD', price: 1.0850, change: 0.15 },
    { symbol: 'SPX500', price: 5300.00, change: 0.50 },
];

const TradingCampus = () => {
    const navigate = useNavigate();
    const [portfolio, setPortfolio] = useState({ balance: 10000, equity: 10000, pnl: 0 });
    const [positions, setPositions] = useState([]);
    const [assets, setAssets] = useState(MOCK_ASSETS);
    const [selectedAsset, setSelectedAsset] = useState(assets[0]);
    const [tradeSide, setTradeSide] = useState('buy'); // 'buy' or 'sell'
    const [tradeAmount, setTradeAmount] = useState(100); // in USD

    const executeTrade = () => {
        if (tradeAmount > portfolio.balance) {
            toast({ variant: 'destructive', title: "Fondos insuficientes" });
            return;
        }

        const newPosition = {
            id: Date.now(),
            asset: selectedAsset.symbol,
            side: tradeSide,
            amount: tradeAmount,
            entryPrice: selectedAsset.price,
            pnl: 0,
        };

        setPositions(prev => [...prev, newPosition]);
        setPortfolio(prev => ({...prev, balance: prev.balance - tradeAmount }));
        toast({ title: `Operación Abierta`, description: `${tradeSide.toUpperCase()} ${tradeAmount}$ en ${selectedAsset.symbol}` });
    };

    const closePosition = (positionId) => {
        const position = positions.find(p => p.id === positionId);
        if (!position) return;

        const pnl = position.pnl;
        setPortfolio(prev => ({ ...prev, balance: prev.balance + position.amount + pnl }));
        setPositions(prev => prev.filter(p => p.id !== positionId));
        toast({ title: "Posición Cerrada", description: `P&L: ${pnl.toFixed(2)}$` });
    };

    useEffect(() => {
        const interval = setInterval(() => {
            const updatedAssets = assets.map(asset => {
                const changeFactor = (Math.random() - 0.5) * 0.001; 
                const newPrice = asset.price * (1 + changeFactor);
                const originalAsset = MOCK_ASSETS.find(a => a.symbol === asset.symbol) || asset;
                const newChange = ((newPrice - originalAsset.price) / originalAsset.price) * 100;
                return { ...asset, price: newPrice, change: newChange };
            });
            setAssets(updatedAssets);
            
            let totalPnl = 0;
            const updatedPositions = positions.map(pos => {
                const currentAsset = updatedAssets.find(a => a.symbol === pos.asset);
                if (!currentAsset) return pos;
                
                const priceChange = currentAsset.price - pos.entryPrice;
                const pnl = (pos.side === 'buy' ? priceChange : -priceChange) * (pos.amount / pos.entryPrice);
                totalPnl += pnl;
                return { ...pos, pnl };
            });
            setPositions(updatedPositions);
            setPortfolio(prev => ({ ...prev, equity: prev.balance + positions.reduce((sum,p)=> sum + p.amount, 0) + totalPnl, pnl: totalPnl }));

        }, 1500);
        return () => clearInterval(interval);
    }, [assets, positions]);

    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => navigate('/finance')}>
                    <ArrowLeft />
                </Button>
                <div>
                    <h2 className="text-2xl font-bold">Campus de Trading</h2>
                    <p className="text-muted-foreground">Simulador de trading en tiempo real.</p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 glass-effect p-4 sm:p-6 rounded-lg space-y-4">
                    <h3 className="text-xl font-bold">{selectedAsset.symbol}</h3>
                    <div className="text-3xl sm:text-4xl font-bold flex items-center gap-2">
                        {selectedAsset.price.toFixed(2)}
                        <span className={`text-base sm:text-lg ${selectedAsset.change >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                           ({selectedAsset.change.toFixed(2)}%)
                        </span>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <Button onClick={() => setTradeSide('buy')} variant={tradeSide === 'buy' ? 'default' : 'secondary'} className="h-16 flex-col gap-1 bg-green-500/20 text-green-300 hover:bg-green-500/30 border-green-500">
                            <TrendingUp/> COMPRAR
                        </Button>
                         <Button onClick={() => setTradeSide('sell')} variant={tradeSide === 'sell' ? 'default' : 'secondary'} className="h-16 flex-col gap-1 bg-red-500/20 text-red-300 hover:bg-red-500/30 border-red-500">
                             <TrendingDown/> VENDER
                        </Button>
                    </div>

                    <div>
                        <label className="text-sm font-medium">Cantidad (USD)</label>
                        <input 
                            type="number"
                            value={tradeAmount}
                            onChange={e => setTradeAmount(Number(e.target.value))}
                            className="w-full mt-1 bg-background p-2 rounded-md border border-border focus:ring-primary focus:border-primary"
                        />
                    </div>
                    <Button onClick={executeTrade} className="w-full btn-primary h-12 text-lg">Ejecutar Orden</Button>
                </div>

                <div className="space-y-6">
                     <div className="glass-effect p-4 rounded-lg space-y-2">
                        <h4 className="font-bold text-lg">Cuenta</h4>
                        <div className="flex justify-between text-sm"><span className="text-muted-foreground">Balance:</span> <span>{portfolio.balance.toFixed(2)}$</span></div>
                        <div className="flex justify-between text-sm"><span className="text-muted-foreground">Equidad:</span> <span>{portfolio.equity.toFixed(2)}$</span></div>
                        <div className="flex justify-between text-sm"><span className="text-muted-foreground">P&L Flotante:</span> <span className={portfolio.pnl >= 0 ? 'text-green-400' : 'text-red-400'}>{portfolio.pnl.toFixed(2)}$</span></div>
                    </div>
                     <div className="glass-effect p-4 rounded-lg">
                        <h4 className="font-bold text-lg mb-2">Activos</h4>
                        <div className="space-y-1 max-h-48 overflow-y-auto">
                            {assets.map(asset => (
                                <div key={asset.symbol} onClick={() => setSelectedAsset(asset)} className={`p-2 rounded-md cursor-pointer flex justify-between items-center text-sm ${selectedAsset.symbol === asset.symbol ? 'bg-primary/20' : 'hover:bg-secondary'}`}>
                                    <span className="font-semibold">{asset.symbol}</span>
                                    <span className={asset.change >= 0 ? 'text-green-500' : 'text-red-500'}>{asset.price.toFixed(2)}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            <div className="glass-effect p-4 sm:p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-4">Posiciones Abiertas</h3>
                {positions.length === 0 ? (
                    <p className="text-muted-foreground text-center py-4">No hay posiciones abiertas.</p>
                ) : (
                    <div className="space-y-3">
                        {positions.map(pos => (
                            <div key={pos.id} className="grid grid-cols-[1fr,auto] sm:grid-cols-5 items-center text-xs sm:text-sm gap-2 p-2 bg-secondary rounded-md">
                                <div className="sm:col-span-1">
                                    <span className={`font-bold ${pos.side === 'buy' ? 'text-green-400' : 'text-red-400'}`}>{pos.side.toUpperCase()}</span>
                                    <span className="ml-2 font-semibold">{pos.asset}</span>
                                </div>
                                <span className="hidden sm:inline text-right">{pos.amount.toFixed(2)}$</span>
                                <span className="hidden sm:inline text-right text-muted-foreground">{pos.entryPrice.toFixed(2)}</span>
                                <span className={`${pos.pnl >= 0 ? 'text-green-400' : 'text-red-400'} text-right`}>{pos.pnl.toFixed(2)}$</span>
                                <Button size="sm" variant="destructive" onClick={() => closePosition(pos.id)} className="w-full sm:w-auto">Cerrar</Button>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </motion.div>
    );
};

export default TradingCampus;