import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Link as LinkIcon, Copy, Check, DollarSign, Users, BarChart2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const StatCard = ({ icon, title, value, color }) => (
    <div className="glass-effect p-4 rounded-lg flex items-center space-x-4">
        <div className={`p-3 rounded-full bg-${color}-500/20 text-${color}-400`}>
            {icon}
        </div>
        <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-xl font-bold">{value}</p>
        </div>
    </div>
);

const AffiliateCampus = () => {
    const navigate = useNavigate();
    const { user } = useAuth();
    const [copied, setCopied] = useState(false);

    // This would be fetched from the backend
    const affiliateCode = `BOOST${user?.id.substring(0, 6).toUpperCase()}`;
    const affiliateLink = `https://sergicp.app/join?ref=${affiliateCode}`;

    const handleCopy = () => {
        navigator.clipboard.writeText(affiliateLink);
        setCopied(true);
        toast({ title: "¡Enlace copiado!" });
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => navigate('/finance')}>
                    <ArrowLeft />
                </Button>
                <div>
                    <h2 className="text-2xl font-bold">Campus de Afiliados</h2>
                    <p className="text-muted-foreground">Genera ingresos pasivos con tu influencia.</p>
                </div>
            </div>

            <div className="glass-effect p-6 rounded-lg space-y-4">
                <h3 className="font-bold text-lg">Tu Enlace de Afiliado Único</h3>
                <div className="flex flex-col sm:flex-row items-stretch gap-2 p-2 bg-background rounded-md">
                   <div className="flex-grow p-2 text-sm text-primary font-mono truncate">{affiliateLink}</div>
                    <Button onClick={handleCopy} className="w-full sm:w-auto">
                        {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                        {copied ? 'Copiado' : 'Copiar'}
                    </Button>
                </div>
                 <p className="text-xs text-muted-foreground">Comparte este enlace. Ganarás una comisión por cada nuevo miembro PRO que se una a través de él.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard icon={<DollarSign/>} title="Ganancias Totales" value="$0.00" color="green" />
                <StatCard icon={<Users/>} title="Referidos Totales" value="0" color="blue" />
                <StatCard icon={<LinkIcon/>} title="Clicks (30d)" value="0" color="purple" />
                <StatCard icon={<BarChart2/>} title="Tasa Conversión" value="0%" color="amber" />
            </div>

            <div className="glass-effect p-6 rounded-lg">
                <h3 className="font-bold text-lg mb-4">Tus Referidos Recientes</h3>
                <div className="text-center py-8 text-muted-foreground">
                    <p>Cuando tus referidos se unan, aparecerán aquí.</p>
                </div>
            </div>

        </motion.div>
    );
};

export default AffiliateCampus;