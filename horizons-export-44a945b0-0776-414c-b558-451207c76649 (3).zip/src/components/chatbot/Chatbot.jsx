import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Bot } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Chatbot = ({ onClose, user }) => {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');
    const messagesEndRef = useRef(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages]);

    useEffect(() => {
        setMessages([
            { from: 'bot', text: `¡Hola ${user.name}! Soy tu asistente de coaching. Estoy aquí para ayudarte a conseguir tus objetivos. ¿En qué te puedo ayudar hoy?` }
        ]);
    }, [user.name]);

    const handleSend = () => {
        if (input.trim() === '') return;

        const userMessage = { from: 'user', text: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');

        setTimeout(() => {
            const botResponse = { from: 'bot', text: "Esa es una gran pregunta. Ahora mismo estoy aprendiendo, pero pronto podré ayudarte con tus objetivos, analizar tu progreso y darte consejos personalizados. ¡Sigue entrenando duro!" };
            setMessages(prev => [...prev, botResponse]);
        }, 1000);
    };

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-end justify-center md:items-center">
            <motion.div
                initial={{ y: "100%", opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: "100%", opacity: 0 }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                className="w-full max-w-lg h-[80vh] md:h-[70vh] bg-card rounded-t-2xl md:rounded-2xl flex flex-col"
            >
                <header className="p-4 border-b border-border flex justify-between items-center">
                    <div className="flex items-center gap-3">
                        <Bot className="text-primary" />
                        <h2 className="font-bold text-lg">Asistente de Coaching</h2>
                    </div>
                    <Button variant="ghost" size="icon" onClick={onClose}><X /></Button>
                </header>

                <div className="flex-1 p-4 overflow-y-auto space-y-4">
                    <AnimatePresence>
                        {messages.map((msg, index) => (
                            <motion.div
                                key={index}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                className={`flex items-end gap-2 ${msg.from === 'user' ? 'justify-end' : 'justify-start'}`}
                            >
                                {msg.from === 'bot' && <div className="w-8 h-8 rounded-full bg-primary flex-shrink-0 flex items-center justify-center"><Bot className="w-5 h-5 text-primary-foreground"/></div>}
                                <div className={`max-w-xs md:max-w-md px-4 py-2 rounded-2xl ${msg.from === 'user' ? 'bg-primary text-primary-foreground rounded-br-none' : 'bg-secondary rounded-bl-none'}`}>
                                    <p className="text-sm">{msg.text}</p>
                                </div>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                    <div ref={messagesEndRef} />
                </div>

                <footer className="p-4 border-t border-border">
                    <div className="flex items-center gap-2">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                            placeholder="Escribe tu mensaje..."
                            className="w-full bg-input rounded-full px-4 py-2 border-none focus:ring-2 focus:ring-primary"
                        />
                        <Button onClick={handleSend} size="icon" className="rounded-full flex-shrink-0">
                            <Send className="w-5 h-5" />
                        </Button>
                    </div>
                </footer>
            </motion.div>
        </div>
    );
};

export default Chatbot;