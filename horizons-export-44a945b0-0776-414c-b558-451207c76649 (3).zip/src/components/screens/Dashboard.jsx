import React, { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, Dumbbell, Apple, BrainCircuit, Activity, ArrowLeft, ArrowRight, Heart, CircleDot as DumbbellIcon, Clock, Rocket, Trophy, Calendar, Star, BookOpen, BarChart2, Beef, Wheat, Droplet, Flame, ChevronRight } from 'lucide-react';
import { CircularProgressbarWithChildren, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import { Button } from '@/components/ui/button';
import { getStreakData, getNutritionProfile, getMealsForDate, getMealItems, saveDailyMood, getWorkouts, getTodaysMood, getBoostChallengeStatus, getBoostedDay, getUserPRs } from '@/lib/database';
import { getUserProgress } from '@/lib/gamification';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useNavigate } from 'react-router-dom';
import MoodTracker from '@/components/common/MoodTracker';
import { toast } from '@/components/ui/use-toast';
import { getAnalyticsData } from '@/lib/analytics';
import LoadingScreen from '@/components/common/LoadingScreen';
import UserGuideModal from '@/components/common/UserGuideModal';

const PerformanceIndexWidget = ({ userId }) => {
    const [score, setScore] = useState(0);

    useEffect(() => {
        if(!userId) return;
        const moodData = JSON.parse(localStorage.getItem(`mood_tracker_${userId}`) || '{}');
        const todayStr = new Date().toISOString().split('T')[0];
        const todayMood = moodData[todayStr] || 3; 
        
        const streakData = getStreakData(userId);
        const streakBonus = Math.min(streakData.current_streak / 7, 1); 

        const lastWorkout = getWorkouts(userId).filter(w => w.status === 'done').sort((a,b) => new Date(b.date) - new Date(a.date))[0];
        let workoutImpact = 0;
        if(lastWorkout) {
            const daysSince = (new Date() - new Date(lastWorkout.date)) / (1000 * 3600 * 24);
            if(daysSince <= 1) workoutImpact = 0.2; 
            if(daysSince > 3) workoutImpact = -0.1; 
        }

        const calculatedScore = ((todayMood / 5) * 0.6 + streakBonus * 0.2 + 0.2 + workoutImpact) * 100;
        setScore(Math.max(0, Math.min(100, Math.round(calculatedScore))));

    }, [userId]);

    return (
        <div className="glass-effect rounded-2xl p-6 flex flex-col justify-between h-full">
            <div>
                <h3 className="text-2xl font-bold flex items-center gap-2"><Activity className="text-[var(--neon-yellow)]"/> Rendimiento</h3>
                <p className="text-sm text-muted-foreground">Tu estado diario.</p>
            </div>
            <div className="relative w-40 h-40 mx-auto my-6">
                <CircularProgressbarWithChildren
                    value={score}
                    strokeWidth={10}
                    styles={buildStyles({
                        pathColor: 'var(--neon-yellow)',
                        trailColor: 'rgba(255,255,255,0.05)',
                        strokeLinecap: 'round'
                    })}
                >
                    <div className="text-center">
                        <p className="text-4xl font-black text-[var(--text-main)]">{score}</p>
                        <p className="text-xs font-bold text-muted-foreground uppercase">PUNTOS</p>
                    </div>
                </CircularProgressbarWithChildren>
            </div>
            <p className="text-center text-xs text-muted-foreground">Combina energía, racha y último entreno.</p>
        </div>
    )
}

const MuscleFocusWidget = ({ userId }) => {
    const muscleGroups = useMemo(() => {
        if(!userId) return {};
        const analytics = getAnalyticsData(userId, 14); 
        return analytics.training?.volumeByMuscleGroup || {};
    }, [userId]);

    const totalVolume = Object.values(muscleGroups).reduce((sum, val) => sum + val, 0);
    const getIntensity = (group) => totalVolume > 0 ? (muscleGroups[group] || 0) / totalVolume : 0;

    const bodyParts = [
        { name: 'Pecho', key: 'pecho', intensity: getIntensity('pecho') },
        { name: 'Espalda', key: 'espalda', intensity: getIntensity('espalda') },
        { name: 'Hombros', key: 'hombros', intensity: getIntensity('hombros') },
        { name: 'Bíceps', key: 'biceps', intensity: getIntensity('biceps') },
        { name: 'Tríceps', key: 'triceps', intensity: getIntensity('triceps') },
        { name: 'Piernas', key: 'piernas', intensity: getIntensity('piernas') },
    ];
    
    return (
        <div className="glass-effect rounded-2xl p-6">
            <h3 className="text-2xl font-bold flex items-center gap-2"><BrainCircuit className="text-[var(--neon-yellow)]"/> Foco Muscular</h3>
            <p className="text-sm text-muted-foreground mb-6">Últimos 14 días.</p>
            <div className="space-y-3">
                {bodyParts.map(part => (
                    <div key={part.key}>
                        <div className="flex justify-between items-center text-xs mb-1 font-bold">
                            <span className="uppercase tracking-wider">{part.name}</span>
                            <span className="text-[var(--neon-yellow)]">{Math.round(part.intensity * 100)}%</span>
                        </div>
                        <div className="w-full bg-[var(--bg-inset)] h-2 rounded-full overflow-hidden shadow-[inset_2px_2px_4px_rgba(0,0,0,0.2)]">
                             <motion.div 
                                className="h-2 bg-[var(--neon-yellow)] rounded-full"
                                initial={{ width: 0 }}
                                animate={{ width: `${part.intensity * 100}%` }}
                                transition={{ duration: 0.5, ease: 'easeOut' }}
                             />
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}

const ExerciseHistoryWidget = ({ userId }) => {
    const [prs, setPrs] = useState([]);
    const [bestDay, setBestDay] = useState(null);

    useEffect(() => {
        if (userId) {
            const userPrs = getUserPRs(userId);
            const uniquePrs = [];
            const seenExercises = new Set();
            
            [...userPrs].sort((a, b) => new Date(b.date) - new Date(a.date)).forEach(pr => {
                if (!seenExercises.has(pr.exerciseId)) {
                    seenExercises.add(pr.exerciseId);
                    uniquePrs.push(pr);
                }
            });
            setPrs(uniquePrs.slice(0, 5));

            const workouts = getWorkouts(userId).filter(w => w.status === 'done');
            if (workouts.length > 0) {
                const best = workouts.reduce((prev, current) => (prev.tonnage_total > current.tonnage_total) ? prev : current);
                setBestDay(best);
            }
        }
    }, [userId]);

    return (
        <div className="glass-effect rounded-2xl p-6">
            <h3 className="text-xl font-bold flex items-center gap-2 mb-2 text-[var(--neon-yellow)]">
                <Trophy className="w-5 h-5" /> Historial de Hitos
            </h3>
            <p className="text-sm text-muted-foreground mb-6">Tus mejores marcas y días legendarios.</p>

            <div className="space-y-4">
                {bestDay && (
                    <div className="bg-[var(--bg-surface)] p-3 rounded-xl border border-[var(--neon-yellow)]/20 relative overflow-hidden">
                        <div className="absolute top-0 right-0 bg-[var(--neon-yellow)] text-black text-[10px] font-bold px-2 py-0.5 rounded-bl-lg">
                            MEJOR SESIÓN
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-[var(--neon-yellow)]/10 rounded-lg">
                                <Calendar className="w-5 h-5 text-[var(--neon-yellow)]" />
                            </div>
                            <div>
                                <p className="text-xs text-muted-foreground font-bold uppercase">Mayor Volumen</p>
                                <p className="text-sm font-bold text-white">{(bestDay.tonnage_total / 1000).toFixed(1)}k kg totales</p>
                                <p className="text-[10px] text-muted-foreground">{new Date(bestDay.date).toLocaleDateString()}</p>
                            </div>
                        </div>
                    </div>
                )}

                <div className="space-y-2">
                    <p className="text-xs font-bold uppercase text-muted-foreground tracking-wider mb-2">Récords Personales (PRs)</p>
                    {prs.length > 0 ? (
                        prs.map(pr => (
                            <div key={pr.id} className="flex justify-between items-center p-2 rounded-lg hover:bg-[var(--bg-surface)] transition-colors border-b border-white/5 last:border-0">
                                <div className="flex-1 min-w-0 pr-2">
                                    <p className="text-sm font-bold truncate">{pr.exerciseName}</p>
                                    <p className="text-[10px] text-muted-foreground">{new Date(pr.date).toLocaleDateString()}</p>
                                </div>
                                <div className="flex items-center gap-1 bg-[var(--bg-surface)] px-2 py-1 rounded border border-white/10">
                                    <Star className="w-3 h-3 text-[var(--neon-yellow)]" />
                                    <span className="text-xs font-black">{pr.value} {pr.type === 'reps' ? 'reps' : 'kg'}</span>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="text-center py-4 text-muted-foreground text-xs">
                            Aún no hay récords registrados. ¡A entrenar!
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const WorkoutCalendarDashboard = ({ userId, boostedDay, selectedLevel, challengeStatus }) => {
    const navigate = useNavigate();
    const [currentDate, setCurrentDate] = useState(new Date());
    const [pageOffset, setPageOffset] = useState(0);

    const workoutProgram = useMemo(() => {
        if (challengeStatus?.isActive) {
            return ['Push 1', 'Pull 1', 'Legs 1', 'Rest', 'Push 2', 'Pull 2', 'Legs 2']; 
        }
        if (!selectedLevel) return null;
        const programs = {
            beginner:     ['Push', 'Pull', 'Legs', 'Cardio', 'Push', 'Pull', 'Rest'],
            intermediate: ['Pecho & Tríceps', 'Espalda & Bíceps', 'Piernas', 'Hombros & Brazos', 'Full Body', 'Cardio', 'Rest'],
            advanced:     ['Push 1', 'Pull 1', 'Legs 1', 'Push 2', 'Pull 2', 'Legs 2', 'Rest'],
        };
        return programs[selectedLevel];
    }, [selectedLevel, challengeStatus]);

    const getDayInfo = useMemo(() => (date) => {
        if (!workoutProgram) return { type: 'Rest', icon: null, activityName: 'Descanso' };
        const dayOfWeek = date.getDay() === 0 ? 6 : date.getDay() - 1;
        const activity = workoutProgram[dayOfWeek % 7];
        
        if (activity.toLowerCase().includes('cardio')) {
            return { type: 'Cardio', icon: <Heart className="w-5 h-5" />, activityName: 'Cardio' };
        } else if (activity.toLowerCase().includes('rest')) {
            return { type: 'Rest', icon: null, activityName: 'Descanso' };
        } else {
            return { type: 'Workout', icon: <DumbbellIcon className="w-5 h-5" />, activityName: activity };
        }
    }, [workoutProgram]);

    const handleDateChange = (days) => {
        setPageOffset(prev => prev + days);
    };
    
    const planTitle = useMemo(() => {
        if (challengeStatus?.isActive) {
            return `Reto Boost`;
        }
        return selectedLevel || 'Plan Personal';
    }, [challengeStatus, selectedLevel]);

    const goToSessionPrep = (date, dayType) => {
        const levelForPath = challengeStatus?.isActive ? 'advanced' : selectedLevel;
        if (dayType === 'Workout' && levelForPath) {
            navigate(`/session-prep/${date.toISOString().split('T')[0]}/${levelForPath}`);
        } else if (dayType === 'Workout' && !levelForPath) {
            toast({
                title: "Selecciona un plan",
                description: "Por favor, elige tu intensidad de entrenamiento en la sección 'Boost' primero.",
                variant: "default",
            });
        } else {
             toast({
                title: `Día de ${dayType}`,
                description: `¡Hoy toca ${dayType === 'Cardio' ? 'sudar' : 'recuperar'}!`,
            });
        }
    };

    const days = useMemo(() => Array.from({ length: 14 }).map((_, i) => {
        const date = new Date(currentDate);
        date.setDate(currentDate.getDate() + i + pageOffset);
        return date;
    }), [currentDate, pageOffset]);

    if (!selectedLevel && !challengeStatus?.isActive) {
        return (
            <div className="glass-effect rounded-2xl p-6 text-center">
                <h3 className="text-2xl font-bold mb-2">Calendario</h3>
                <p className="text-muted-foreground mb-4">Selecciona tu nivel para ver tu plan.</p>
                <Button onClick={() => navigate('/boost')} className="btn-primary">
                    Ir a Boost
                </Button>
            </div>
        );
    }

    return (
        <motion.div 
            className="glass-effect rounded-2xl p-6 relative mt-6 overflow-allow" 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
        >
             {challengeStatus?.isActive && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-[var(--neon-yellow)] text-black font-black text-xs px-6 py-1.5 rounded-full shadow-[0_0_15px_rgba(255,214,0,0.5)] z-20 whitespace-nowrap">
                    RETO SEMANA {challengeStatus.currentWeek}
                </div>
            )}

            <div className="flex justify-between items-center mb-6 pt-2">
                <div>
                    <h3 className="text-2xl font-bold text-[var(--neon-yellow)] capitalize">{planTitle}</h3>
                    <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider">Plan Semanal</p>
                </div>
                <div className="flex gap-2">
                    <Button variant="ghost" size="icon" onClick={() => handleDateChange(-7)} className="h-8 w-8 rounded-full bg-[var(--bg-surface)] shadow-[var(--shadow-active)] hover:text-[var(--neon-yellow)]"><ArrowLeft className="w-4 h-4" /></Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDateChange(7)} className="h-8 w-8 rounded-full bg-[var(--bg-surface)] shadow-[var(--shadow-active)] hover:text-[var(--neon-yellow)]"><ArrowRight className="w-4 h-4" /></Button>
                </div>
            </div>

            <div className="flex overflow-x-auto space-x-4 pb-4 -mx-2 px-2 scrollbar-hide">
                {days.map((date, index) => {
                    const dayOfWeek = date.toLocaleDateString('es-ES', { weekday: 'short' }).toUpperCase();
                    const dayOfMonth = date.getDate();
                    const dayInfo = getDayInfo(date);
                    const today = new Date();
                    const isToday = date.toDateString() === today.toDateString();
                    const isBoosted = boostedDay?.date === date.toISOString().split('T')[0];

                    return (
                        <motion.div
                            key={index}
                            onClick={() => goToSessionPrep(date, dayInfo.type)}
                            className={`relative flex-shrink-0 w-20 h-28 rounded-xl flex flex-col items-center justify-center cursor-pointer transition-all duration-300
                                ${isToday 
                                    ? 'bg-[var(--neon-yellow)] text-black shadow-[0_0_15px_rgba(255,214,0,0.4)] scale-105 z-10' 
                                    : 'bg-[var(--bg-surface)] shadow-[var(--shadow-light),var(--shadow-dark)] hover:text-[var(--neon-yellow)]'
                                }
                                ${dayInfo.type === 'Rest' ? 'opacity-50' : ''}
                                ${isBoosted ? 'border-2 border-[var(--neon-yellow)]' : ''}
                            `}
                            whileTap={{ scale: 0.95 }}
                        >
                            {isBoosted && <Rocket className="absolute top-1 right-1 w-3 h-3 text-[var(--neon-yellow)]" />}
                            <p className={`text-[10px] font-black tracking-widest mb-1 ${isToday ? 'text-black' : 'text-muted-foreground'}`}>{dayOfWeek}</p>
                            <p className="text-2xl font-black mb-2">{dayOfMonth}</p>
                            <div className="text-xs">
                                {dayInfo.type === 'Rest' ? <Clock className="w-4 h-4" /> : dayInfo.icon}
                            </div>
                        </motion.div>
                    );
                })}
            </div>
        </motion.div>
    );
};

const QuickActionsWidget = () => {
    const navigate = useNavigate();
    const actions = [
        { label: "Entrenar", icon: Dumbbell, path: "/boost" },
        { label: "Comida", icon: Apple, path: "/boost", state: { tab: 'nutrition' } },
    ];
    return (
        <div className="glass-effect p-6 rounded-2xl">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2 text-[var(--neon-yellow)]"><Zap className="w-5 h-5"/> Acciones Rápidas</h3>
            <div className="grid grid-cols-2 gap-4">
                {actions.map((action, i) => (
                     <motion.button 
                        key={i}
                        onClick={() => navigate(action.path, { state: action.state })}
                        className="p-4 rounded-xl bg-[var(--bg-surface)] shadow-[var(--shadow-light),var(--shadow-dark)] active:shadow-[var(--shadow-active)] flex flex-col items-center justify-center transition-all group"
                     >
                        <div className="w-10 h-10 rounded-full bg-[var(--bg-inset)] flex items-center justify-center shadow-[var(--shadow-active)] mb-2 group-hover:text-[var(--neon-yellow)] transition-colors">
                             <action.icon className="w-5 h-5" />
                        </div>
                        <span className="text-xs font-bold uppercase tracking-wide">{action.label}</span>
                    </motion.button>
                ))}
            </div>
        </div>
    );
};

const DailyMacrosWidget = ({ nutritionData }) => {
    const navigate = useNavigate();

    if (!nutritionData.profile) {
        return (
            <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }}
                className="relative overflow-hidden rounded-3xl p-6 bg-gradient-to-br from-[#1A1B1E] to-[#0A0A0A] border border-white/5 flex flex-col justify-center items-center text-center shadow-xl group cursor-pointer"
                onClick={() => navigate('/nutrition')}
            >
                 <div className="absolute inset-0 bg-gradient-to-b from-[var(--neon-yellow)]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                 <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                    <Apple className="w-8 h-8 text-white/40 group-hover:text-[var(--neon-yellow)] transition-colors" />
                 </div>
                 <h3 className="text-xl font-black text-white mb-2">Sin Datos</h3>
                 <p className="text-xs font-medium text-gray-400">Configura tu plan nutricional para ver tus métricas.</p>
                 <Button variant="ghost" className="mt-4 text-[var(--neon-yellow)] hover:text-white hover:bg-white/5">
                    Configurar Ahora <ChevronRight className="w-4 h-4 ml-1" />
                 </Button>
            </motion.div>
        );
    }

    const { kcal, protein, carbs, fat } = nutritionData.totals;
    const { kcal_objetivo, p_gramos, c_gramos, g_gramos } = nutritionData.profile;
    const percentage = kcal_objetivo > 0 ? (kcal / kcal_objetivo) * 100 : 0;

    const macros = [
        { 
            label: 'Proteínas', 
            value: protein, 
            target: p_gramos, 
            unit: 'g', 
            icon: Beef, 
            color: '#22d3ee', // Cyan
            gradient: 'from-cyan-500 to-blue-600',
            bg: 'bg-cyan-500/10'
        },
        { 
            label: 'Carbos', 
            value: carbs, 
            target: c_gramos, 
            unit: 'g', 
            icon: Wheat, 
            color: '#d946ef', // Fuchsia
            gradient: 'from-fuchsia-500 to-purple-600',
            bg: 'bg-fuchsia-500/10'
        },
        { 
            label: 'Grasas', 
            value: fat, 
            target: g_gramos, 
            unit: 'g', 
            icon: Droplet, 
            color: '#f59e0b', // Amber
            gradient: 'from-amber-400 to-orange-600',
            bg: 'bg-amber-500/10'
        },
    ];

    return (
        <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-[#1E1F22] to-[#121315] border border-white/5 p-6 shadow-2xl"
        >
            {/* Header & Main Stats */}
            <div className="flex justify-between items-start mb-6 relative z-10">
                <div>
                    <div className="flex items-center gap-2 mb-1">
                        <div className="p-1.5 rounded-md bg-gradient-to-br from-red-500 to-orange-600 shadow-lg shadow-orange-500/20">
                            <Flame className="w-4 h-4 text-white" fill="white" />
                        </div>
                        <h3 className="text-sm font-black uppercase tracking-wider text-gray-400">Energía Diaria</h3>
                    </div>
                    <div className="flex items-baseline gap-1 mt-2">
                        <span className="text-4xl lg:text-5xl font-black text-white tracking-tighter drop-shadow-sm">
                            {Math.round(kcal)}
                        </span>
                        <span className="text-sm font-bold text-gray-500">/ {kcal_objetivo} kcal</span>
                    </div>
                </div>
                
                {/* Circular Progress (Mini) */}
                <div className="w-16 h-16 relative">
                     <svg className="w-full h-full transform -rotate-90">
                        <circle cx="32" cy="32" r="28" stroke="currentColor" strokeWidth="6" fill="transparent" className="text-white/5" />
                        <circle 
                            cx="32" cy="32" r="28" stroke="url(#gradient-kcal)" strokeWidth="6" fill="transparent" strokeLinecap="round" 
                            className="text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.3)] transition-all duration-1000 ease-out"
                            strokeDasharray={175}
                            strokeDashoffset={175 - (Math.min(percentage, 100) / 100) * 175}
                        />
                         <defs>
                            <linearGradient id="gradient-kcal" x1="0%" y1="0%" x2="100%" y2="0%">
                                <stop offset="0%" stopColor="#ef4444" />
                                <stop offset="100%" stopColor="#f59e0b" />
                            </linearGradient>
                        </defs>
                     </svg>
                     <div className="absolute inset-0 flex items-center justify-center">
                         <span className="text-[10px] font-bold text-white">{Math.round(percentage)}%</span>
                     </div>
                </div>
            </div>

            {/* Macros Grid */}
            <div className="grid grid-cols-1 gap-4 relative z-10">
                {macros.map((macro, i) => {
                    const percent = Math.min((macro.value / (macro.target || 1)) * 100, 100);
                    return (
                        <motion.div 
                            key={macro.label}
                            initial={{ x: -20, opacity: 0 }}
                            animate={{ x: 0, opacity: 1 }}
                            transition={{ delay: i * 0.1 }}
                            className={`relative rounded-xl p-3 border border-white/5 ${macro.bg} group hover:border-white/10 transition-colors`}
                        >
                            <div className="flex justify-between items-center mb-2">
                                <div className="flex items-center gap-3">
                                    <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${macro.gradient} flex items-center justify-center shadow-lg`}>
                                        <macro.icon className="w-4 h-4 text-white" />
                                    </div>
                                    <div>
                                        <p className="text-xs font-bold text-gray-400 uppercase tracking-wide">{macro.label}</p>
                                        <p className="text-lg font-black text-white leading-none mt-0.5">
                                            {Math.round(macro.value)} <span className="text-xs text-gray-500 font-bold">/ {macro.target}g</span>
                                        </p>
                                    </div>
                                </div>
                                <span className="text-xs font-bold" style={{ color: macro.color }}>{Math.round(percent)}%</span>
                            </div>

                            {/* Progress Bar */}
                            <div className="w-full h-1.5 bg-black/40 rounded-full overflow-hidden">
                                <motion.div 
                                    className={`h-full rounded-full bg-gradient-to-r ${macro.gradient}`}
                                    initial={{ width: 0 }}
                                    animate={{ width: `${percent}%` }}
                                    transition={{ duration: 1, ease: "easeOut", delay: 0.2 + (i * 0.1) }}
                                    style={{ boxShadow: `0 0 10px ${macro.color}40` }}
                                />
                            </div>
                        </motion.div>
                    );
                })}
            </div>

            {/* Background Effects */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-b from-[var(--neon-yellow)]/5 to-transparent blur-[80px] rounded-full pointer-events-none -translate-y-1/2 translate-x-1/2" />
        </motion.div>
    );
};

const UserGuideBanner = ({ onClick }) => (
    <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        onClick={onClick}
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.99 }}
        className="relative w-full h-16 md:h-20 rounded-xl overflow-hidden cursor-pointer border border-[#FF10F0]/50 shadow-[0_0_20px_rgba(255,16,240,0.2)] group mb-8 flex items-center"
    >
        <img 
            src="https://sergiconstance-9fn0dyoiqm.live-website.com/wp-content/uploads/2025/11/ShottingAtlas-157-scaled.jpg" 
            alt="User Guide Banner"
            className="absolute inset-0 w-full h-full object-cover opacity-40 group-hover:opacity-60 transition-opacity"
            style={{ objectPosition: '50% 25%' }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent" />
        
        <div className="relative z-10 flex items-center justify-between w-full px-6">
            <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-[#FF10F0]/20 flex items-center justify-center border border-[#FF10F0]/50 shadow-[0_0_10px_rgba(255,16,240,0.4)]">
                    <BookOpen className="w-5 h-5 text-[#FF10F0]" />
                </div>
                <div>
                    <h3 className="text-lg md:text-xl font-black italic text-white leading-none flex items-center gap-2">
                        GUÍA DE INICIACIÓN
                    </h3>
                    <p className="text-[#FF10F0] font-bold text-[10px] md:text-xs uppercase tracking-widest">
                        Aprende a usar la App como un Leyenda
                    </p>
                </div>
            </div>
            
            <div className="hidden md:flex items-center gap-2 text-[#FF10F0] text-xs font-bold uppercase tracking-wider group-hover:translate-x-1 transition-transform">
                Ver Guía <ArrowRight className="w-4 h-4" />
            </div>
        </div>
    </motion.div>
);

const ProgramCluster = ({ programName, onClick, subText }) => (
    <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative w-full h-64 md:h-80 rounded-[2rem] overflow-hidden cursor-pointer group shadow-[0_10px_30px_rgba(0,0,0,0.5)] mb-8"
        onClick={onClick}
    >
        <img 
            src="https://sergiconstance-9fn0dyoiqm.live-website.com/wp-content/uploads/2025/12/ShottingAtlas-137-1-scaled.jpg" 
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 group-hover:brightness-110"
            alt="Program Background"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/95 via-black/60 to-transparent" />
        
        <div className="absolute inset-0 p-8 flex flex-col justify-center items-start z-10">
            <motion.div 
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="bg-[var(--neon-yellow)] text-black text-xs font-black px-3 py-1 rounded-full mb-4 uppercase tracking-widest shadow-[0_0_15px_rgba(255,214,0,0.6)]"
            >
                Programa Activo
            </motion.div>
            <h2 className="text-4xl md:text-5xl font-black text-white uppercase leading-none mb-2 drop-shadow-[0_4px_4px_rgba(0,0,0,0.8)] italic">
                {programName}
            </h2>
            <p className="text-gray-300 max-w-md text-sm md:text-base mb-6 font-medium drop-shadow-md">
                {subText || "Supera tus límites con el plan definitivo de hipertrofia y fuerza."}
            </p>
            <Button className="btn-primary">
                Continuar Entrenamiento <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
        </div>
    </motion.div>
);

const Dashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [dashboardData, setDashboardData] = useState({
    nutrition: { totals: { kcal: 0, protein: 0, carbs: 0, fat: 0 }, profile: null },
    programName: 'N/A',
    boostedDay: null,
    challengeStatus: { isActive: false, progress: { time: 0, workouts: 0, adherence: 0 } },
    selectedLevel: null,
  });
  const [loading, setLoading] = useState(true);
  const [showMoodTracker, setShowMoodTracker] = useState(false);
  const [showUserGuide, setShowUserGuide] = useState(false);

  useEffect(() => {
    if (!user) return;
    const loadData = async () => {
        setLoading(true);
        // Removed localstorage balance fetch, relying on MainLayout/Profile for gamification display
        
        const nutritionProfile = getNutritionProfile(user.id);
        const todaysMood = getTodaysMood(user.id);
        setShowMoodTracker(!todaysMood);
        const challengeStatus = getBoostChallengeStatus(user.id);
        
        let dailyTotals = { kcal: 0, protein: 0, carbs: 0, fat: 0 };
        if (nutritionProfile) {
           const dailyMeals = getMealsForDate(user.id, new Date());
           const allItems = dailyMeals.flatMap(meal => getMealItems(user.id, meal.id));
           dailyTotals = allItems.reduce((acc, item) => {
               acc.kcal += item.kcal_calc || 0;
               acc.protein += item.p_calc || 0;
               acc.carbs += item.c_calc || 0;
               acc.fat += item.g_calc || 0;
               return acc;
           }, { kcal: 0, protein: 0, carbs: 0, fat: 0 });
        }
        
        const storedLevel = localStorage.getItem(`workout_level_${user.id}`);
        const boostedDayData = getBoostedDay(user.id);
        
        setDashboardData({
          nutrition: { totals: dailyTotals, profile: nutritionProfile },
          programName: challengeStatus?.isActive ? 'Reto Boost' : (storedLevel ? storedLevel.charAt(0).toUpperCase() + storedLevel.slice(1) : 'No definido'),
          boostedDay: boostedDayData,
          challengeStatus: challengeStatus,
          selectedLevel: storedLevel,
        });
        setLoading(false);
    }
    loadData();
  }, [user]);

  const handleMoodSubmit = (rating) => {
      if(!user) return;
      saveDailyMood(user.id, rating);
      setShowMoodTracker(false);
      toast({title: "¡Energía registrada!", description: "¡Gracias! Tu panel se ha actualizado."});
  }

  if (loading) return <div className="fixed inset-0 flex items-center justify-center bg-[var(--bg-base)]"><LoadingScreen /></div>;

  const userName = user?.user_metadata?.full_name?.split(' ')[0] || 'Campeón';
  const { nutrition, programName, boostedDay, challengeStatus, selectedLevel } = dashboardData;

  return (
    <div className="pb-24">
      <header className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-4xl font-bold text-[var(--text-main)] tracking-tight">Hola, {userName}</h2>
          <p className="text-muted-foreground font-medium">Vamos a por todas hoy.</p>
        </div>
        <div className="w-12 h-12 rounded-full bg-[var(--bg-surface)] flex items-center justify-center shadow-[var(--shadow-dark),var(--shadow-light)]">
            <img src={`https://ui-avatars.com/api/?name=${userName}&background=FFD600&color=000000`} alt="Avatar" className="w-10 h-10 rounded-full" />
        </div>
      </header>

      {/* User Guide Banner - Positioned above Program Cluster */}
      <UserGuideBanner onClick={() => setShowUserGuide(true)} />

      {/* Full Width Program Cluster */}
      <ProgramCluster 
         programName={programName} 
         onClick={() => navigate('/boost')}
         subText={challengeStatus?.isActive ? `Semana ${challengeStatus.currentWeek} en curso. ¡Mantén la racha!` : undefined}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
                
                <WorkoutCalendarDashboard userId={user?.id} boostedDay={boostedDay} selectedLevel={selectedLevel} challengeStatus={challengeStatus} />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <PerformanceIndexWidget userId={user?.id} />
                    <MuscleFocusWidget userId={user?.id} />
                    <ExerciseHistoryWidget userId={user?.id} />
                </div>
            </div>

            <div className="space-y-6">
                <QuickActionsWidget />
                <AnimatePresence>
                    {showMoodTracker && <MoodTracker onMoodSubmit={handleMoodSubmit} />}
                </AnimatePresence>
                <DailyMacrosWidget nutritionData={nutrition} />
            </div>
       </div>
       
       <AnimatePresence>
          {showUserGuide && <UserGuideModal onClose={() => setShowUserGuide(false)} />}
       </AnimatePresence>
    </div>
  );
};

export default Dashboard;