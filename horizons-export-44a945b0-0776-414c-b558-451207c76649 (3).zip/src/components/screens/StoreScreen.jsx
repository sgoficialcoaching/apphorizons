import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ShoppingBag, Zap, Lock, CheckCircle2, Gift, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { SHOP_ITEMS, getUserProgress, purchaseItem } from '@/lib/gamification';
import LoadingScreen from '@/components/common/LoadingScreen';

const StoreScreen = () => {
  const { user } = useAuth();
  const [boosties, setBoosties] = useState(0);
  const [loading, setLoading] = useState(true);
  const [purchasingId, setPurchasingId] = useState(null);

  useEffect(() => {
    if (user) {
      loadBalance();
    }
  }, [user]);

  const loadBalance = async () => {
    const progress = await getUserProgress(user.id);
    setBoosties(progress?.boosties || 0);
    setLoading(false);
  };

  const handlePurchase = async (item) => {
    if (boosties < item.cost) {
      toast({
        title: "Saldo insuficiente",
        description: `Necesitas ${item.cost - boosties} Boosties más.`,
        variant: "destructive"
      });
      return;
    }

    setPurchasingId(item.id);
    try {
      await purchaseItem(user.id, item.cost);
      setBoosties(prev => prev - item.cost);
      toast({
        title: "¡Compra realizada!",
        description: `Has adquirido: ${item.name}`,
        variant: "default"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setPurchasingId(null);
    }
  };

  if (loading) return <LoadingScreen />;

  return (
    <div className="space-y-6 pb-24">
      <div className="relative overflow-hidden rounded-3xl bg-black border border-white/10 shadow-2xl p-6 md:p-10 mb-8">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[var(--neon-yellow)]/20 blur-[100px] rounded-full pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h1 className="text-3xl md:text-4xl font-black text-white uppercase italic tracking-tighter">
              Tienda <span className="text-[var(--neon-yellow)]">Boost</span>
            </h1>
            <p className="text-gray-400 mt-2 max-w-md">
              Intercambia tus Boosties ganados con esfuerzo por recompensas exclusivas, rutinas y equipamiento.
            </p>
          </div>
          <div className="bg-white/5 backdrop-blur-md rounded-2xl p-4 border border-white/10 flex items-center gap-4 min-w-[200px]">
             <div className="w-12 h-12 rounded-full bg-[var(--neon-yellow)] flex items-center justify-center shadow-[0_0_15px_rgba(255,214,0,0.5)]">
                <Zap className="w-6 h-6 text-black fill-black" />
             </div>
             <div>
                <p className="text-xs text-gray-400 font-bold uppercase tracking-wider">Tu Saldo</p>
                <p className="text-2xl font-black text-white">{boosties}</p>
             </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {SHOP_ITEMS.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="group relative bg-[#1E1F22] rounded-2xl border border-white/5 overflow-hidden hover:border-[var(--neon-yellow)]/50 transition-all duration-300 hover:shadow-[0_0_20px_rgba(0,0,0,0.5)]"
          >
             <div className="h-40 overflow-hidden relative">
                <img src={item.image} alt={item.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 opacity-80 group-hover:opacity-100" />
                <div className="absolute top-3 right-3 bg-black/80 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-white border border-white/10">
                   {item.type.toUpperCase()}
                </div>
             </div>
             
             <div className="p-5">
                <h3 className="text-xl font-bold text-white mb-2 line-clamp-1">{item.name}</h3>
                <p className="text-sm text-gray-400 mb-4 line-clamp-2 h-10">{item.description}</p>
                
                <div className="flex items-center justify-between mt-4">
                   <div className="flex items-center gap-2 text-[var(--neon-yellow)]">
                      <Zap className="w-4 h-4 fill-[var(--neon-yellow)]" />
                      <span className="font-bold text-lg">{item.cost}</span>
                   </div>
                   
                   <Button 
                      onClick={() => handlePurchase(item)}
                      disabled={purchasingId === item.id || boosties < item.cost}
                      className={`
                        ${boosties >= item.cost 
                           ? 'bg-white text-black hover:bg-[var(--neon-yellow)] hover:scale-105' 
                           : 'bg-white/10 text-gray-500 cursor-not-allowed'}
                         transition-all font-bold rounded-xl
                      `}
                   >
                      {purchasingId === item.id ? (
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current" />
                      ) : boosties >= item.cost ? (
                         'Comprar'
                      ) : (
                         <Lock className="w-4 h-4" />
                      )}
                   </Button>
                </div>
             </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default StoreScreen;