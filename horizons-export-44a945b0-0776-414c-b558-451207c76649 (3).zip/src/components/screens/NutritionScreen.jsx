import React, { useState, useEffect, useMemo, Suspense } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    Calendar, ChevronLeft, ChevronRight, Zap, TrendingUp, 
    Camera, Plus, Settings, Sparkles, AlertCircle, RefreshCw, ChefHat
} from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { 
    getNutritionProfile, getMealsForDate, addMeal, addMealItem, deleteMealItem, getMealItems, updateMeal
} from '@/lib/database';
import { getRecommendations, getProfessionalPlans } from '@/lib/nutritionLogic';

// Components
import NutritionSummaryCard from '@/components/nutrition/NutritionSummaryCard';
import MealCard from '@/components/nutrition/MealCard';
import FoodSearchModal from '@/components/nutrition/FoodSearchModal';
import NutritionSettings from '@/components/profile/NutritionSettings';
import SmartFridge from '@/components/nutrition/SmartFridge';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import AiScanScreen from '@/components/nutrition/AiScanScreen';
import PresetMenuSelector from '@/components/nutrition/PresetMenuSelector';

const NutritionScreen = () => {
    const { user } = useAuth();
    const [currentDate, setCurrentDate] = useState(new Date());
    const [profile, setProfile] = useState(null);
    const [meals, setMeals] = useState([]);
    
    // Initial state explicitly set to 0 to avoid uncontrolled/controlled issues
    const [dailyTotals, setDailyTotals] = useState({ kcal: 0, protein: 0, carbs: 0, fat: 0 });
    const [generatedPlans, setGeneratedPlans] = useState([]);
    
    // UI States
    const [view, setView] = useState('dashboard'); // dashboard, settings, scan, analysis
    const [isFoodModalOpen, setIsFoodModalOpen] = useState(false);
    const [isFridgeOpen, setIsFridgeOpen] = useState(false);
    const [isMenuSelectorOpen, setIsMenuSelectorOpen] = useState(false);
    const [activeMealId, setActiveMealId] = useState(null);
    const [isLoading, setIsLoading] = useState(true);

    // Fetch data
    const refreshData = async () => {
        if(!user) return;
        setIsLoading(true);
        const prof = getNutritionProfile(user.id);
        setProfile(prof);

        if (prof) {
            const plans = getProfessionalPlans(prof);
            setGeneratedPlans(plans);
        } else {
             const plans = getProfessionalPlans(null);
             setGeneratedPlans(plans);
        }

        const dateMeals = getMealsForDate(user.id, currentDate);
        
        // Enrich meals with calculated items
        const enrichedMeals = dateMeals.map(meal => {
            const items = getMealItems(user.id, meal.id);
            const calculatedItems = items.map(i => {
                const grams = parseFloat(i.gramos) || 0;
                
                const allFoods = JSON.parse(localStorage.getItem('foods') || '[]');
                const pantryFoods = JSON.parse(localStorage.getItem('pantry_items') || '[]'); 
                const food = allFoods.find(f => f.id === i.food_id) || pantryFoods.find(f => f.id === i.food_id);
                
                const k100 = food ? food.kcal_100g : (i.kcal_100g || 0);
                const p100 = food ? food.p_100g : (i.p_100g || 0);
                const c100 = food ? food.c_100g : (i.c_100g || 0);
                const f100 = food ? food.g_100g : (i.g_100g || 0);
                const itemName = food ? food.name : (i.name || 'Unknown Food');

                const k = (k100 * grams) / 100;
                const p = (p100 * grams) / 100;
                const c = (c100 * grams) / 100;
                const f = (f100 * grams) / 100;

                return { 
                    ...i, 
                    name: itemName,
                    total_kcal: k, 
                    total_p: p, 
                    total_c: c, 
                    total_f: f,
                    kcal_100g: k100, p_100g: p100, c_100g: c100, g_100g: f100 
                };
            });

            return { ...meal, items: calculatedItems };
        });

        // DEBUG: Calculate daily totals
        const totals = enrichedMeals.reduce((acc, m) => {
             // CRITICAL CHECK: is_completed must be strictly true
             if (m.is_completed === true) {
                 // 1. Add Base Meal Calories/Macros (if any)
                 if (m.kcal) acc.kcal += Number(m.kcal);
                 if (m.protein) acc.protein += Number(m.protein);
                 if (m.carbs) acc.carbs += Number(m.carbs);
                 if (m.fat) acc.fat += Number(m.fat);

                 // 2. Add Ingredient Calories/Macros
                 m.items.forEach(i => {
                     const k = i.total_kcal || 0;
                     acc.kcal += k;
                     acc.protein += i.total_p || 0;
                     acc.carbs += i.total_c || 0;
                     acc.fat += i.total_f || 0;
                 });
             }
             return acc;
        }, { kcal: 0, protein: 0, carbs: 0, fat: 0 });
        
        // console.log("DEBUG: Updated Daily Totals with Base + Items", totals);

        setMeals(enrichedMeals);
        
        // Ensure we are passing a NEW object reference to trigger React re-renders
        setDailyTotals({ ...totals }); 
        
        setIsLoading(false);
    };

    useEffect(() => {
        refreshData();
        
        const handleGlobalUpdate = () => {
             refreshData();
        };
        window.addEventListener('nutrition_updated', handleGlobalUpdate);
        return () => window.removeEventListener('nutrition_updated', handleGlobalUpdate);
    }, [user, currentDate, view]);

    // Handlers
    const handleDateChange = (days) => {
        const newDate = new Date(currentDate);
        newDate.setDate(newDate.getDate() + days);
        setCurrentDate(newDate);
    };

    const handleAddMeal = () => {
        addMeal(user.id, { 
            nombre: 'Nueva Comida', 
            fecha: currentDate.toISOString(),
            type: 'snack' 
        });
        refreshData();
        window.dispatchEvent(new Event('nutrition_updated'));
        toast({ title: 'Comida Añadida', className: "bg-[var(--neon-yellow)] text-black" });
    };

    const handleAddFood = (mealId) => {
        setActiveMealId(mealId);
        setIsFoodModalOpen(true);
    };

    const handleFoodSelect = (food, grams = 100) => {
        if (activeMealId) {
            addMealItem(user.id, activeMealId, { food_id: food.id, gramos: grams });
            setIsFoodModalOpen(false);
            setActiveMealId(null);
            refreshData();
            window.dispatchEvent(new Event('nutrition_updated'));
            toast({ title: 'Alimento Añadido', description: `${grams}g de ${food.name}` });
        }
    };

    const handleDeleteItem = (itemId) => {
        deleteMealItem(user.id, itemId);
        refreshData();
        window.dispatchEvent(new Event('nutrition_updated'));
    };

    const handleCompleteToggle = async (mealId, currentStatus) => {
        // 1. Determine new status
        const newStatus = !currentStatus;
        
        // 2. Perform DB update
        // We ensure we await this operation
        const updatedMeal = updateMeal(user.id, mealId, { is_completed: newStatus });
        
        if (!updatedMeal) {
            console.error("Failed to update meal in DB");
            return;
        }

        // console.log("DEBUG: Meal status updated in DB", updatedMeal.is_completed);

        // 3. Force UI refresh immediately
        // By calling refreshData, we re-fetch everything from local storage, recalculate totals
        // and update the state, which forces the SummaryCard to re-render.
        await refreshData();
        
        // 4. Notify other components
        window.dispatchEvent(new Event('nutrition_updated'));
    };
    
    const handleLoadCustomPlan = async (plan) => {
        setIsMenuSelectorOpen(false);
        const { deleteMealsForDate, addMeal, addMealItem } = await import('@/lib/database');
        
        deleteMealsForDate(user.id, currentDate);
        
        plan.meals.forEach(meal => {
            const newMeal = addMeal(user.id, {
                nombre: meal.name,
                dishName: meal.dishName,
                isRecipe: false,
                fecha: currentDate.toISOString(),
                type: meal.type
            });

            meal.items.forEach(item => {
                addMealItem(user.id, newMeal.id, {
                    food_id: item.id,
                    gramos: item.grams
                });
            });
        });

        await refreshData();
        window.dispatchEvent(new Event('nutrition_updated'));
        
        toast({ 
            title: "Plan Cargado", 
            description: "Tu menú ha sido actualizado correctamente.", 
            className: "bg-green-600 text-white border-none" 
        });
    };

    if (view === 'settings') {
        return <NutritionSettings user={user} profile={profile} onBack={() => setView('dashboard')} />;
    }

    if (view === 'scan') {
        return <AiScanScreen user={user} date={currentDate} onBack={() => setView('dashboard')} onAddFood={(f, g) => handleFoodSelect(f, g)} />;
    }

    const formattedDate = currentDate.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });
    const isToday = currentDate.toDateString() === new Date().toDateString();

    const targets = {
        calories: profile?.kcal_objetivo || 2500,
        protein: profile?.p_gramos || 180,
        carbs: profile?.c_gramos || 300,
        fat: profile?.g_gramos || 80
    };

    const recommendations = profile ? getRecommendations(profile.objetivo) : [];

    return (
        <div className="min-h-screen bg-black pb-32">
            <div className="sticky top-0 z-40 bg-black/80 backdrop-blur-xl border-b border-white/5 p-4">
                <div className="flex justify-between items-center mb-4">
                    <h1 className="text-xl font-black italic uppercase text-white flex items-center gap-2">
                        Nutrition <span className="text-[var(--neon-yellow)]">OS</span>
                    </h1>
                    <div className="flex gap-2">
                        <Button variant="ghost" size="icon" onClick={() => setView('settings')} className="text-gray-400 hover:text-white">
                            <Settings className="w-5 h-5" />
                        </Button>
                    </div>
                </div>
                
                <div className="flex items-center justify-between bg-white/5 p-2 rounded-full border border-white/10">
                    <Button variant="ghost" size="icon" onClick={() => handleDateChange(-1)} className="rounded-full h-8 w-8 hover:bg-white/10">
                        <ChevronLeft className="w-4 h-4" />
                    </Button>
                    <div className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-white">
                        <Calendar className="w-4 h-4 text-[var(--neon-yellow)]" />
                        {isToday ? "Hoy, " : ""}{formattedDate}
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => handleDateChange(1)} className="rounded-full h-8 w-8 hover:bg-white/10">
                        <ChevronRight className="w-4 h-4" />
                    </Button>
                </div>
            </div>

            <div className="p-4 space-y-6 max-w-3xl mx-auto">
                {/* Summary Card with explicit prop passing for totals */}
                <NutritionSummaryCard 
                    totals={dailyTotals} 
                    targets={targets} 
                    profile={profile || {}} 
                    onAdjustClick={() => setView('settings')} 
                />

                <div className="grid grid-cols-2 gap-3">
                     <Button 
                        onClick={() => setIsMenuSelectorOpen(true)}
                        className="col-span-2 bg-gradient-to-r from-yellow-600 to-orange-500 border-none text-white shadow-lg shadow-orange-900/20 font-black uppercase tracking-wider h-14"
                    >
                        <ChefHat className="mr-2 h-5 w-5" /> 
                        Cargar Menú Profesional
                    </Button>
                    <Button 
                        onClick={() => setView('scan')} 
                        variant="outline"
                        className="border-white/10 hover:border-blue-500 hover:bg-blue-500/10 text-gray-300 h-12"
                    >
                        <Camera className="mr-2 h-4 w-4 text-blue-500" /> Escáner IA
                    </Button>
                    <Button 
                        onClick={() => setIsFridgeOpen(true)}
                        variant="outline"
                        className="border-white/10 hover:border-purple-500 hover:bg-purple-500/10 text-gray-300 h-12"
                    >
                        <Sparkles className="mr-2 h-4 w-4 text-purple-500" /> Smart Fridge
                    </Button>
                </div>

                {profile && (
                    <motion.div initial={{opacity:0}} animate={{opacity:1}} className="bg-white/5 border border-white/10 rounded-2xl p-4">
                        <div className="flex items-center gap-2 mb-2 text-[var(--neon-yellow)] font-bold text-xs uppercase tracking-widest">
                            <Zap className="w-3 h-3" /> Smart Coach
                        </div>
                        <p className="text-sm text-gray-300 italic">"{recommendations[Math.floor(Math.random()*recommendations.length)]}"</p>
                    </motion.div>
                )}

                <div className="space-y-4">
                    {meals.length === 0 ? (
                        <div className="text-center py-12 opacity-50 border-2 border-dashed border-white/5 rounded-3xl">
                            <p className="mb-4 text-sm font-medium">No hay comidas registradas hoy.</p>
                            <Button variant="outline" onClick={handleAddMeal}>Crear Primera Comida</Button>
                        </div>
                    ) : (
                        meals.map((meal, idx) => (
                            <motion.div 
                                key={meal.id}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.1 }}
                            >
                                <MealCard 
                                    meal={meal} 
                                    items={meal.items} 
                                    onAddFood={handleAddFood} 
                                    onDeleteFood={handleDeleteItem} 
                                    onCompleteToggle={handleCompleteToggle} 
                                    userId={user.id}
                                />
                            </motion.div>
                        ))
                    )}
                </div>

                <Button onClick={handleAddMeal} variant="ghost" className="w-full border-2 border-dashed border-white/10 hover:border-[var(--neon-yellow)] hover:text-[var(--neon-yellow)] h-16 rounded-2xl">
                    <Plus className="mr-2 h-5 w-5" /> Añadir Bloque de Comida
                </Button>
            </div>

            <AnimatePresence>
                {isFoodModalOpen && (
                    <FoodSearchModal 
                        onClose={() => setIsFoodModalOpen(false)} 
                        onSelectFood={(f, g) => handleFoodSelect(f, g)} 
                    />
                )}
                {isMenuSelectorOpen && (
                    <PresetMenuSelector
                        onClose={() => setIsMenuSelectorOpen(false)}
                        onSelect={handleLoadCustomPlan}
                        plans={generatedPlans}
                    />
                )}
                {isFridgeOpen && (
                    <SmartFridge 
                        onClose={() => setIsFridgeOpen(false)}
                        onSelectFood={(f) => {
                            if (!activeMealId && meals.length > 0) handleFoodSelect(f, 100); 
                            else if(activeMealId) handleFoodSelect(f, 100);
                            else {
                                import('@/lib/database').then(({ addMeal }) => {
                                    const newMeal = addMeal(user.id, { nombre: 'Smart Snack', fecha: currentDate.toISOString(), type: 'snack' });
                                    handleFoodSelect(f, 100); 
                                    import('@/lib/database').then(({ addMealItem }) => {
                                         addMealItem(user.id, newMeal.id, { food_id: f.id, gramos: 100 });
                                         setIsFridgeOpen(false);
                                         refreshData();
                                         toast({ title: 'Smart Snack Creado', description: `${f.name} añadido.` });
                                    });
                                });
                            }
                        }}
                    />
                )}
            </AnimatePresence>
        </div>
    );
};

export default NutritionScreen;