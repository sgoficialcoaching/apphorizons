import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Zap, GraduationCap, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { getFeed, initializeCommunityData, checkCommunityDataHealth } from '@/lib/community';
import PostCard from '@/components/community/PostCard';
import CreatePostModal from '@/components/community/CreatePostModal';
import { toast } from '@/components/ui/use-toast';
import LoadingScreen from '@/components/common/LoadingScreen';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import BoostChat from '@/components/community/BoostChat';

const CommunityScreen = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [feed, setFeed] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeCommunity, setActiveCommunity] = useState('boost'); 
  const [isCreatePostOpen, setCreatePostOpen] = useState(false);

  const fetchFeed = useCallback(() => {
    if (activeCommunity === 'boost') {
        setLoading(false);
        return;
    }

    if (!user) {
        setLoading(false);
        return;
    }

    setLoading(true);
    try {
      if (!checkCommunityDataHealth()) {
        initializeCommunityData(true);
      }
      const feedData = getFeed(user.id, activeCommunity);
      setFeed(feedData);
    } catch (error) {
      console.error("Failed to fetch feed:", error);
      initializeCommunityData(true); 
      const feedData = getFeed(user.id, activeCommunity); 
      setFeed(feedData);
    } finally {
        setLoading(false);
    }
  }, [user, activeCommunity]);

  useEffect(() => {
    fetchFeed();
  }, [fetchFeed]);

  const handlePostCreated = () => {
    fetchFeed();
    setCreatePostOpen(false);
    toast({
      title: "¡Publicación Creada!",
      description: "Tu publicación ahora es visible en la comunidad.",
    });
  };

  const renderContent = () => {
    if (activeCommunity === 'boost') {
        return (
            <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="w-full h-full"
            >
               {user ? (
                   <BoostChat />
               ) : (
                    <div className="text-center py-16 glass-effect rounded-xl border border-white/10 bg-black/40">
                       <p className="text-muted-foreground mb-4">Inicia sesión para acceder al chat exclusivo.</p>
                       <Button onClick={() => navigate('/')} variant="default">Iniciar Sesión</Button>
                    </div>
               )}
            </motion.div>
        );
    }

    if (loading) return <LoadingScreen />;

    if (!user) {
      return (
        <div className="text-center py-16 glass-effect rounded-xl border border-white/10 bg-black/40">
          <p className="text-muted-foreground mb-4">Inicia sesión para ver las publicaciones de la comunidad.</p>
        </div>
      );
    }
    
    if (feed.length === 0) {
      return (
        <div className="text-center py-16 glass-effect rounded-xl max-w-3xl mx-auto border border-white/10 bg-black/40">
          <p className="text-gray-300 mb-4 text-lg">
            Esta comunidad está un poco vacía. ¡Sé el primero en publicar!
          </p>
          <Button 
            onClick={() => setCreatePostOpen(true)}
            className="bg-[var(--neon-yellow)] text-black hover:bg-[var(--neon-yellow)]/90"
          >
            <Plus className="w-4 h-4 mr-2" />
            Crear Publicación
          </Button>
        </div>
      );
    }

    return (
        <div className="space-y-6 max-w-3xl mx-auto px-2 md:px-0 pb-20">
            {feed.map(post => (
                <PostCard key={post.id} post={post} currentUser={user} onRefresh={fetchFeed} />
            ))}
        </div>
    );
  };

  return (
    <div className="space-y-6 pb-10 min-h-screen relative h-full flex flex-col">
      <Helmet>
        <title>Comunidad Elite - Sergi Constance</title>
        <meta name="description" content="Únete a la comunidad exclusiva." />
      </Helmet>
      
      <AnimatePresence>
        {isCreatePostOpen && (
          <CreatePostModal
            onClose={() => setCreatePostOpen(false)}
            onPostCreated={handlePostCreated}
            community={activeCommunity}
          />
        )}
      </AnimatePresence>

      {activeCommunity !== 'boost' && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative w-full h-[200px] md:h-[300px] rounded-[2rem] overflow-hidden shadow-2xl border border-white/5 bg-black"
          >
            <div className="absolute inset-0">
               <img 
                 src="https://sergiconstance-9fn0dyoiqm.live-website.com/wp-content/uploads/2025/09/ShottingAtlas-143-scaled.jpg" 
                 alt="Community Hero" 
                 className="w-full h-full object-cover opacity-60"
                 style={{ objectPosition: 'center 20%' }}
               />
               <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
            </div>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 space-y-4">
               <Users className="w-12 h-12 text-white mb-2" />
               <h1 className="text-3xl md:text-5xl font-black text-white uppercase tracking-tighter">
                 Comunidad <span className="text-transparent bg-clip-text bg-gradient-to-r from-[var(--neon-yellow)] to-amber-500">Elite</span>
               </h1>
            </div>
          </motion.div>
      )}

      <div className="glass-effect rounded-full p-1 flex items-center gap-1 max-w-md mx-auto shadow-xl bg-black/60 border border-white/10 mb-2">
        <Button
          onClick={() => setActiveCommunity('boost')}
          className={`flex-1 rounded-full ${activeCommunity === 'boost' ? 'bg-[#5865F2] text-white font-bold' : 'text-white hover:bg-white/10'}`}
          variant="ghost"
        >
          <Zap className="w-4 h-4 mr-2"/>
          Boost Chat
        </Button>
        <Button
          onClick={() => setActiveCommunity('campus')}
          className={`flex-1 rounded-full ${activeCommunity === 'campus' ? 'bg-[var(--neon-yellow)] text-black font-bold' : 'text-white hover:bg-white/10'}`}
          variant="ghost"
        >
          <GraduationCap className="w-4 h-4 mr-2"/>
          Campus Feed
        </Button>
      </div>

      <div className="w-full flex-1">
        {renderContent()}
      </div>
    </div>
  );
};

export default CommunityScreen;