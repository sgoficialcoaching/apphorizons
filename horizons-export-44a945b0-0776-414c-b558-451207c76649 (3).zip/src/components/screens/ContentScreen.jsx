import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Play, Lock, BookOpen, Video } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { getContentLibrary } from '@/lib/database';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { checkSubscriptionStatus } from '@/lib/subscription';

const ContentScreen = () => {
  const { user } = useAuth();
  const [content, setContent] = useState([]);
  const [filter, setFilter] = useState('all');
  const [subscriptionStatus, setSubscriptionStatus] = useState(null);

  useEffect(() => {
    setContent(getContentLibrary());
    if (user) {
      setSubscriptionStatus(checkSubscriptionStatus(user.id));
    }
  }, [user]);

  const filteredContent = content.filter(item => {
    if (filter === 'all') return true;
    return item.type === filter;
  });

  const handleContentClick = (item) => {
    if (item.premium && !subscriptionStatus?.isPremium) {
      toast({
        title: '🔒 Contenido Premium',
        description: 'Mejora a Pro o Elite para acceder a este contenido.',
        variant: 'destructive'
      });
      return;
    }

    toast({
      title: '🚧 ¡Próximamente!',
      description: 'El reproductor de vídeo estará disponible en la próxima actualización.',
    });
  };
  
  if (!user) {
    return <div className="text-center p-8">Cargando contenido...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2">Contenido Exclusivo</h2>
        <p className="text-muted-foreground">Aprende de la mano de Sergi Constance.</p>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2">
        {['all', 'video', 'article'].map((filterType) => (
          <button
            key={filterType}
            onClick={() => setFilter(filterType)}
            className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-all ${
              filter === filterType
                ? 'btn-primary'
                : 'btn-secondary'
            }`}
          >
            {filterType === 'all' ? 'Todo' : filterType === 'video' ? 'Vídeos' : 'Artículos'}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredContent.map((item, index) => {
          const isLocked = item.premium && !subscriptionStatus?.isPremium;

          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`glass-effect rounded-2xl overflow-hidden card-hover ${isLocked ? 'content-locked' : ''}`}
            >
              <div className="relative h-48 bg-secondary">
                <img
                  alt={item.title}
                  className="w-full h-full object-cover opacity-80"
                 src="https://images.unsplash.com/photo-1652086939922-9582b3367e61" />
                {isLocked && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/70 backdrop-blur-sm z-10">
                    <div className="text-center">
                      <Lock className="w-12 h-12 mx-auto mb-2 text-primary" />
                      <span className="premium-badge">PREMIUM</span>
                    </div>
                  </div>
                )}
                <div className="absolute top-3 right-3 z-20">
                  {item.type === 'video' ? (
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                      <Video className="w-5 h-5 text-primary" />
                    </div>
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center">
                      <BookOpen className="w-5 h-5 text-blue-400" />
                    </div>
                  )}
                </div>
              </div>

              <div className="p-4 flex flex-col flex-grow">
                <div className="flex-grow">
                  <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {item.tags?.slice(0, 3).map(tag => `#${tag}`).join(' ') || ''}
                  </p>
                </div>

                <Button
                  onClick={() => handleContentClick(item)}
                  className={`w-full mt-auto ${
                    isLocked
                      ? 'btn-primary'
                      : 'btn-secondary'
                  }`}
                >
                  {isLocked ? (
                    <>
                      <Lock className="w-4 h-4 mr-2" />
                      Desbloquear con Pro
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      {item.type === 'video' ? 'Ver Vídeo' : 'Leer Artículo'}
                    </>
                  )}
                </Button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};

export default ContentScreen;