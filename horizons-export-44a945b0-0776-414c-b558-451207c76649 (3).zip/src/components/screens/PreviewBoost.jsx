import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ArrowLeft, Play, Star, TrendingUp, Activity, Lock, Dumbbell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';

const PreviewBoost = () => {
    const navigate = useNavigate();

    return (
        <>
            <Helmet>
                <title>App Preview - Boost</title>
            </Helmet>
            <div className="min-h-screen bg-background p-6 md:p-10 flex flex-col items-center">
                <motion.div 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="w-full max-w-6xl flex justify-between items-center mb-10"
                >
                    <Button variant="ghost" onClick={() => navigate('/')} className="gap-2">
                        <ArrowLeft size={20} /> Volver
                    </Button>
                    <img src="https://horizons-cdn.hostinger.com/44a945b0-0776-414c-b558-451207c76649/fb087dd1803a43139c7109f55ed3d3a5.png" alt="Boost Logo" className="h-8" />
                </motion.div>

                <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                    >
                        <h1 className="text-6xl md:text-8xl font-bebas text-white mb-6 leading-none">
                            TU ENTRENADOR <br/>
                            <span className="text-primary">PERSONAL 24/7</span>
                        </h1>
                        <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                            Accede a rutinas exclusivas, planes de nutrición adaptados y seguimiento en tiempo real. La tecnología de Boost se adapta a tu progreso.
                        </p>
                        <div className="flex flex-col sm:flex-row gap-4">
                            <Button size="lg" className="text-lg" onClick={() => navigate('/selection')}>
                                COMENZAR AHORA
                            </Button>
                            <Button size="lg" variant="outline" className="text-lg">
                                VER DEMO
                            </Button>
                        </div>
                        
                        <div className="mt-12 grid grid-cols-3 gap-6">
                            <div className="text-center">
                                <h3 className="text-3xl font-bold text-white">500+</h3>
                                <p className="text-sm text-primary uppercase tracking-wider">Ejercicios</p>
                            </div>
                            <div className="text-center border-l border-white/10">
                                <h3 className="text-3xl font-bold text-white">10k+</h3>
                                <p className="text-sm text-primary uppercase tracking-wider">Usuarios</p>
                            </div>
                            <div className="text-center border-l border-white/10">
                                <h3 className="text-3xl font-bold text-white">4.9</h3>
                                <p className="text-sm text-primary uppercase tracking-wider">Rating</p>
                            </div>
                        </div>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.4 }}
                        className="relative"
                    >
                        {/* Mockup Phone/App Interface */}
                        <div className="relative z-10 bg-[#121214] rounded-[3rem] border-8 border-[#1C1C1F] shadow-2xl overflow-hidden max-w-md mx-auto aspect-[9/19]">
                            <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-black/80 to-transparent z-20 pointer-events-none"></div>
                            
                            {/* Mock Content Inside Phone */}
                            <div className="p-6 pt-12 h-full flex flex-col gap-4 overflow-hidden">
                                <div className="flex justify-between items-center mb-4">
                                    <div>
                                        <p className="text-xs text-muted-foreground uppercase">Buenos días</p>
                                        <h4 className="text-xl font-bold text-white">Campeón</h4>
                                    </div>
                                    <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                                        <Activity size={20} />
                                    </div>
                                </div>

                                <div className="bg-primary rounded-3xl p-6 text-black mb-2 relative overflow-hidden">
                                    <div className="relative z-10">
                                        <p className="font-bold text-sm opacity-80 mb-1">ENTRENAMIENTO DE HOY</p>
                                        <h3 className="text-2xl font-black uppercase mb-4">PECHO & TRÍCEPS</h3>
                                        <button className="bg-black text-white px-4 py-2 rounded-full text-xs font-bold uppercase">Iniciar</button>
                                    </div>
                                    <Dumbbell className="absolute -bottom-4 -right-4 text-black/10 w-32 h-32" />
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div className="bg-[#1C1C1F] p-4 rounded-3xl">
                                        <TrendingUp className="text-green-500 mb-2" />
                                        <p className="text-2xl font-bold text-white">2,450</p>
                                        <p className="text-xs text-muted-foreground">Kcal Quemadas</p>
                                    </div>
                                    <div className="bg-[#1C1C1F] p-4 rounded-3xl">
                                        <Star className="text-primary mb-2" />
                                        <p className="text-2xl font-bold text-white">12</p>
                                        <p className="text-xs text-muted-foreground">Racha Días</p>
                                    </div>
                                </div>

                                <div className="mt-4">
                                    <h5 className="text-white font-bold mb-3">Próximos Retos</h5>
                                    <div className="bg-[#1C1C1F] p-4 rounded-3xl flex items-center gap-4 opacity-60">
                                        <div className="h-10 w-10 rounded-full bg-white/10 flex items-center justify-center">
                                            <Lock size={18} className="text-white" />
                                        </div>
                                        <div>
                                            <p className="text-white font-bold">Bestia de Espalda</p>
                                            <p className="text-xs text-muted-foreground">Desbloquea en Nivel 5</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Decorative Elements behind phone */}
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[80%] bg-primary/20 blur-[100px] -z-10 rounded-full"></div>
                    </motion.div>
                </div>
            </div>
        </>
    );
};

export default PreviewBoost;