import React, { useState, useEffect, Suspense, lazy } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'framer-motion';
import { 
  Play, Trophy, Activity, 
  Dumbbell, Timer, Rocket
} from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { 
  getBoostChallengeStatus, getBoostedDay, getActiveRoutine, 
  getWorkouts
} from '@/lib/database';
import BoostWorkoutProgram from '@/components/workout/BoostWorkoutProgram';
import { CircularProgressbar, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

// Lazy load heavy components
const NutritionSection = lazy(() => import('@/components/nutrition/NutritionSection'));

// --- COMPONENTS ---

const GlowingOrb = () => (
    <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] bg-[var(--neon-yellow)]/10 blur-[150px] rounded-full pointer-events-none z-0 animate-pulse" />
);

const DailyWorkoutCard = ({ dayType, date, onStart }) => {
    const isRest = dayType === 'Rest';
    
    return (
        <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative w-full overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-[#1c1c1e] to-[#000] border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.5)] group mb-16 md:mb-8"
        >
            {/* Background Image Effect */}
            <div className="absolute inset-0 opacity-40 group-hover:opacity-60 transition-opacity duration-700">
                <img 
                    src={isRest 
                        ? "https://images.unsplash.com/photo-1518611012118-696072aa579a?q=80&w=2070&auto=format&fit=crop" // Rest/Stretch
                        : "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070&auto=format&fit=crop" // Gym
                    }
                    className="w-full h-full object-cover grayscale mix-blend-overlay"
                    alt="Workout Background"
                />
            </div>
            
            {/* Content - Increased padding-bottom for mobile safe area */}
            <div className="relative z-10 p-8 pb-16 md:pb-8 flex flex-col items-center text-center h-[500px] md:h-[450px] justify-between">
                <div className="space-y-2">
                    <span className="inline-block px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400 backdrop-blur-md">
                        {new Date().toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })}
                    </span>
                    <h2 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter text-white drop-shadow-xl">
                        {dayType === 'Rest' ? 'Recuperación' : dayType}
                    </h2>
                    {!isRest && <p className="text-[var(--neon-yellow)] font-bold uppercase tracking-widest text-sm animate-pulse">Plan del Día</p>}
                </div>

                {/* Central Interactive Element */}
                <div className="relative group/btn z-30">
                    <div className="absolute inset-0 bg-[var(--neon-yellow)] blur-[60px] opacity-20 group-hover/btn:opacity-40 transition-opacity duration-500 rounded-full" />
                    
                    {isRest ? (
                        <div className="w-32 h-32 rounded-full border-2 border-white/20 flex items-center justify-center bg-black/40 backdrop-blur-sm">
                            <Activity className="w-12 h-12 text-gray-400" />
                        </div>
                    ) : (
                        <motion.button
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.95 }}
                            onClick={onStart}
                            className="relative w-32 h-32 md:w-40 md:h-40 rounded-full bg-[var(--neon-yellow)] flex items-center justify-center shadow-[0_0_40px_rgba(255,214,0,0.4)] hover:shadow-[0_0_80px_rgba(255,214,0,0.6)] transition-all duration-300 z-20 cursor-pointer pointer-events-auto"
                        >
                            <Play className="w-12 h-12 md:w-16 md:h-16 fill-black text-black ml-2" />
                            
                            {/* Orbital Ring Animation */}
                            <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none" viewBox="0 0 100 100">
                                <circle cx="50" cy="50" r="48" stroke="white" strokeWidth="1" fill="none" className="opacity-30" />
                                <motion.circle 
                                    cx="50" cy="50" r="48" stroke="white" strokeWidth="2" fill="none"
                                    strokeDasharray="300"
                                    animate={{ strokeDashoffset: [300, 0] }}
                                    transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                                />
                            </svg>
                        </motion.button>
                    )}
                </div>

                <div className="w-full relative z-20">
                    {isRest ? (
                        <div className="grid grid-cols-2 gap-4 w-full max-w-sm mx-auto">
                            <div className="bg-black/40 p-3 rounded-xl border border-white/5 backdrop-blur-sm">
                                <Activity className="w-5 h-5 text-blue-400 mx-auto mb-1" />
                                <p className="text-xs text-gray-400">Cardio Ligero</p>
                            </div>
                            <div className="bg-black/40 p-3 rounded-xl border border-white/5 backdrop-blur-sm">
                                <SparklesIcon className="w-5 h-5 text-purple-400 mx-auto mb-1" />
                                <p className="text-xs text-gray-400">Estiramientos</p>
                            </div>
                        </div>
                    ) : (
                        <div className="flex flex-col gap-3 w-full max-w-xs mx-auto">
                             <div className="flex justify-between text-xs font-bold text-gray-400 uppercase tracking-wider px-2">
                                <span>Duración Est.</span>
                                <span>Intensidad</span>
                            </div>
                            <div className="flex justify-between items-center bg-black/40 p-4 rounded-2xl border border-white/10 backdrop-blur-md">
                                <div className="flex items-center gap-2">
                                    <Timer className="w-4 h-4 text-[var(--neon-yellow)]" />
                                    <span className="font-bold text-white">60-75 min</span>
                                </div>
                                <div className="flex gap-1">
                                    {[1,2,3,4,5].map(i => (
                                        <div key={i} className={`w-1.5 h-4 rounded-full ${i <= 4 ? 'bg-[var(--neon-yellow)]' : 'bg-white/10'}`} />
                                    ))}
                                </div>
                            </div>
                            <p className="text-[10px] text-gray-500 font-medium uppercase tracking-widest mt-2 animate-pulse">
                                Pulsa para iniciar sesión
                            </p>
                        </div>
                    )}
                </div>
            </div>
        </motion.div>
    );
};

const SparklesIcon = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M9 5H3"/></svg>
)

const QuickStatsRow = ({ workouts }) => {
    const completedWorkouts = workouts.filter(w => w.status === 'done').length;
    const totalVolume = workouts.reduce((acc, w) => acc + (w.tonnage_total || 0), 0) / 1000; // in tons
    const hoursTrained = Math.round(workouts.reduce((acc, w) => acc + (w.duration_min || 0), 0) / 60);

    const StatBox = ({ icon: Icon, label, value, sub, delay }) => (
        <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay }}
            className="flex-1 bg-gradient-to-br from-[#1c1c1e] to-black border border-white/5 p-4 rounded-2xl relative overflow-hidden group"
        >
            <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                <Icon className="w-12 h-12 text-[var(--neon-yellow)]" />
            </div>
            <div className="relative z-10">
                <div className="text-gray-400 text-[10px] font-bold uppercase tracking-widest mb-1">{label}</div>
                <div className="text-2xl md:text-3xl font-black text-white">{value}</div>
                <div className="text-[10px] text-[var(--neon-yellow)] font-medium mt-1">{sub}</div>
            </div>
        </motion.div>
    );

    return (
        <div className="grid grid-cols-3 gap-3 md:gap-6 my-8">
            <StatBox icon={Trophy} label="Sesiones" value={completedWorkouts} sub="Completadas" delay={0.1} />
            <StatBox icon={Dumbbell} label="Volumen" value={`${totalVolume.toFixed(0)}T`} sub="Levantados" delay={0.2} />
            <StatBox icon={Timer} label="Tiempo" value={`${hoursTrained}h`} sub="Entrenando" delay={0.3} />
        </div>
    );
};

const ChallengeMiniCard = ({ status }) => {
    if (!status?.isActive) return null;
    
    return (
        <motion.div 
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="w-full bg-gradient-to-r from-[var(--neon-yellow)]/20 to-transparent border border-[var(--neon-yellow)]/30 rounded-xl p-4 flex items-center justify-between mb-8 backdrop-blur-sm"
        >
            <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-[var(--neon-yellow)] flex items-center justify-center shadow-[0_0_15px_rgba(255,214,0,0.4)]">
                    <Rocket className="w-5 h-5 text-black fill-black" />
                </div>
                <div>
                    <h4 className="text-white font-bold text-sm">Boost Challenge Activo</h4>
                    <p className="text-[10px] text-gray-300 uppercase tracking-wider">Semana {status.currentWeek} • Día 4/7</p>
                </div>
            </div>
            <div className="w-12 h-12">
                <CircularProgressbar
                    value={65} // Mock progress
                    text={`${65}%`}
                    styles={buildStyles({
                        textSize: '28px',
                        pathColor: '#FFD600',
                        textColor: '#fff',
                        trailColor: 'rgba(255,255,255,0.1)'
                    })}
                />
            </div>
        </motion.div>
    );
};

// --- MAIN SCREEN ---

const BoostScreen = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    
    // Default to 'workout' if no state passed
    const [activeTab, setActiveTab] = useState('workout');
    const [isLoading, setIsLoading] = useState(true);
    const [data, setData] = useState(null);

    const { scrollY } = useScroll();
    const headerOpacity = useTransform(scrollY, [0, 100], [0, 1]);

    // Update activeTab when location.state changes
    useEffect(() => {
        if (location.state?.tab) {
            setActiveTab(location.state.tab);
        }
    }, [location.state]);

    useEffect(() => {
        if (!user) return;
        const loadData = () => {
            const challenge = getBoostChallengeStatus(user.id);
            const boostedDayInfo = getBoostedDay(user.id);
            const activeRoutine = getActiveRoutine(user.id) || (challenge?.isActive ? 'advanced' : 'beginner');
            const workouts = getWorkouts(user.id);

            // Determine today's workout type
            let dayType = 'Rest';
            // Simple logic: use active routine schedule or PPL
            const programs = {
                beginner: ['Push', 'Pull', 'Legs', 'Rest', 'Full Body', 'Rest', 'Rest'],
                intermediate: ['Push', 'Pull', 'Legs', 'Upper', 'Lower', 'Rest', 'Rest'],
                advanced: ['Push', 'Pull', 'Legs', 'Rest', 'Push', 'Pull', 'Legs']
            };
            const todayIndex = (new Date().getDay() + 6) % 7; // Monday = 0
            dayType = (programs[activeRoutine] || programs['beginner'])[todayIndex];

            setData({
                challenge,
                boostedDay: boostedDayInfo,
                activeRoutine,
                workouts,
                dayType
            });
            setIsLoading(false);
        };
        loadData();
    }, [user]);

    if (isLoading) return null;

    const handleStartWorkout = () => {
        // Navigate to session prep with today's date and active level
        const dateStr = new Date().toISOString().split('T')[0];
        navigate(`/session-prep/${dateStr}/${data.activeRoutine}`);
    };

    return (
        <div className="min-h-screen pb-32 relative">
            <GlowingOrb />
            
            {/* Sticky Header */}
            <motion.div 
                style={{ opacity: headerOpacity }}
                className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-xl border-b border-white/5 px-6 py-4 flex justify-between items-center"
            >
                <span className="font-black text-xl italic uppercase tracking-tighter text-white">BOOST <span className="text-[var(--neon-yellow)]">ZONE</span></span>
                <div className="flex gap-2">
                    <Button 
                        variant={activeTab === 'workout' ? 'default' : 'ghost'} 
                        size="sm" 
                        onClick={() => setActiveTab('workout')}
                        className="text-xs h-8"
                    >
                        Entreno
                    </Button>
                    <Button 
                        variant={activeTab === 'nutrition' ? 'default' : 'ghost'} 
                        size="sm" 
                        onClick={() => setActiveTab('nutrition')}
                        className="text-xs h-8"
                    >
                        Nutrición
                    </Button>
                </div>
            </motion.div>

            <div className="px-4 md:px-8 pt-6 relative z-10 max-w-5xl mx-auto">
                {/* Header Section */}
                <div className="flex justify-between items-end mb-8">
                    <div>
                        <h1 className="text-5xl md:text-7xl font-black italic uppercase text-white tracking-tighter leading-none mb-2">
                            MODO <span className="text-transparent bg-clip-text bg-gradient-to-r from-[var(--neon-yellow)] to-yellow-600">BESTIA</span>
                        </h1>
                        <p className="text-gray-400 font-medium text-sm md:text-base max-w-md">
                            Tu centro de mando para romper límites. Hoy es el día.
                        </p>
                    </div>
                </div>

                {/* Tab Switcher (Mobile/Desktop) */}
                <div className="flex p-1 bg-white/5 rounded-xl border border-white/5 mb-8 w-fit mx-auto md:mx-0">
                    <button
                        onClick={() => setActiveTab('workout')}
                        className={`px-6 py-2 rounded-lg text-sm font-bold uppercase tracking-wider transition-all duration-300 ${activeTab === 'workout' ? 'bg-[var(--neon-yellow)] text-black shadow-lg shadow-yellow-500/20' : 'text-gray-400 hover:text-white'}`}
                    >
                        Entrenamiento
                    </button>
                    <button
                        onClick={() => setActiveTab('nutrition')}
                        className={`px-6 py-2 rounded-lg text-sm font-bold uppercase tracking-wider transition-all duration-300 ${activeTab === 'nutrition' ? 'bg-[var(--neon-yellow)] text-black shadow-lg shadow-yellow-500/20' : 'text-gray-400 hover:text-white'}`}
                    >
                        Nutrición
                    </button>
                </div>

                <AnimatePresence mode="wait">
                    {activeTab === 'workout' ? (
                        <motion.div
                            key="workout"
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -20 }}
                            transition={{ duration: 0.3 }}
                        >
                            <ChallengeMiniCard status={data.challenge} />
                            
                            {/* Main Hero Card */}
                            <DailyWorkoutCard 
                                dayType={data.dayType} 
                                date={new Date()} 
                                onStart={handleStartWorkout} 
                            />

                            <QuickStatsRow workouts={data.workouts} />

                            {/* Program Section */}
                            <div className="mt-12">
                                <div className="flex items-center gap-3 mb-6">
                                    <div className="w-1 h-8 bg-[var(--neon-yellow)] rounded-full" />
                                    <h3 className="text-2xl font-black italic uppercase text-white">Tu Calendario</h3>
                                </div>
                                <BoostWorkoutProgram userId={user.id} />
                            </div>

                        </motion.div>
                    ) : (
                        <motion.div
                            key="nutrition"
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -20 }}
                            transition={{ duration: 0.3 }}
                        >
                            <Suspense fallback={<div className="h-64 flex items-center justify-center text-[var(--neon-yellow)] animate-pulse font-bold tracking-widest uppercase">Cargando Nutrición OS...</div>}>
                                <NutritionSection userId={user.id} />
                            </Suspense>
                        </motion.div>
                    )}
                </AnimatePresence>

            </div>
        </div>
    );
};

export default BoostScreen;