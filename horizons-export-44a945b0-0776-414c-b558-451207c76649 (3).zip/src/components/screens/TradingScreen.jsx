import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, Briefcase, ArrowLeft } from 'lucide-react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { toast } from '@/components/ui/use-toast';
import LoadingScreen from '@/components/common/LoadingScreen';

const TradingScreen = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAccounts = async () => {
      if (!user) return;
      
      const { data, error } = await supabase
        .from('trading_accounts')
        .select('*')
        .eq('user_id', user.id);
        
      if (error) {
        toast({
          title: 'Error',
          description: 'No se pudieron cargar las cuentas de trading.',
          variant: 'destructive',
        });
      } else {
        setAccounts(data);
      }
      setLoading(false);
    };

    fetchAccounts();
  }, [user]);

  const handleNotImplemented = () => {
    toast({
      title: "🚧 Próximamente",
      description: "Esta funcionalidad estará disponible próximamente.",
    });
  };

  if(loading) return <LoadingScreen />

  return (
    <>
      <Helmet>
        <title>Trading - Sergi Constance App</title>
        <meta name="description" content="Gestiona tus cuentas de trading y analiza tu rendimiento." />
      </Helmet>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
                <Button variant="ghost" size="icon" onClick={() => navigate('/finance')}>
                    <ArrowLeft />
                </Button>
                <div>
                    <h1 className="text-3xl sm:text-4xl font-bold">Panel de Trading</h1>
                    <p className="text-muted-foreground text-sm sm:text-base">Gestiona tus cuentas y operaciones.</p>
                </div>
            </div>
            <Button onClick={handleNotImplemented}>
                <Plus className="mr-2 h-4 w-4" /> Añadir Cuenta
            </Button>
        </div>

        {accounts.length === 0 ? (
            <div className="text-center py-16 glass-effect rounded-2xl">
                <Briefcase className="mx-auto h-12 w-12 text-muted-foreground" />
                <h3 className="mt-4 text-lg font-semibold">Sin Cuentas de Trading</h3>
                <p className="mt-1 text-sm text-muted-foreground">Añade tu primera cuenta para empezar a monitorizarla.</p>
                <Button className="mt-6" onClick={handleNotImplemented}>Añadir Cuenta de Trading</Button>
            </div>
        ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {accounts.map(account => (
                    <div key={account.id} className="glass-effect p-6 rounded-2xl">
                        <h3 className="font-bold text-lg">{account.name}</h3>
                        <p className="text-sm text-primary">{account.platform}</p>
                        <p className="text-2xl font-bold mt-4">${account.balance.toLocaleString()}</p>
                    </div>
                ))}
            </div>
        )}

      </motion.div>
    </>
  );
};

export default TradingScreen;