import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { getExerciseById, getUserPRs, createWorkout, addSetToWorkout, getWorkouts } from '@/lib/database';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { ArrowLeft, PlusCircle, Trophy } from 'lucide-react';

const ExerciseDetailScreen = () => {
    const { exerciseId } = useParams();
    const navigate = useNavigate();
    const { user } = useAuth();
    
    const [exercise, setExercise] = useState(null);
    const [prs, setPRs] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (user) {
            setLoading(true);
            const exerciseData = getExerciseById(exerciseId);
            const prData = getUserPRs(user.id, exerciseId);
            setExercise(exerciseData);
            setPRs(prData.sort((a,b) => new Date(b.date) - new Date(a.date)));
            setLoading(false);
        }
    }, [user, exerciseId]);

    const handleAddToWorkout = () => {
        const activeWorkouts = getWorkouts(user.id).filter(w => w.status === 'active');
        let workoutToUse;
        if (activeWorkouts.length > 0) {
            workoutToUse = activeWorkouts[0];
        } else {
            workoutToUse = createWorkout(user.id, {});
        }
        addSetToWorkout(user.id, workoutToUse.id, exerciseId);
        toast({ title: '¡Añadido!', description: `${exercise.name} se ha añadido a tu entrenamiento activo.` });
        navigate(`/workout/${workoutToUse.id}`);
    };

    if (loading) return <div className="text-center p-10">Cargando ejercicio...</div>;
    if (!exercise) return <div className="text-center p-10">Ejercicio no encontrado.</div>;

    const currentPR = prs.length > 0 ? prs[0] : null;

    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div>
                <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="mb-2">
                    <ArrowLeft />
                </Button>
                <h2 className="text-3xl font-bold">{exercise.name}</h2>
                <p className="text-muted-foreground capitalize">{exercise.muscleGroup}</p>
            </div>
            
            <div className="aspect-video rounded-xl overflow-hidden glass-effect shadow-lg">
                {exercise.videoUrl ? (
                     <iframe
                        className="w-full h-full"
                        src={exercise.videoUrl}
                        title={exercise.name}
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                    ></iframe>
                ) : (
                    <div className="w-full h-full flex items-center justify-center bg-secondary text-muted-foreground">
                        Vídeo no disponible
                    </div>
                )}
            </div>

            <div className="grid md:grid-cols-2 gap-6">
                 <div className="glass-effect rounded-2xl p-6 flex flex-col items-center justify-center text-center">
                    <Trophy className="w-12 h-12 text-amber-400" />
                    <h3 className="text-xl font-bold mt-4">Mejor Marca Personal</h3>
                    {currentPR ? (
                        <>
                            <p className="text-4xl font-black gradient-text my-2">
                                {currentPR.type === '1RM' ? `${Math.round(currentPR.value)}kg` : currentPR.value}
                            </p>
                            <p className="text-sm text-muted-foreground">{currentPR.type === '1RM' ? '1RM Estimado' : (currentPR.type === 'reps' ? 'Repeticiones' : 'Peso')}</p>
                            <p className="text-xs text-muted-foreground mt-1">Conseguido el {new Date(currentPR.date).toLocaleDateString()}</p>
                        </>
                    ) : (
                        <p className="text-muted-foreground mt-4">¡Aún no tienes un PR! <br/> ¡Es tu momento de brillar!</p>
                    )}
                </div>

                <div className="glass-effect rounded-2xl p-6">
                    <h3 className="text-xl font-bold mb-4">Historial de PRs</h3>
                    {prs.length > 1 ? (
                        <ul className="space-y-2 max-h-48 overflow-y-auto">
                            {prs.slice(1).map(pr => (
                                <li key={pr.id} className="flex items-center justify-between p-2 bg-secondary/50 rounded-lg">
                                    <span className="font-semibold">{pr.type === '1RM' ? `${Math.round(pr.value)}kg` : pr.value}</span>
                                    <span className="text-xs text-muted-foreground">{new Date(pr.date).toLocaleDateString()}</span>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="text-muted-foreground text-center py-4">No hay historial de récords todavía.</p>
                    )}
                </div>
            </div>

            <Button onClick={handleAddToWorkout} className="w-full btn-primary shadow-lg shadow-primary/20">
                <PlusCircle className="w-5 h-5 mr-2" />
                Añadir al Entrenamiento Actual
            </Button>
        </motion.div>
    );
};

export default ExerciseDetailScreen;