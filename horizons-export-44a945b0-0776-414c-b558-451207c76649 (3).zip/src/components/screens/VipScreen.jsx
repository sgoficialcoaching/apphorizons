import React, { useState, useEffect } from 'react';
        import { motion } from 'framer-motion';
        import { Star, ShoppingCart, Zap, UserCheck } from 'lucide-react';
        import { Button } from '@/components/ui/button';
        import { toast } from '@/components/ui/use-toast';
        import { useAuth } from '@/contexts/SupabaseAuthContext';

        const VipScreen = () => {
          const { user } = useAuth();
          const [tokens, setTokens] = useState(0);
          
          useEffect(() => {
            if (user) {
              const balance = JSON.parse(localStorage.getItem(`gam_user_balance_${user.id}`) || '{ "balance": 0 }');
              setTokens(balance.balance);
            }
          }, [user]);

          const rewards = [
            {
              id: 'belegend',
              title: 'Productos Exclusivos BeLegend',
              description: 'Accede a ropa y accesorios únicos de la tienda oficial BeLegend.',
              cost: 2500,
              icon: ShoppingCart,
              color: 'from-blue-500 to-cyan-500'
            },
            {
              id: 'training',
              title: 'Entrenamiento con Sergi',
              description: 'Una sesión de entrenamiento personal e inolvidable junto a Sergi Constance.',
              cost: 10000,
              icon: Zap,
              color: 'from-purple-500 to-pink-500'
            },
            {
              id: 'one-on-one',
              title: '1 a 1 con Sergi',
              description: 'Una videollamada privada para resolver tus dudas sobre entreno y nutrición.',
              cost: 7500,
              icon: UserCheck,
              color: 'from-green-500 to-emerald-500'
            }
          ];

          const handleRedeem = (reward) => {
            if (!user) {
                toast({ title: 'Error', description: 'Debes iniciar sesión para canjear recompensas.', variant: 'destructive' });
                return;
            }

            if (tokens < reward.cost) {
              toast({
                title: 'Boosts insuficientes',
                description: `Necesitas ${reward.cost} Boosts para canjear esta recompensa.`,
                variant: 'destructive'
              });
              return;
            }

            const currentBalance = JSON.parse(localStorage.getItem(`gam_user_balance_${user.id}`) || '{ "balance": 0 }');
            const newBalance = { balance: currentBalance.balance - reward.cost };
            setTokens(newBalance.balance);
            localStorage.setItem(`gam_user_balance_${user.id}`, JSON.stringify(newBalance));
            
            // For compatibility with old system
            localStorage.setItem(`tokens_${user.id}`, newBalance.balance.toString());

            toast({
              title: '¡Recompensa canjeada!',
              description: `Has canjeado "${reward.title}". Nos pondremos en contacto contigo.`,
            });
          };

          if (!user) {
              return <div className="text-center p-8">Cargando datos de usuario...</div>;
          }

          return (
            <div className="space-y-6 md:space-y-8">
              <div>
                <h2 className="text-2xl sm:text-3xl font-bold mb-2">Zona VIP</h2>
                <p className="text-muted-foreground text-sm sm:text-base">Usa tus Boosts para canjear recompensas exclusivas.</p>
              </div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="glass-effect rounded-2xl p-4 sm:p-6 flex items-center justify-between"
              >
                <h3 className="text-lg sm:text-xl font-bold">Tus Boosts</h3>
                <div className="token-display">
                  <Star className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
                  <span className="font-bold text-xl sm:text-2xl">{tokens}</span>
                </div>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {rewards.map((reward, index) => (
                  <motion.div
                    key={reward.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.15 }}
                    className="glass-effect rounded-2xl p-6 flex flex-col card-hover"
                  >
                    <div className="flex-grow">
                      <div className={`w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-gradient-to-br ${reward.color} flex items-center justify-center mb-4`}>
                        <reward.icon className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
                      </div>
                      <h4 className="text-lg sm:text-xl font-bold mb-2">{reward.title}</h4>
                      <p className="text-muted-foreground text-sm mb-4">{reward.description}</p>
                    </div>
                    <div className="mt-auto">
                      <div className="flex items-center justify-center gap-2 mb-4">
                        <Star className="w-5 h-5 text-primary" />
                        <span className="text-xl font-bold">{reward.cost.toLocaleString('es-ES')}</span>
                      </div>
                      <Button
                        onClick={() => handleRedeem(reward)}
                        className="w-full btn-primary"
                        disabled={tokens < reward.cost}
                      >
                        Canjear Recompensa
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          );
        };

        export default VipScreen;