import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, Check, Plus, Trash2, MoreVertical, 
  History, FileText, ChevronRight, Info,
  Mic, MicOff, Music, Volume2, VolumeX, Maximize2, Minimize2, Lightbulb
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { 
  getWorkoutById, finishWorkout, getSetsForWorkout, getExercises, 
  addSetToWorkout, updateSet, deleteSet, completeSet 
} from '@/lib/database';
import { addXpAndBoosties } from '@/lib/gamification';
import { cn } from '@/lib/utils';

// Components
import RestTimer from '@/components/workout/RestTimer';
import ExerciseInfoCard from '@/components/workout/ExerciseInfoCard';
import Confetti from '@/components/common/Confetti';
import WorkoutStatsBar from '@/components/workout/WorkoutStatsBar';
import ExerciseChart from '@/components/workout/ExerciseChart';
import { useVoiceControl } from '@/hooks/useVoiceControl';

const WorkoutScreen = () => {
    const { workoutId } = useParams();
    const navigate = useNavigate();
    const { user } = useAuth();
    
    // --- STATE ---
    const [workout, setWorkout] = useState(null);
    const [sets, setSets] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeExerciseIndex, setActiveExerciseIndex] = useState(0);
    const [restTimer, setRestTimer] = useState({ isActive: false, duration: 0, endTime: null, minimized: false });
    const [completedWorkoutData, setCompletedWorkoutData] = useState(null);
    const [showConfetti, setShowConfetti] = useState(false);
    
    // Advanced Features State
    const [isFocusMode, setIsFocusMode] = useState(false);
    const [isPlayingMusic, setIsPlayingMusic] = useState(false);
    const [workoutDuration, setWorkoutDuration] = useState(0);
    const audioRef = useRef(null);
    
    // UI Toggles
    const [showNotes, setShowNotes] = useState({}); 
    const [showInfo, setShowInfo] = useState({});
    const scrollRef = useRef(null);

    // --- INITIALIZATION ---
    useEffect(() => {
        if (user && workoutId) {
            const w = getWorkoutById(user.id, workoutId);
            if (w) {
                setWorkout(w);
                const s = getSetsForWorkout(user.id, workoutId);
                setSets(s);
            } else {
                toast({ variant: "destructive", title: "Error", description: "Entrenamiento no encontrado." });
                navigate('/home');
            }
            setLoading(false);
        }
    }, [user, workoutId, navigate]);

    // Timer Logic
    useEffect(() => {
        if (!completedWorkoutData) {
            const timer = setInterval(() => setWorkoutDuration(prev => prev + 1), 1000);
            return () => clearInterval(timer);
        }
    }, [completedWorkoutData]);

    // --- DERIVED DATA ---
    const exercises = useMemo(() => {
        const allExercises = getExercises();
        const grouped = {};
        const order = [];
        
        sets.forEach(set => {
            if (!grouped[set.exercise_id]) {
                const exData = allExercises.find(e => e.id === set.exercise_id);
                grouped[set.exercise_id] = {
                    ...exData,
                    sets: []
                };
                order.push(set.exercise_id);
            }
            grouped[set.exercise_id].sets.push(set);
        });
        return order.map(id => grouped[id]);
    }, [sets]);

    // Stats Calculations
    const totalSets = sets.length;
    const completedSets = sets.filter(s => s.completed_at).length;
    const progressPercentage = totalSets > 0 ? (completedSets / totalSets) * 100 : 0;
    const currentVolume = sets.reduce((acc, set) => acc + (set.completed_at ? (set.peso * set.reps) : 0), 0);
    // Rough calorie formula: MET * weight * time (simplified for UI)
    const burnedCalories = Math.floor((workoutDuration / 60) * 6 + (currentVolume / 500)); 

    // --- VOICE CONTROL ---
    const handleVoiceComplete = () => {
        // Logic to find current incomplete set
        const activeEx = exercises[activeExerciseIndex];
        if(!activeEx) return;
        const nextSet = activeEx.sets.find(s => !s.completed_at);
        if(nextSet) {
             handleSetComplete(nextSet.id, true);
             toast({ title: "🎙️ Set Completado", description: "¡Bien hecho!", className: "bg-green-500 text-black border-none" });
        } else if (activeExerciseIndex < exercises.length - 1) {
            jumpToExercise(activeExerciseIndex + 1);
        }
    };

    const handleVoiceNext = () => {
        if (activeExerciseIndex < exercises.length - 1) {
             jumpToExercise(activeExerciseIndex + 1);
             toast({ title: "🎙️ Siguiente Ejercicio", className: "bg-blue-500 text-white" });
        }
    };

    const { isListening, toggleListening, support: voiceSupported } = useVoiceControl({
        "completado": handleVoiceComplete,
        "listo": handleVoiceComplete,
        "siguiente": handleVoiceNext,
        "vamos": handleVoiceNext
    });

    // --- HANDLERS ---
    const handleSetUpdate = (setId, field, value) => {
        updateSet(user.id, setId, { [field]: parseFloat(value) || 0 });
        setSets(prev => prev.map(s => s.id === setId ? { ...s, [field]: parseFloat(value) || 0 } : s));
    };

    const handleSetComplete = (setId, isComplete) => {
        const result = completeSet(user.id, setId, isComplete);
        setSets(prev => prev.map(s => s.id === setId ? result.completedSet : s));

        if (isComplete) {
            // Haptics
            if (navigator.vibrate) navigator.vibrate(50);

            // Motivational Toast (Random)
            const phrases = ["¡Ligero!", "¡Bestia!", "¡Una más!", "¡Fuego puro! 🔥"];
            if (Math.random() > 0.7) {
                toast({ 
                    title: phrases[Math.floor(Math.random() * phrases.length)], 
                    className: "bg-[var(--neon-blue)] text-black font-black border-none" 
                });
            }

            // Challenge Check (Mock)
            if (sets.filter(s => s.completed_at).length === 5) {
                toast({ title: "🎖️ Reto Diario", description: "5 Series completadas. ¡Sigue así!", variant: "default" });
            }
            
            // PR Check
            if (result.newPR) {
                setShowConfetti(true);
                setTimeout(() => setShowConfetti(false), 3000);
                toast({
                    title: "🏆 ¡NUEVO RÉCORD!",
                    description: `¡Has superado tu marca en ${result.newPR.exerciseName}!`,
                    className: "bg-yellow-400 text-black border-none font-bold"
                });
            }
            
            // Start Rest Timer
            const exercise = exercises.find(e => e.sets.some(s => s.id === setId));
            if (exercise) {
                const duration = exercise.rest_time_sec > 0 ? exercise.rest_time_sec : 90;
                setRestTimer({
                    isActive: true,
                    duration: duration,
                    endTime: Date.now() + duration * 1000,
                    minimized: false
                });
            }
        }
    };

    const handleAddSet = (exerciseId) => {
        const newSet = addSetToWorkout(user.id, workoutId, exerciseId);
        setSets(prev => [...prev, newSet]);
    };

    const handleDeleteSet = (setId) => {
        deleteSet(user.id, setId);
        setSets(prev => prev.filter(s => s.id !== setId));
    };

    const handleFinishWorkout = async () => {
        const incompleteSets = sets.filter(s => !s.completed_at);
        if (incompleteSets.length > 0) {
            if (!window.confirm(`Aún tienes ${incompleteSets.length} series pendientes. ¿Seguro que quieres terminar?`)) return;
        }

        const result = finishWorkout(user.id, workoutId);
        if (result.success) {
            try {
                const rewards = await addXpAndBoosties(user.id, 'WORKOUT_COMPLETE');
                setCompletedWorkoutData({ ...result, rewards });
                setShowConfetti(true);
            } catch (error) {
                setCompletedWorkoutData({ ...result, rewards: { earnedXp: 100, earnedBoosties: 20 } });
                setShowConfetti(true);
            }
        } else {
            toast({ variant: "destructive", title: "Error", description: result.error });
        }
    };

    const jumpToExercise = (index) => {
        setActiveExerciseIndex(index);
        const el = document.getElementById(`exercise-${index}`);
        if(el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };

    const toggleMusic = () => {
        if (!audioRef.current) return;
        if (isPlayingMusic) {
            audioRef.current.pause();
        } else {
            audioRef.current.play();
            toast({ title: "🎵 Modo Bestia", description: "Reproduciendo música motivacional" });
        }
        setIsPlayingMusic(!isPlayingMusic);
    };

    // --- SMART SUGGESTIONS LOGIC ---
    const getSmartSuggestion = (exercise) => {
        // Simple logic: if previous set was > 12 reps, suggest +2.5kg
        // This would ideally look at historical data, but we use the current session for now
        const lastCompletedSet = [...exercise.sets].reverse().find(s => s.completed_at);
        if (lastCompletedSet) {
            if (lastCompletedSet.reps >= 12) return { text: "Sube peso (+2.5kg)", color: "text-green-400" };
            if (lastCompletedSet.reps < 8) return { text: "Mantén o baja peso", color: "text-yellow-400" };
        }
        return null;
    };

    if (loading) return null;

    if (completedWorkoutData) {
        return <CompletionScreen data={completedWorkoutData} showConfetti={showConfetti} navigate={navigate} />;
    }

    return (
        <div className={cn("flex flex-col h-[100dvh] bg-background overflow-hidden relative", isFocusMode ? "z-[100]" : "")}>
            {/* Hidden Audio Player */}
            <audio ref={audioRef} loop src="https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=lofi-study-112191.mp3" />

            {/* Header - Hidden in Focus Mode */}
            <AnimatePresence>
                {!isFocusMode && (
                    <motion.header 
                        initial={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="flex-none px-4 pt-4 pb-2 bg-background/80 backdrop-blur-md z-20 border-b border-white/5 safe-area-top"
                    >
                        <div className="flex items-center justify-between mb-2">
                            <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="h-8 w-8">
                                <ArrowLeft className="h-5 w-5" />
                            </Button>
                            
                            <div className="flex gap-2">
                                {/* Music Toggle */}
                                <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    onClick={toggleMusic}
                                    className={cn("h-8 w-8 rounded-full transition-colors", isPlayingMusic ? "bg-[var(--neon-blue)] text-black" : "bg-white/5 text-muted-foreground")}
                                >
                                    {isPlayingMusic ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                                </Button>

                                {/* Voice Toggle */}
                                {voiceSupported && (
                                    <Button 
                                        variant="ghost" 
                                        size="icon" 
                                        onClick={toggleListening}
                                        className={cn("h-8 w-8 rounded-full transition-colors", isListening ? "bg-red-500 text-white animate-pulse" : "bg-white/5 text-muted-foreground")}
                                    >
                                        {isListening ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
                                    </Button>
                                )}

                                <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    onClick={() => setIsFocusMode(true)} 
                                    className="h-8 w-8 text-muted-foreground"
                                >
                                    <Maximize2 className="h-4 w-4" />
                                </Button>
                            </div>
                        </div>

                        {/* Live Stats Widget */}
                        <WorkoutStatsBar 
                            duration={workoutDuration} 
                            calories={burnedCalories} 
                            volume={currentVolume} 
                            setsDone={completedSets} 
                        />
                        
                        {/* Progress Bar */}
                        <div className="h-1 w-full bg-secondary rounded-full overflow-hidden mt-3">
                            <motion.div 
                                className="h-full bg-[var(--neon-blue)] shadow-[0_0_10px_var(--neon-blue)]"
                                initial={{ width: 0 }}
                                animate={{ width: `${progressPercentage}%` }}
                                transition={{ duration: 0.5 }}
                            />
                        </div>
                    </motion.header>
                )}
            </AnimatePresence>

            {/* Focus Mode Exit Button (Floating) */}
            <AnimatePresence>
                {isFocusMode && (
                    <motion.button
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="fixed top-4 right-4 z-50 bg-black/50 backdrop-blur-md p-2 rounded-full border border-white/10 safe-area-top"
                        onClick={() => setIsFocusMode(false)}
                    >
                        <Minimize2 className="w-5 h-5 text-white" />
                    </motion.button>
                )}
            </AnimatePresence>

            {/* Confetti Overlay */}
            {showConfetti && <Confetti count={50} colors={['#007AFF', '#ffffff', '#00ffaa']} />}

            {/* Main Content - Added safe-area-bottom padding */}
            <div className="flex-1 overflow-y-auto no-scrollbar pb-32 safe-area-bottom" ref={scrollRef}>
                <div className={cn("px-4 py-6 space-y-6", isFocusMode ? "pt-12" : "")}>
                    {exercises.map((exercise, index) => {
                        const isActive = index === activeExerciseIndex;
                        const isDone = exercise.sets.every(s => s.completed_at);
                        const suggestion = getSmartSuggestion(exercise);
                        
                        return (
                            <motion.div 
                                key={exercise.id}
                                id={`exercise-${index}`}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ 
                                    opacity: isActive ? 1 : 0.5, 
                                    scale: isActive ? 1 : 0.98,
                                    y: 0
                                }}
                                className={cn(
                                    "rounded-2xl overflow-hidden border transition-all duration-300 relative",
                                    isActive 
                                        ? "bg-[#16171a] border-[var(--neon-blue)]/30 shadow-[0_0_20px_rgba(0,0,0,0.5)]" 
                                        : "bg-card/30 border-white/5 grayscale-[0.8]"
                                )}
                                onClick={() => !isActive && jumpToExercise(index)}
                            >
                                {/* Active Indicator Strip */}
                                {isActive && <div className="absolute left-0 top-0 bottom-0 w-1 bg-[var(--neon-blue)]" />}

                                {/* Exercise Header */}
                                <div className="p-4 border-b border-white/5 flex justify-between items-start bg-gradient-to-r from-transparent via-white/[0.02] to-transparent">
                                    <div className="flex-1 mr-2">
                                        <div className="flex items-center gap-2 mb-1">
                                            <span className="text-[9px] font-black bg-white/10 px-1.5 py-0.5 rounded text-white/70">
                                                {index + 1}/{exercises.length}
                                            </span>
                                            <h3 className={cn("font-bold text-lg leading-tight", isActive ? "text-white" : "text-muted-foreground")}>
                                                {exercise.name}
                                            </h3>
                                        </div>
                                        
                                        {/* Smart Suggestion Badge */}
                                        {isActive && suggestion && (
                                            <motion.div 
                                                initial={{ opacity: 0, x: -10 }}
                                                animate={{ opacity: 1, x: 0 }}
                                                className="flex items-center gap-1.5 mb-2"
                                            >
                                                <Lightbulb className={cn("w-3 h-3", suggestion.color)} />
                                                <span className={cn("text-[10px] font-bold uppercase", suggestion.color)}>{suggestion.text}</span>
                                            </motion.div>
                                        )}

                                        {isActive && (
                                            <div className="flex flex-wrap items-center gap-3 mt-2">
                                                <button 
                                                    className={cn("flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider transition-colors", showInfo[exercise.id] ? "text-[var(--neon-blue)]" : "text-muted-foreground")}
                                                    onClick={(e) => { e.stopPropagation(); setShowInfo(prev => ({...prev, [exercise.id]: !prev[exercise.id]})); }}
                                                >
                                                    <Info className="w-3 h-3" /> Info
                                                </button>
                                                <button 
                                                    className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground hover:text-white"
                                                    onClick={(e) => { e.stopPropagation(); setShowNotes(prev => ({...prev, [exercise.id]: !prev[exercise.id]})); }}
                                                >
                                                    <FileText className="w-3 h-3" /> Notas
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                    {isDone && <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center text-green-500 shadow-[0_0_10px_rgba(34,197,94,0.3)]"><Check className="w-5 h-5" /></div>}
                                </div>

                                {/* Graph & Info (Expanded) */}
                                <AnimatePresence>
                                    {isActive && (
                                        <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="overflow-hidden bg-black/20">
                                            <div className="px-4 pt-0 pb-2">
                                                {/* Mini Chart */}
                                                <ExerciseChart />
                                            </div>
                                        </motion.div>
                                    )}
                                </AnimatePresence>

                                <ExerciseInfoCard exercise={exercise} isOpen={showInfo[exercise.id]} onToggle={() => setShowInfo(prev => ({...prev, [exercise.id]: !prev[exercise.id]}))} />

                                {/* Sets Header */}
                                <div className="grid grid-cols-12 gap-1 px-2 py-2 bg-black/30 text-[9px] font-bold text-muted-foreground uppercase tracking-wider text-center border-y border-white/5">
                                    <div className="col-span-1">#</div>
                                    <div className="col-span-3">Prev</div>
                                    <div className="col-span-3">Kg</div>
                                    <div className="col-span-3">Reps</div>
                                    <div className="col-span-2">OK</div>
                                </div>

                                {/* Sets Rows */}
                                <div className="p-2 space-y-1.5">
                                    {exercise.sets.map((set, i) => (
                                        <motion.div 
                                            key={set.id} 
                                            layout
                                            className={cn(
                                                "grid grid-cols-12 gap-2 items-center p-2 rounded-xl transition-all border",
                                                set.completed_at 
                                                    ? "bg-green-500/10 border-green-500/20" 
                                                    : "bg-[#0A0A0A] border-white/5"
                                            )}
                                        >
                                            <div className="col-span-1 text-center font-bold text-muted-foreground text-xs">{i + 1}</div>
                                            <div className="col-span-3 text-center">
                                                <span className="text-[10px] text-muted-foreground/50 font-mono">20kg x 12</span>
                                            </div>
                                            <div className="col-span-3">
                                                <input 
                                                    type="number" 
                                                    value={set.peso || ''} 
                                                    onChange={(e) => handleSetUpdate(set.id, 'peso', e.target.value)}
                                                    className={cn(
                                                        "w-full bg-secondary/50 border border-transparent focus:border-[var(--neon-blue)] rounded-lg py-2 text-center font-bold text-sm transition-all outline-none p-0 h-9",
                                                        set.completed_at && "text-green-400"
                                                    )}
                                                    placeholder="0"
                                                />
                                            </div>
                                            <div className="col-span-3">
                                                <input 
                                                    type="number" 
                                                    value={set.reps || ''} 
                                                    onChange={(e) => handleSetUpdate(set.id, 'reps', e.target.value)}
                                                    className={cn(
                                                        "w-full bg-secondary/50 border border-transparent focus:border-[var(--neon-blue)] rounded-lg py-2 text-center font-bold text-sm transition-all outline-none p-0 h-9",
                                                        set.completed_at && "text-green-400"
                                                    )}
                                                    placeholder="0"
                                                />
                                            </div>
                                            <div className="col-span-2 flex justify-center">
                                                <button 
                                                    onClick={() => handleSetComplete(set.id, !set.completed_at)}
                                                    className={cn(
                                                        "w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-300",
                                                        set.completed_at 
                                                            ? "bg-green-500 text-black shadow-[0_0_15px_rgba(34,197,94,0.4)] scale-105" 
                                                            : "bg-white/5 text-muted-foreground hover:bg-white/10 border border-white/5"
                                                    )}
                                                >
                                                    <Check className="w-4 h-4" strokeWidth={4} />
                                                </button>
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>

                                {/* Actions Footer */}
                                {isActive && (
                                    <div className="px-4 py-3 border-t border-white/5 flex justify-between items-center bg-black/20">
                                        <Button 
                                            variant="ghost" 
                                            size="sm" 
                                            className="text-[10px] text-red-400/70 hover:text-red-400 hover:bg-red-900/10 h-8 px-2"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                const lastSet = exercise.sets[exercise.sets.length - 1];
                                                if(lastSet) handleDeleteSet(lastSet.id);
                                            }}
                                        >
                                            <Trash2 className="w-3 h-3 mr-1" /> - Set
                                        </Button>
                                        <Button 
                                            variant="secondary" 
                                            size="sm" 
                                            className="text-[10px] h-8 font-bold uppercase tracking-wider bg-white/5 hover:bg-white/10"
                                            onClick={(e) => { e.stopPropagation(); handleAddSet(exercise.id); }}
                                        >
                                            <Plus className="w-3 h-3 mr-1" /> Set
                                        </Button>
                                    </div>
                                )}
                            </motion.div>
                        );
                    })}
                </div>
            </div>

            {/* Bottom Actions Bar - Hidden in Focus Mode to maximize screen */}
            {!isFocusMode && (
                <div className="flex-none p-4 bg-background/90 backdrop-blur-lg border-t border-white/10 z-30 safe-area-bottom">
                     <Button 
                        onClick={handleFinishWorkout} 
                        className="w-full h-12 text-sm font-black uppercase tracking-widest bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-lg shadow-blue-900/20 border-none"
                    >
                        Finalizar Sesión
                    </Button>
                </div>
            )}

            {/* Rest Timer Overlay */}
            <AnimatePresence>
                {restTimer.isActive && (
                    <RestTimer 
                        duration={restTimer.duration} 
                        endTime={restTimer.endTime}
                        minimized={restTimer.minimized}
                        onMinimize={() => setRestTimer(prev => ({...prev, minimized: !prev.minimized}))}
                        onClose={() => setRestTimer(prev => ({...prev, isActive: false}))}
                        onAdd={(sec) => setRestTimer(prev => ({...prev, endTime: prev.endTime + sec * 1000}))}
                    />
                )}
            </AnimatePresence>
        </div>
    );
};

// Simplified Completion Screen for brevity
const CompletionScreen = ({ data, showConfetti, navigate }) => (
    <div className="flex flex-col items-center justify-center min-h-screen p-6 text-center space-y-8 bg-background relative overflow-hidden">
        {showConfetti && <Confetti />}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-green-500/10 blur-[100px] rounded-full pointer-events-none" />
        <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="w-32 h-32 bg-green-500 rounded-full flex items-center justify-center mb-4 shadow-[0_0_50px_rgba(34,197,94,0.4)] relative z-10">
            <Check className="w-16 h-16 text-black" strokeWidth={4} />
        </motion.div>
        <div className="relative z-10">
            <h1 className="text-4xl font-black italic uppercase tracking-tighter mb-2">¡Misión Cumplida!</h1>
            <p className="text-muted-foreground text-lg">Has dominado este entrenamiento.</p>
        </div>
        <Button onClick={() => navigate('/home')} className="w-full max-w-sm h-14 text-lg font-bold rounded-full relative z-10 mt-8">Volver al Inicio</Button>
    </div>
);

export default WorkoutScreen;