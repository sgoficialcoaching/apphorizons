import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { getWorkoutTemplates, createWorkout, saveActiveRoutine } from '@/lib/database';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { toast } from '@/components/ui/use-toast';
import { ArrowLeft, Dumbbell, Play, Info } from 'lucide-react';

const WorkoutTemplatesScreen = () => {
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {
    const allTemplates = getWorkoutTemplates();
    setTemplates(allTemplates);
    setLoading(false);
  }, []);
  
  const handleUseTemplate = (template) => {
    if (!user) {
        toast({
            title: "Error",
            description: "Debes iniciar sesión para usar una plantilla.",
            variant: "destructive"
        });
        return;
    }

    // Save the selected routine level for calendar generation
    if (template.level) {
        saveActiveRoutine(user.id, template.level);
    }

    // Convert template items to initial sets structure for createWorkout
    const workoutSets = template.items.flatMap(item => 
        Array.from({ length: item.series }, (_, i) => ({
            exercise_id: item.exercise_id,
            set_index: i + 1,
            // Can pass target reps if needed later
        }))
    );
    
    const newWorkout = createWorkout(user.id, {
        templateId: template.id,
        programName: template.name,
        sets: workoutSets, // Pass sets to be created
    });
    
    toast({
        title: "¡Rutina Activada!",
        description: `Has empezado el programa "${template.name}". Tu calendario se ha actualizado.`,
        className: "bg-primary text-black border-none"
    });

    navigate(`/workout/${newWorkout.id}`);
  };

  const renderTemplates = () => {
    if (loading) {
      return [...Array(3)].map((_, i) => (
        <div key={i} className="glass-effect rounded-2xl p-6 animate-pulse">
            <div className="h-6 bg-secondary w-3/4 rounded mb-3"></div>
            <div className="h-4 bg-secondary w-1/2 rounded"></div>
        </div>
      ));
    }
    return templates.map((template, idx) => (
      <motion.div
        key={template.id}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: idx * 0.1 }}
        className="glass-effect rounded-2xl p-0 overflow-hidden group border border-white/5 hover:border-primary/50 transition-colors"
      >
        <div className="p-6">
            <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                        idx === 0 ? 'bg-green-500/20 text-green-400' : 
                        idx === 1 ? 'bg-yellow-500/20 text-yellow-400' : 
                        'bg-red-500/20 text-red-400'
                    }`}>
                        <Dumbbell className="w-6 h-6" />
                    </div>
                    <div>
                        <h3 className="text-xl font-bold leading-none mb-1">{template.name}</h3>
                        <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{template.items.length} Ejercicios</p>
                    </div>
                </div>
            </div>
            
            <p className="text-muted-foreground text-sm mb-6 leading-relaxed">{template.description}</p>
            
            <div className="flex gap-3">
                <Button onClick={() => handleUseTemplate(template)} className="flex-1 btn-primary font-bold py-6 group-hover:shadow-lg group-hover:shadow-primary/20 transition-all">
                    <Play className="w-4 h-4 mr-2 fill-current" /> USAR RUTINA
                </Button>
            </div>
        </div>
        <div className="bg-secondary/30 p-3 text-center text-[10px] uppercase tracking-widest font-bold text-muted-foreground group-hover:bg-primary/10 group-hover:text-primary transition-colors">
            Diseñada por Sergi Constance
        </div>
      </motion.div>
    ));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-2">
        <Button variant="ghost" size="icon" onClick={() => navigate('/boost')}>
            <ArrowLeft />
        </Button>
        <div>
            <h2 className="text-3xl font-bold">Rutinas Oficiales</h2>
            <p className="text-muted-foreground">Selecciona tu nivel para empezar.</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 gap-6">
        {renderTemplates()}
      </div>
      
      <div className="text-center p-8 text-muted-foreground text-sm">
        <p>¿Buscas algo más específico? <br/>Usa el creador de rutinas manual en la sección anterior.</p>
      </div>
    </div>
  );
};

export default WorkoutTemplatesScreen;