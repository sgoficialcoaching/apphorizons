import React, { Suspense, lazy } from 'react';
import { motion } from 'framer-motion';
import { Briefcase, ShoppingBag, Users } from 'lucide-react';
import { Helmet } from 'react-helmet';
import LoadingScreen from '@/components/common/LoadingScreen';
import { useNavigate, Routes, Route } from 'react-router-dom';

const TradingCampus = lazy(() => import('@/components/finance/TradingCampus'));
const EcommerceCampus = lazy(() => import('@/components/finance/EcommerceCampus'));
const AffiliateCampus = lazy(() => import('@/components/finance/AffiliateCampus'));

const CampusCard = ({ title, description, icon, path, status, progress }) => {
    const navigate = useNavigate();
    const isComingSoon = status === 'Próximamente';

    const cardVariants = {
        initial: { opacity: 0, y: 50 },
        animate: { opacity: 1, y: 0, transition: { duration: 0.5 } },
        hover: { y: -10, scale: 1.03, boxShadow: '0 20px 30px rgba(0,0,0,0.2)' }
    };

    return (
        <motion.div
            variants={cardVariants}
            whileHover="hover"
            onClick={() => !isComingSoon && navigate(path)}
            className={`glass-effect p-6 rounded-2xl cursor-pointer flex flex-col h-full relative overflow-hidden group ${isComingSoon ? 'cursor-not-allowed' : ''}`}
            style={{ perspective: '1000px' }}
        >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-secondary/5 to-transparent opacity-50 group-hover:opacity-100 transition-opacity duration-300"></div>
            <motion.div className="absolute -top-1/4 -right-1/4 w-1/2 h-1/2 bg-primary/20 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></motion.div>
            
            <div className="flex justify-between items-start z-10">
                {icon}
                <span className={`text-xs font-bold px-3 py-1 rounded-full border ${
                    status === 'Activo' ? 'border-green-400/50 bg-green-500/10 text-green-300' 
                    : 'border-amber-400/50 bg-amber-500/10 text-amber-300'
                }`}>
                    {status}
                </span>
            </div>
            <div className="flex-grow mt-4 z-10">
                <h3 className="font-bold text-lg tracking-wide">{title}</h3>
                <p className="text-sm text-muted-foreground mt-1">{description}</p>
            </div>
            <div className="mt-4 z-10">
                <div className="w-full bg-black/20 h-2 rounded-full overflow-hidden">
                    <motion.div
                        className="h-full bg-gradient-to-r from-primary/70 to-primary"
                        initial={{ width: 0 }}
                        animate={{ width: `${progress}%` }}
                        transition={{ duration: 1, ease: "easeOut" }}
                    />
                </div>
                <p className="text-xs text-right mt-1.5 text-muted-foreground">{progress}% completado</p>
            </div>
        </motion.div>
    );
};

const FinanceDashboard = () => {
    return (
        <div className="space-y-8">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <h1 className="text-3xl sm:text-4xl font-bold tracking-tighter">Campus</h1>
              <p className="text-muted-foreground mt-2 text-lg">Tu Matriz de la Riqueza.</p>
            </motion.div>
            <motion.div 
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
                initial="initial"
                animate="animate"
                variants={{
                    animate: { transition: { staggerChildren: 0.1 } }
                }}
            >
                <CampusCard 
                    title="Campus de Trading"
                    description="Domina los mercados financieros, desde cripto hasta forex."
                    icon={<Briefcase className="w-8 h-8 text-primary" />}
                    path="trading"
                    status="Activo"
                    progress={45}
                />
                <CampusCard 
                    title="Campus de E-commerce"
                    description="Construye tu imperio online con dropshipping y marcas personales."
                    icon={<ShoppingBag className="w-8 h-8 text-primary" />}
                    path="ecommerce"
                    status="Activo"
                    progress={10}
                />
                <CampusCard 
                    title="Campus de Afiliados"
                    description="Genera ingresos pasivos promocionando productos de alto valor."
                    icon={<Users className="w-8 h-8 text-primary" />}
                    path="affiliate"
                    status="Activo"
                    progress={5}
                />
            </motion.div>
        </div>
    );
};


const FinanceScreen = () => {
  return (
    <>
      <Helmet>
        <title>Campus - Sergi Constance App</title>
        <meta name="description" content="Explora los campus de generación de riqueza y domina tus finanzas." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Suspense fallback={<LoadingScreen />}>
          <Routes>
            <Route index element={<FinanceDashboard />} />
            <Route path="trading" element={<TradingCampus />} />
            <Route path="ecommerce" element={<EcommerceCampus />} />
            <Route path="affiliate" element={<AffiliateCampus />} />
          </Routes>
        </Suspense>
      </motion.div>
    </>
  );
};
    
export default FinanceScreen;