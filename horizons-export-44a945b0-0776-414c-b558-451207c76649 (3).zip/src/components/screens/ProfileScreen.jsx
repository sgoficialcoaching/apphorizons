import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Crown, Download, Shield, CreditCard, Star, User, Palette, Bell, LogOut, HeartPulse, Apple } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { exportUserData, getNutritionProfile } from '@/lib/database';
import { getUserProgress } from '@/lib/gamification';
import SubscriptionModal from '@/components/subscription/SubscriptionModal';
import NotificationSettings from '@/components/profile/NotificationSettings';
import AppearanceSettings from '@/components/profile/AppearanceSettings';
import NutritionSettings from '@/components/profile/NutritionSettings';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { checkSubscriptionStatus } from '@/lib/subscription';
import BoostiesWarning from '@/components/common/BoostiesWarning';

const ProfileScreen = () => {
  const { user, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [activeScreen, setActiveScreen] = useState('main'); // main, notifications, appearance, nutrition
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [tokens, setTokens] = useState(0);
  const [totalWorkouts, setTotalWorkouts] = useState(0);
  const [totalPRs, setTotalPRs] = useState(0);
  const [membershipDate, setMembershipDate] = useState('');
  const [subscriptionStatus, setSubscriptionStatus] = useState(null);
  const [nutritionProfile, setNutritionProfile] = useState(null);

  useEffect(() => {
    if (user) {
      // Sync with Supabase for gamification data
      const loadGamification = async () => {
          const progress = await getUserProgress(user.id);
          setTokens(progress?.boosties || 0);
      };
      loadGamification();

      setTotalWorkouts(JSON.parse(localStorage.getItem(`workouts_${user.id}`) || '[]').length);
      setTotalPRs(JSON.parse(localStorage.getItem(`prs_${user.id}`) || '[]').length);
      setMembershipDate(new Date(user.created_at).toLocaleDateString('es-ES', { month: 'short', year: 'numeric' }));
      
      const subStatus = checkSubscriptionStatus(user.id);
      setSubscriptionStatus(subStatus);
      
      const profile = getNutritionProfile(user.id);
      setNutritionProfile(profile);
      
      if (location.state?.screen) {
        setActiveScreen(location.state.screen);
        navigate(location.pathname, { replace: true });
      }

    }
  }, [user, location.state, navigate, location.pathname]);

  const handleBackToMain = (refresh = false) => {
    setActiveScreen('main');
    if (refresh && user) {
        setNutritionProfile(getNutritionProfile(user.id));
    }
  };

  if (!user) {
    return null;
  }

  const handleExportData = () => {
    exportUserData(user.id);
    toast({
      title: '✅ ¡Datos exportados!',
      description: 'Tus datos han sido descargados en formato JSON.'
    });
  };

  const handleDeleteAccount = () => {
    toast({
      title: '🚧 Función no implementada',
      description: 'La eliminación de cuenta estará disponible pronto.'
    });
  };

  const handleHealthConnect = () => {
    toast({
      title: '🚧 ¡Función en desarrollo!',
      description: 'La integración con Apple Health y Google Fit llegará muy pronto. ¡Gracias por tu interés!',
    });
  };

  if (activeScreen === 'notifications') {
    return <NotificationSettings user={user} onBack={handleBackToMain} />;
  }
  
  if (activeScreen === 'appearance') {
    return <AppearanceSettings onBack={handleBackToMain} />;
  }

  if (activeScreen === 'nutrition') {
    return <NutritionSettings user={user} profile={nutritionProfile} onBack={() => handleBackToMain(true)} />;
  }

  const userName = user?.user_metadata?.full_name || user?.email || 'Usuario';
  const userInitial = userName?.charAt(0)?.toUpperCase() || 'U';

  return (
    <div className="space-y-6 pb-20">
      <div>
        <h2 className="text-3xl font-bold mb-2">Perfil</h2>
        <p className="text-muted-foreground">Gestiona tu cuenta y suscripción.</p>
      </div>

      <div className="glass-effect rounded-2xl p-6">
        <div className="flex flex-col sm:flex-row items-center gap-4 mb-6">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary to-amber-400 flex items-center justify-center text-4xl font-bold text-primary-foreground">
            {userInitial}
          </div>
          <div className="flex-1 text-center sm:text-left">
            <h3 className="text-2xl font-bold">{userName}</h3>
            <p className="text-muted-foreground">{user.email}</p>
            <div className="flex items-center justify-center sm:justify-start gap-4 mt-2">
              {subscriptionStatus?.isPremium && (
                <div className="flex items-center gap-2">
                  <Crown className="w-4 h-4 text-primary" />
                  <span className="text-primary font-semibold">
                    Miembro {subscriptionStatus.plan.toUpperCase()}
                  </span>
                </div>
              )}
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 text-primary" />
                <span className="font-semibold">{tokens} Boosts</span>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="stat-card">
            <p className="text-muted-foreground text-sm mb-1">Miembro desde</p>
            <p className="text-xl font-bold">{membershipDate}</p>
          </div>
          <div className="stat-card">
            <p className="text-muted-foreground text-sm mb-1">Entrenos Totales</p>
            <p className="text-xl font-bold">{totalWorkouts}</p>
          </div>
          <div className="stat-card">
            <p className="text-muted-foreground text-sm mb-1">Récords Personales</p>
            <p className="text-xl font-bold">{totalPRs}</p>
          </div>
        </div>
      </div>
      
      <div className="glass-effect rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
            <HeartPulse className="w-6 h-6 text-red-500" />
            <h3 className="text-xl font-bold">Integraciones de Salud</h3>
        </div>
        <p className="text-muted-foreground mb-4">Sincroniza tus datos de salud para un seguimiento más preciso.</p>
        <Button onClick={handleHealthConnect} className="w-full btn-secondary flex items-center justify-center gap-2">
            <User className="w-5 h-5" />
            Conectar con Apple Salud / Google Fit
        </Button>
      </div>

      <div className="glass-effect rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
            <CreditCard className="w-6 h-6 text-primary" />
            <h3 className="text-xl font-bold">Suscripción</h3>
        </div>

        {subscriptionStatus?.isPremium ? (
          <div className="space-y-4">
            <div className="p-4 bg-primary/10 rounded-xl border border-primary/20">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-lg">Plan {subscriptionStatus.plan.toUpperCase()}</span>
                <span className="premium-badge">ACTIVO</span>
              </div>
              <p className="text-sm text-muted-foreground">
                {subscriptionStatus.trialEnd && new Date(subscriptionStatus.trialEnd) > new Date()
                  ? `La prueba termina el ${new Date(subscriptionStatus.trialEnd).toLocaleDateString()}`
                  : `Se renueva el ${new Date(subscriptionStatus.currentPeriodEnd).toLocaleDateString()}`
                }
              </p>
            </div>
            <Button
              variant="outline"
              className="w-full btn-secondary"
              onClick={() => toast({ title: '🚧 Función no implementada', description: 'La gestión de suscripción llegará pronto.' })}
            >
              Gestionar Suscripción
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 bg-secondary rounded-xl border border-border">
              <p className="font-semibold mb-1">Plan Básico</p>
              <p className="text-sm text-muted-foreground">Funciones limitadas</p>
            </div>
            <Button
              onClick={() => setShowSubscriptionModal(true)}
              className="w-full btn-primary"
            >
              <Crown className="w-4 h-4 mr-2" />
              Mejorar a Premium
            </Button>
          </div>
        )}
      </div>

      <div className="glass-effect rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <Shield className="w-6 h-6 text-green-400" />
          <h3 className="text-xl font-bold">Ajustes y Privacidad</h3>
        </div>

        <div className="space-y-3">
          <Button
            onClick={() => setActiveScreen('appearance')}
            variant="outline"
            className="w-full justify-start btn-secondary"
          >
            <Palette className="w-4 h-4 mr-2" />
            Apariencia
          </Button>
          <Button
            onClick={() => setActiveScreen('nutrition')}
            variant="outline"
            className="w-full justify-start btn-secondary"
          >
            <Apple className="w-4 h-4 mr-2" />
            Perfil Nutricional
          </Button>
          <Button
            onClick={() => setActiveScreen('notifications')}
            variant="outline"
            className="w-full justify-start btn-secondary"
          >
            <Bell className="w-4 h-4 mr-2" />
            Ajustes de Notificaciones
          </Button>
          <Button
            onClick={handleExportData}
            variant="outline"
            className="w-full justify-start btn-secondary"
          >
            <Download className="w-4 h-4 mr-2" />
            Exportar mis Datos (GDPR)
          </Button>

           <Button
            onClick={handleDeleteAccount}
            variant="destructive"
            className="w-full justify-start"
          >
            <User className="w-4 h-4 mr-2" />
            Eliminar Cuenta
          </Button>
          
           <Button
            onClick={signOut}
            variant="ghost"
            className="w-full justify-start text-muted-foreground hover:text-red-500"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Cerrar Sesión
          </Button>
        </div>
      </div>
      
      <BoostiesWarning />

      {showSubscriptionModal && (
        <SubscriptionModal
          onClose={() => setShowSubscriptionModal(false)}
        />
      )}
    </div>
  );
};

export default ProfileScreen;