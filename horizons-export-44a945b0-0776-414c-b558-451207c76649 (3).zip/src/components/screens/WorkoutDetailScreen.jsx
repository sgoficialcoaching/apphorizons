import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { getWorkoutById, getSetsForWorkout, getExerciseById, addSetToWorkout, updateSet, deleteSet, completeSet, finishWorkout, getUserPRs } from '@/lib/database';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { ArrowLeft, Plus, Trash2, Copy, Check, ShieldCheck, Trophy, Crown, Dumbbell, Timer, MoreVertical } from 'lucide-react';
import ExerciseSearchModal from '@/components/workout/ExerciseSearchModal';
import RestTimer from '@/components/workout/RestTimer';

const WorkoutDetailScreen = () => {
    const { workoutId } = useParams();
    const navigate = useNavigate();
    const { user } = useAuth();

    const [workout, setWorkout] = useState(null);
    const [sets, setSets] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isFinishing, setIsFinishing] = useState(false);
    const [isSearchOpen, setSearchOpen] = useState(false);
    const [newPrsInSession, setNewPrsInSession] = useState([]);
    const [restTimer, setRestTimer] = useState({ active: false, duration: 0, key: 0 });

    const fetchData = useCallback(() => {
        if (!user) return;
        setLoading(true);
        const workoutData = getWorkoutById(user.id, workoutId);
        if (workoutData) {
            setWorkout(workoutData);
            const setsData = getSetsForWorkout(user.id, workoutId);
            setSets(setsData.sort((a,b) => a.set_index - b.set_index));
        } else {
            navigate('/workout');
            toast({ title: "Error", description: "Entrenamiento no encontrado.", variant: "destructive" });
        }
        setLoading(false);
    }, [user, workoutId, navigate]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const groupedSets = useMemo(() => {
        const groups = sets.reduce((acc, set) => {
            if (!acc[set.exercise_id]) {
                const exercise = getExerciseById(set.exercise_id);
                acc[set.exercise_id] = { exercise, sets: [] };
            }
            acc[set.exercise_id].sets.push(set);
            return acc;
        }, {});

        const workoutOrder = workout?.exercise_order || Object.keys(groups);
        
        return workoutOrder.map(exId => groups[exId]).filter(g => g && g.exercise);

    }, [sets, workout]);
    
    const handleAddExercise = (exerciseId) => {
        addSetToWorkout(user.id, workoutId, exerciseId);
        fetchData();
        setSearchOpen(false);
        toast({ title: "Ejercicio añadido", description: "Se ha añadido una nueva serie a tu entreno."});
    };
    
    const handleAddSeries = (exerciseId) => {
        addSetToWorkout(user.id, workoutId, exerciseId);
        fetchData();
    }

    const handleUpdateSet = (setId, field, value) => {
        const numericValue = value === '' ? '' : Number(value);
        if (!isNaN(numericValue)) {
            setSets(currentSets => currentSets.map(s => s.id === setId ? {...s, [field]: numericValue} : s));
            updateSet(user.id, setId, {[field]: numericValue});
        }
    };

    const handleToggleSetComplete = (set) => {
        const isComplete = !set.completed_at;
        const { newPR } = completeSet(user.id, set.id, isComplete);
        fetchData();

        if (isComplete) {
            const exercise = getExerciseById(set.exercise_id);
            if (exercise && exercise.rest_time_sec) {
                setRestTimer({ active: true, duration: exercise.rest_time_sec, key: Date.now() });
            }
            toast({ title: "¡Serie completada!", description: "¡Buen trabajo!", icon: <Check className="text-green-500" /> });

            if (newPR) {
                setNewPrsInSession(prev => [...prev, newPR.id]);
                toast({
                    title: "👑 ¡NUEVO PR!",
                    description: `¡Récord batido en ${newPR.exerciseName}!`,
                    duration: 5000,
                    className: "bg-gradient-to-r from-amber-400 to-primary text-primary-foreground border-0",
                });
            }
        }
    };

    const handleFinishWorkout = async () => {
        setIsFinishing(true);
        const result = finishWorkout(user.id, workoutId);
        if (result.error) {
            toast({ title: "Error", description: result.error, variant: "destructive" });
            setIsFinishing(false);
            return;
        }

        let description = `¡Has ganado 30 Boosts por tu constancia!`;
        if (result.newPRs && result.newPRs.length > 0) {
            description += ` ¡Y has conseguido ${result.newPRs.length} nuevo${result.newPRs.length > 1 ? 's' : ''} PR!`;
        }

        toast({
            title: "🔥 ¡Entreno Finalizado!",
            description,
            duration: 6000,
            icon: <Trophy className="text-amber-400"/>
        });
        navigate('/workout');
    };

    if (loading) return <div className="text-center p-10">Cargando entrenamiento...</div>;
    if (!workout) return null;

    const completedSetsCount = sets.filter(s => s.completed_at).length;
    const totalSetsCount = sets.length;

    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 pb-24">
             <AnimatePresence>
                {isSearchOpen && <ExerciseSearchModal onClose={() => setSearchOpen(false)} onSelectExercise={handleAddExercise} />}
            </AnimatePresence>

            <div className="flex justify-between items-center">
                 <Button variant="ghost" size="icon" onClick={() => navigate('/workout')}>
                    <ArrowLeft />
                </Button>
                <h2 className="text-xl font-bold">{workout.program_name || 'Entrenamiento'}</h2>
                {workout.status !== 'done' && (
                    <Button onClick={handleFinishWorkout} disabled={isFinishing} className="btn-primary">
                        <Trophy className="w-4 h-4 mr-2" />
                        {isFinishing ? "..." : "Terminar"}
                    </Button>
                )}
            </div>
            
             <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                    <p className="text-sm text-muted-foreground">Duración</p>
                    <p className="font-bold text-lg">--:--</p>
                </div>
                 <div>
                    <p className="text-sm text-muted-foreground">Volumen</p>
                    <p className="font-bold text-lg">{Math.round(sets.reduce((acc, s) => acc + (s.completed_at ? s.peso * s.reps : 0), 0))} kg</p>
                </div>
                 <div>
                    <p className="text-sm text-muted-foreground">Series</p>
                    <p className="font-bold text-lg">{completedSetsCount}/{totalSetsCount}</p>
                </div>
            </div>

            <div className="space-y-6">
                <AnimatePresence>
                {groupedSets.map(({ exercise, sets: exerciseSets }) => (
                    <motion.div 
                        key={exercise.id} 
                        layout 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0 }}
                        className="bg-card rounded-2xl"
                    >
                        <div className="p-4 border-b border-border">
                            <h3 className="font-bold text-primary cursor-pointer" onClick={() => navigate(`/exercise/${exercise.id}`)}>{exercise.name}</h3>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                                <Timer className="w-4 h-4" />
                                <span>Descanso: {exercise.rest_time_sec || 90}s</span>
                            </div>
                        </div>
                        <div className="p-4 space-y-2">
                             <div className="grid grid-cols-6 gap-2 text-xs text-muted-foreground text-center">
                                <div className="col-span-1">SERIE</div>
                                <div className="col-span-2">ANTERIOR</div>
                                <div className="col-span-1">KG</div>
                                <div className="col-span-1">REPS</div>
                                <div className="col-span-1"></div>
                            </div>
                            <AnimatePresence>
                            {exerciseSets.map((set, setIndex) => (
                                <motion.div 
                                    key={set.id} 
                                    layout 
                                    initial={{ opacity: 0, y: -10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, x: -20, transition: { duration: 0.2 } }}
                                    className={`grid grid-cols-6 gap-2 items-center rounded-lg transition-colors ${set.completed_at ? 'bg-green-800/50' : ''}`}
                                >
                                    <span className="font-bold text-center text-lg">{set.set_index}</span>
                                    <div className="col-span-2 text-center text-sm text-muted-foreground">--</div>
                                    <input type="number" value={set.peso} onChange={e => handleUpdateSet(set.id, 'peso', e.target.value)} placeholder="0" className="w-full bg-input text-center rounded-md p-2 border-none" disabled={!!set.completed_at}/>
                                    <input type="number" value={set.reps} onChange={e => handleUpdateSet(set.id, 'reps', e.target.value)} placeholder="0" className="w-full bg-input text-center rounded-md p-2 border-none" disabled={!!set.completed_at}/>
                                    <Button size="icon" variant="ghost" onClick={() => handleToggleSetComplete(set)} className="mx-auto">
                                        <div className={`w-7 h-7 rounded-full flex items-center justify-center transition-all ${set.completed_at ? 'bg-green-500' : 'border-2 border-muted-foreground'}`}>
                                            {set.completed_at && <Check className="w-5 h-5 text-white" />}
                                        </div>
                                    </Button>
                                </motion.div>
                            ))}
                            </AnimatePresence>
                             <Button onClick={() => handleAddSeries(exercise.id)} variant="outline" className="w-full mt-2">
                                <Plus className="w-4 h-4 mr-2" /> Agregar Serie
                            </Button>
                        </div>
                    </motion.div>
                ))}
                </AnimatePresence>
            </div>

            {workout.status !== 'done' ? (
                <Button onClick={() => setSearchOpen(true)} variant="secondary" className="w-full">
                    <Plus className="w-4 h-4 mr-2" /> Añadir Ejercicio
                </Button>
            ) : (
                 <div className="glass-effect rounded-2xl p-6 text-center">
                    <Trophy className="w-12 h-12 text-primary mx-auto mb-4" />
                    <h3 className="text-2xl font-bold">¡Entrenamiento completado!</h3>
                    <p className="text-muted-foreground mt-2">Revisa tu rendimiento y prepárate para la próxima sesión.</p>
                </div>
            )}
             <AnimatePresence>
                {restTimer.active && (
                    <RestTimer
                        key={restTimer.key}
                        duration={restTimer.duration}
                        onFinish={() => setRestTimer({ ...restTimer, active: false })}
                        onClose={() => setRestTimer({ ...restTimer, active: false })}
                    />
                )}
            </AnimatePresence>
        </motion.div>
    );
};

export default WorkoutDetailScreen;