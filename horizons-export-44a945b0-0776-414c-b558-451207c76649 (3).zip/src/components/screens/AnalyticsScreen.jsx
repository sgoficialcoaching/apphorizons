import React, { useState, useEffect, useMemo, Suspense, lazy } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { BarChart, Dumbbell, Apple, Activity, TrendingUp, TrendingDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { getAnalyticsData } from '@/lib/analytics';
import { Helmet } from 'react-helmet';
import LoadingScreen from '@/components/common/LoadingScreen';
import { cn } from '@/lib/utils';

const LineChartComponent = lazy(() => import('@/components/analytics/LineChart'));
const DonutChartComponent = lazy(() => import('@/components/analytics/DonutChart'));
const HealthStatusWidget = lazy(() => import('@/components/analytics/HealthStatusWidget'));
const TrendCard = lazy(() => import('@/components/analytics/TrendCard'));


const StatCard = ({ title, value, change, unit, changeType, icon: Icon, color }) => {
    const isPositive = change >= 0;
    const changeColor = changeType === 'positive' 
        ? (isPositive ? 'text-green-400' : 'text-red-400')
        : (isPositive ? 'text-red-400' : 'text-green-400');
    
    return (
        <motion.div 
            className="glass-effect p-4 rounded-xl flex flex-col justify-between"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ scale: 1.03, transition: { duration: 0.2 } }}
        >
            <div className="flex justify-between items-center mb-2">
                <p className="text-sm font-medium text-muted-foreground">{title}</p>
                <div className="p-2 rounded-full" style={{backgroundColor: color + '20', color: color}}>
                  <Icon className="w-5 h-5" />
                </div>
            </div>
            <div>
              <p className="text-3xl font-bold">
                  {value}
                  {unit && <span className="text-lg ml-1 text-muted-foreground">{unit}</span>}
              </p>
              {change !== 'N/A' ? (
                  <div className={`flex items-center text-xs mt-1 ${changeColor}`}>
                      {change > 0 ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                      <span>{change.toFixed(1)}% vs. periodo anterior</span>
                  </div>
              ) : <div className="text-xs mt-1 text-muted-foreground h-4">N/A</div>}
            </div>
        </motion.div>
    );
};

const SummaryTab = ({ data, range }) => {
    if (!data) return <LoadingScreen />;
    const { summary = {}, previousSummary = {} } = data;

    const tonnage = summary.tonnage || 0;
    const prevTonnage = previousSummary.tonnage || 0;
    const tonnageChange = prevTonnage > 0 ? ((tonnage - prevTonnage) / prevTonnage) * 100 : 0;

    const adherence = summary.adherence || 0;
    const prevAdherence = previousSummary.adherence || 0;
    const adherenceChange = prevAdherence > 0 ? ((adherence - prevAdherence) / prevAdherence) * 100 : 0;

    const kcalVsTarget = (summary.avgKcal || 0) - (summary.avgTargetKcal || 0);

    const weight = summary.avgWeight || 0;
    const prevWeight = previousSummary.avgWeight || 0;
    const weightChange = prevWeight > 0 ? ((weight - prevWeight) / prevWeight) * 100 : 0;

    const summaryCards = [
      { title: `Tonelaje Total (${range}d)`, value: (tonnage / 1000).toFixed(1), unit: 't', change: tonnageChange, changeType: 'positive', icon: Dumbbell, color: 'hsl(var(--primary))' },
      { title: "Adherencia Entreno", value: Math.round(adherence), unit: '%', change: adherenceChange, changeType: 'positive', icon: BarChart, color: '#4c8bf5' },
      { title: "Kcal vs Objetivo", value: kcalVsTarget.toFixed(0), unit: 'kcal', change: 'N/A', changeType: 'neutral', icon: Apple, color: '#f56565' },
      { title: `Peso Promedio (${range}d)`, value: weight.toFixed(1), unit: 'kg', change: weightChange, changeType: 'negative', icon: TrendingUp, color: '#48bb78' },
    ];

    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full">
            {summaryCards.map((card, index) => <StatCard key={index} {...card} />)}
        </div>
    );
};

const ChartCard = ({ title, children }) => (
    <div className="glass-effect p-4 sm:p-6 rounded-xl h-[400px] flex flex-col">
        <h3 className="text-base sm:text-lg font-bold mb-4">{title}</h3>
        <div className="flex-grow">
            <Suspense fallback={<div className="h-full w-full flex items-center justify-center text-muted-foreground">Cargando gráfico...</div>}>
                {children}
            </Suspense>
        </div>
    </div>
);


const TrainingTab = ({ data }) => {
    const { training, progress } = data || {};
    
    const volumeByMuscleGroup = useMemo(() => Object.entries(training?.volumeByMuscleGroup || {})
      .map(([name, value]) => ({ name, value }))
      .sort((a,b) => b.value - a.value),
    [training]);

    const chartData = useMemo(() => progress?.map(p => ({
        date: new Date(p.date).toLocaleDateString('es-ES', { month: 'short', day: 'numeric' }),
        Volumen: p.tonnage,
        'Índice Fuerza': p.strengthIndex,
    })) || [], [progress]);

    if (!data) return <LoadingScreen />;

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 w-full">
            <ChartCard title="Volumen Total por Grupo Muscular">
                <DonutChartComponent data={volumeByMuscleGroup} />
            </ChartCard>
            <ChartCard title="Progresión de Volumen e Índice de Fuerza">
                <LineChartComponent data={chartData} lines={[{ key: 'Volumen', name:'Volumen (kg)', color: 'hsl(var(--primary))' }, { key: 'Índice Fuerza', name:'Índice Fuerza', color: '#A7ABB3', yAxisId: 'right' }]} />
            </ChartCard>
        </div>
    );
};

const NutritionTab = ({ data }) => {
    const { nutrition, progress } = data || {};

    const macroDistribution = useMemo(() => {
        const macros = nutrition?.avgMacros || { protein: 0, carbs: 0, fat: 0 };
        const totalGrams = macros.protein + macros.carbs + macros.fat;
        if (totalGrams === 0) return [];
        
        const totalKcal = (macros.protein * 4) + (macros.carbs * 4) + (macros.fat * 9);
        if (totalKcal === 0) return [];

        return [
            { name: 'Proteínas', grams: macros.protein, percentage: (macros.protein * 4 / totalKcal) * 100, color: '#4c8bf5' },
            { name: 'Carbs', grams: macros.carbs, percentage: (macros.carbs * 4 / totalKcal) * 100, color: 'hsl(var(--primary))' },
            { name: 'Grasas', grams: macros.fat, percentage: (macros.fat * 9 / totalKcal) * 100, color: '#f56565' },
        ];
    }, [nutrition]);


    const chartData = useMemo(() => progress?.map(p => ({
        date: new Date(p.date).toLocaleDateString('es-ES', { month: 'short', day: 'numeric' }),
        Calorías: p.kcal,
        Objetivo: p.targetKcal,
        Peso: p.weight,
    })) || [], [progress]);

    if (!data) return <LoadingScreen />;

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 w-full">
             <ChartCard title="Distribución Media de Macros">
                <DonutChartComponent data={macroDistribution} />
            </ChartCard>
            <ChartCard title="Progreso de Calorías y Peso">
               <LineChartComponent 
                  data={chartData} 
                  lines={[
                    { key: 'Calorías', name: 'Calorías', color: 'hsl(var(--primary))' }, 
                    { key: 'Objetivo', name: 'Objetivo', color: '#A7ABB3' }, 
                    { key: 'Peso', name: 'Peso', color: '#4c8bf5', yAxisId: 'right' }
                  ]}
                />
            </ChartCard>
        </div>
    );
};

const HealthTab = ({ data }) => {
    if (!data) return <LoadingScreen />;

    const { progress, trends } = data;

    const chartData = (key, name, color, yAxisId) => ({
      data: progress?.map(p => ({
          date: new Date(p.date).toLocaleDateString('es-ES', { month: 'short', day: 'numeric' }),
          [name]: p[key],
      })) || [],
      lines: [{ key: name, name, color, yAxisId }]
    });

    return (
        <div className="w-full space-y-6">
            <Suspense fallback={<div className="h-48 w-full flex items-center justify-center text-muted-foreground">Cargando estado...</div>}>
              <HealthStatusWidget trends={trends} />
            </Suspense>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Suspense fallback={<div className="h-96 w-full flex items-center justify-center text-muted-foreground">Cargando...</div>}>
                    <TrendCard title="Tendencia de Adherencia" trend={trends?.adherence}>
                        <LineChartComponent {...chartData('adherence', 'Adherencia', '#4c8bf5')} />
                    </TrendCard>
                    <TrendCard title="Tendencia de Fuerza" trend={trends?.strength}>
                        <LineChartComponent {...chartData('strengthIndex', 'Índice Fuerza', 'hsl(var(--primary))')} />
                    </TrendCard>
                    <TrendCard title="Tendencia de Peso Corporal" trend={trends?.weight}>
                        <LineChartComponent {...chartData('weight', 'Peso', '#48bb78', 'right')} />
                    </TrendCard>
                </Suspense>
            </div>
        </div>
    );
};

const AnalyticsScreen = () => {
    const { user } = useAuth();
    const location = useLocation();
    const navigate = useNavigate();

    const searchParams = new URLSearchParams(location.search);
    const activeTab = searchParams.get('tab') || 'training'; // Default to training
    const range = parseInt(searchParams.get('range') || '30', 10);

    const [analyticsData, setAnalyticsData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (user) {
            setLoading(true);
            try {
              const data = getAnalyticsData(user.id, range);
              setAnalyticsData(data);
            } catch (error) {
              console.error("Error fetching analytics:", error);
            } finally {
              setLoading(false);
            }
        }
    }, [user, range]);

    const handleTabChange = (tab) => {
        navigate(`/analytics?tab=${tab}&range=${range}`);
    };

    const handleRangeChange = (newRange) => {
        navigate(`/analytics?tab=${activeTab}&range=${newRange}`);
    };

    const tabs = [
        { id: 'training', label: 'Entreno', icon: Dumbbell },
        { id: 'nutrition', label: 'Nutrición', icon: Apple },
        { id: 'health', label: 'Progreso', icon: Activity },
    ];
    
    const rangeOptions = [
        { label: 'Semana', value: 7 },
        { label: 'Mes', value: 30 },
        { label: 'Trimestre', value: 90 },
        { label: 'Año', value: 365 },
    ];

    const renderContent = () => {
        if (loading) return <LoadingScreen />;
        switch (activeTab) {
            case 'training': return <TrainingTab data={analyticsData} />;
            case 'nutrition': return <NutritionTab data={analyticsData} />;
            case 'health': return <HealthTab data={analyticsData} />;
            default: return null;
        }
    };

    return (
        <>
            <Helmet>
                <title>Analíticas de Rendimiento - Boost</title>
                <meta name="description" content="Visualiza tu progreso de entrenamiento y nutrición con gráficos de vanguardia." />
            </Helmet>
            <div className="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto flex flex-col items-center">
                <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center w-full">
                    <h1 className="text-2xl sm:text-3xl font-bold">Centro de Analíticas</h1>
                    <p className="text-muted-foreground">Tu progreso, descifrado.</p>
                </motion.div>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full max-w-xl"> {/* Changed max-w-2xl to max-w-xl */}
                    <div className="flex items-center gap-0.5 bg-secondary p-1 rounded-md w-full sm:w-auto justify-center">
                        {tabs.map((tab) => (
                            <Button
                                key={tab.id}
                                variant='ghost'
                                onClick={() => handleTabChange(tab.id)}
                                className={cn(
                                    "transition-all duration-300 flex-1 sm:flex-initial flex items-center justify-center gap-2 rounded-md px-2 py-1 h-auto",
                                    activeTab === tab.id ? 'bg-background shadow-sm text-foreground font-bold' : 'text-muted-foreground'
                                )}
                            >
                                  <tab.icon className="w-4 h-4" />
                                  {tab.label}
                            </Button>
                        ))}
                    </div>
                     <div className="flex justify-center items-center gap-0.5 bg-secondary p-1 rounded-md w-full sm:w-auto">
                        {rangeOptions.map((r) => (
                            <Button
                                key={r.value}
                                variant='ghost'
                                onClick={() => handleRangeChange(r.value)}
                                className={cn(
                                    "transition-all duration-300 flex-1 sm:flex-initial text-xs sm:text-sm rounded-md px-2 py-1 h-auto",
                                    range === r.value ? 'bg-background shadow-sm text-foreground font-bold' : 'text-muted-foreground'
                                )}
                            >
                                {r.label}
                            </Button>
                        ))}
                    </div>
                </div>

                <AnimatePresence mode="wait">
                    <motion.div
                        key={activeTab + range}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="flex justify-center w-full"
                    >
                        {renderContent()}
                    </motion.div>
                </AnimatePresence>
            </div>
        </>
    );
};

export default AnalyticsScreen;