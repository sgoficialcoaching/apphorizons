import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const NavLink = ({ href, children, onClick }) => {
    const navigate = useNavigate();
    const handleClick = (e) => {
        if (href.startsWith('/')) {
            e.preventDefault();
            navigate(href);
        }
        if (onClick) onClick();
    };
    return (
        <a href={href} onClick={handleClick} className="block text-center text-white text-2xl font-bebas tracking-widest py-6 hover:text-primary transition-colors duration-300">
            {children}
        </a>
    );
};

const LandingScreen = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [showPromo, setShowPromo] = useState(true);
    const navigate = useNavigate();

    return (
        <>
            <Helmet>
                <title>Boost - 20% Descuento Black Friday | Sergi Constance</title>
                <meta name="description" content="Aprovecha el 20% de descuento en Boost por Black Friday. Únete a la comunidad de Sergi Constance y transforma tu físico." />
                <link rel="preconnect" href="https://fonts.googleapis.com" />
                <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
                <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@400;700&family=Poppins:wght@700;900&display=swap" rel="stylesheet" />
            </Helmet>

            <div className="relative w-full min-h-screen overflow-y-auto bg-black text-white">
                {/* Video Background - Fixed */}
                <div className="fixed top-0 left-0 w-full h-full z-0">
                    <video
                        autoPlay
                        loop
                        muted
                        playsInline
                        className="w-full h-full object-cover opacity-60"
                        poster="https://sergiconstance-9fn0dyoiqm.live-website.com/wp-content/uploads/2024/07/20210219_013745.jpg"
                    >
                        <source src="https://sergiconstance-9fn0dyoiqm.live-website.com/wp-content/uploads/2025/11/1119.mp4" type="video/mp4" />
                        Tu navegador no soporta el tag de video.
                    </video>
                    <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-black/70 via-black/40 to-black/90 z-10"></div>
                </div>

                <header className="fixed top-0 left-0 right-0 z-50 p-6 md:p-8">
                    <div className="container mx-auto flex justify-between items-center">
                        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}>
                            <img src="https://horizons-cdn.hostinger.com/44a945b0-0776-414c-b558-451207c76649/fb087dd1803a43139c7109f55ed3d3a5.png" alt="Boost Logo" className="h-10 md:h-14 drop-shadow-[0_0_10px_rgba(255,215,0,0.3)]" />
                        </motion.div>

                        <div className="flex items-center gap-4">
                            <motion.div
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ duration: 0.5, delay: 0.1 }}
                            >
                                <Button 
                                    onClick={() => navigate('/selection')}
                                    className="bg-primary text-black font-bold hover:bg-primary/90 rounded-full px-6 py-5"
                                >
                                    REGÍSTRATE
                                </Button>
                            </motion.div>

                            <motion.button 
                                onClick={() => setIsMenuOpen(!isMenuOpen)} 
                                className="p-3 rounded-full bg-black/20 backdrop-blur-md border border-white/10 text-white hover:bg-primary hover:text-black transition-all duration-300"
                                initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}
                            >
                                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
                            </motion.button>
                        </div>
                    </div>
                </header>

                <AnimatePresence>
                    {isMenuOpen && (
                        <motion.div
                            initial={{ opacity: 0, clipPath: "circle(0% at 100% 0%)" }}
                            animate={{ opacity: 1, clipPath: "circle(150% at 100% 0%)" }}
                            exit={{ opacity: 0, clipPath: "circle(0% at 100% 0%)" }}
                            transition={{ duration: 0.5, ease: "easeInOut" }}
                            className="fixed inset-0 bg-[#09090B] z-[60] flex flex-col justify-center items-center"
                        >
                            <nav className="flex flex-col gap-4">
                                <NavLink href="/home" onClick={() => {navigate('/'); setIsMenuOpen(false);}}>Iniciar sesión</NavLink>
                                <NavLink href="/selection" onClick={() => {navigate('/selection'); setIsMenuOpen(false);}}>Registrarse</NavLink>
                                <NavLink href="/preview-boost" onClick={() => {navigate('/preview-boost'); setIsMenuOpen(false);}}>App</NavLink>
                                <NavLink href="https://sergiconstance.com/" onClick={() => setIsMenuOpen(false)}>Sergi Constance</NavLink>
                            </nav>
                            <button onClick={() => setIsMenuOpen(false)} className="absolute top-8 right-8 text-white/50 hover:text-white transition-colors">
                                <X size={32} />
                            </button>
                        </motion.div>
                    )}
                </AnimatePresence>

                <main className="relative z-20 flex flex-col items-center min-h-screen pt-32 pb-12 px-4 text-center gap-8">
                    
                    <AnimatePresence>
                        {showPromo && (
                            <motion.div
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, height: 0, overflow: 'hidden' }}
                                className="relative w-full max-w-4xl mx-auto"
                            >
                                <div className="relative py-8">
                                     <button 
                                        onClick={() => setShowPromo(false)}
                                        className="absolute top-0 right-1/2 translate-x-1/2 -mt-2 p-2 text-white/30 hover:text-white transition-colors z-30"
                                        title="Cerrar promoción"
                                    >
                                        <X size={20} />
                                    </button>

                                    <motion.div
                                        initial={{ scale: 0.95 }}
                                        animate={{ scale: 1 }}
                                        transition={{ delay: 0.1 }}
                                        className="flex flex-col items-center"
                                    >
                                         <h1 
                                            className="font-black text-white uppercase text-6xl sm:text-8xl tracking-tighter leading-none mb-0 drop-shadow-2xl" 
                                            style={{ fontFamily: "'Poppins', sans-serif" }}
                                        >
                                            BLACK <span className="text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-600">FRIDAY</span>
                                        </h1>
                                        
                                        <p 
                                            className="text-primary font-bold text-2xl sm:text-3xl tracking-[0.5em] mt-2 mb-8 shadow-black drop-shadow-lg"
                                            style={{ fontFamily: "'Bebas Neue', sans-serif" }}
                                        >
                                            20% OFF NOW
                                        </p>

                                        <div className="flex justify-center">
                                            <Button 
                                                onClick={() => navigate('/preview-boost')}
                                                variant="outline"
                                                size="lg"
                                                className="text-lg h-12 px-8 border-white/30 hover:bg-white/10 text-white rounded-full backdrop-blur-sm"
                                            >
                                                VER DEMO
                                            </Button>
                                        </div>
                                    </motion.div>
                                </div>
                            </motion.div>
                        )}
                    </AnimatePresence>

                    {/* Minimalist Spotify Playlist Section */}
                    <motion.div
                        initial={{ opacity: 0, y: 40 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3, duration: 0.8 }}
                        className="w-full max-w-md mx-auto"
                    >
                         <div className="rounded-xl overflow-hidden shadow-2xl border border-white/5 bg-black/20 backdrop-blur-sm">
                            <iframe 
                                src="https://open.spotify.com/embed/playlist/37i9dQZF1DX76Wlfdnj7AP?utm_source=generator&theme=0" 
                                width="100%" 
                                height="152" 
                                frameBorder="0" 
                                allowFullScreen="" 
                                allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" 
                                loading="lazy"
                                title="Spotify Workout Playlist"
                                className="block"
                            ></iframe>
                        </div>
                        
                        {!showPromo && (
                            <motion.div 
                                initial={{ opacity: 0 }} 
                                animate={{ opacity: 1 }}
                                className="mt-8"
                            >
                                <button 
                                    onClick={() => setShowPromo(true)} 
                                    className="text-xs text-white/30 hover:text-white transition-colors uppercase tracking-widest"
                                >
                                    Ver Oferta Black Friday
                                </button>
                            </motion.div>
                        )}
                    </motion.div>

                </main>
            </div>
        </>
    );
};

export default LandingScreen;