import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Check, Lock, Bike, Expand as Stretch, Sparkles, Play, Pause, SkipForward, BrainCircuit, AlertTriangle, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { getWorkoutPreferences, createWorkout, getWorkoutTemplates, getExerciseById, getExercises, createExercise } from '@/lib/database';
import { toast } from '@/components/ui/use-toast';
import { CircularProgressbarWithChildren, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import { getUserPPLConfig, getTodaysPPLWorkout, initializePPLExercises } from '@/lib/ppl';
import PPLSetupModal from '@/components/workout/PPLSetupModal';

// Componente para la visualización del cerebro (Placeholder)
const NeuralMap = ({ readiness }) => {
    const getColor = (s) => {
        if(s < 40) return '#ef4444';
        if(s < 75) return '#f59e0b';
        return '#22c55e';
    }
    const color = getColor(readiness);

    return (
        <div className="w-full h-48 flex items-center justify-center rounded-lg relative overflow-hidden bg-black/30">
            <motion.div
                className="absolute inset-0"
                style={{
                    background: `radial-gradient(circle at 50% 50%, ${color}11 0%, transparent 70%)`
                }}
                animate={{ scale: [1, 1.1, 1], opacity: [0.5, 0.8, 0.5] }}
                transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
            />
            <BrainCircuit size={80} className="text-white/80 z-10" style={{ filter: `drop-shadow(0 0 10px ${color})` }}/>
            <p className="absolute bottom-4 text-white/80 font-bold z-10 text-lg">{readiness}%</p>
        </div>
    );
};

const BioAnalysisWidget = ({ userId, level, onAnalysisComplete, onAdaptSession }) => {
     const readiness = 85;
     const recommendation = "¡Estás listo para darlo todo hoy!";

    return (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-effect rounded-lg p-6 space-y-4">
            <h3 className="text-xl font-bold flex items-center gap-2"><BrainCircuit className="text-primary"/> Análisis de Preparación</h3>
            <NeuralMap readiness={readiness} />
             <div className={`p-3 rounded-lg flex items-start gap-3 mt-2 border-l-4 border-green-500 bg-green-500/10`}>
                 <Sparkles className="w-5 h-5 mt-1 flex-shrink-0 text-green-500" />
                <p className="text-sm">{recommendation}</p>
            </div>
             <div className="flex gap-2 mt-4">
                <Button onClick={onAnalysisComplete} className="w-full btn-primary">Continuar a Preparación</Button>
             </div>
        </motion.div>
    );
};

const TimerScreen = ({ exercise, duration, onFinish }) => {
    const [timeLeft, setTimeLeft] = useState(duration);
    const [isPaused, setIsPaused] = useState(false);

    useEffect(() => {
        if (isPaused) return;
        if (timeLeft <= 0) {
            onFinish();
            return;
        }
        const timer = setInterval(() => {
            setTimeLeft(prev => prev - 1);
        }, 1000);
        return () => clearInterval(timer);
    }, [timeLeft, isPaused, onFinish]);

    const formatTime = (seconds) => {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    };

    const progress = ((duration - timeLeft) / duration) * 100;

    return (
        <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed inset-0 bg-background/95 backdrop-blur-lg z-50 flex flex-col items-center justify-center p-8"
        >
            <h2 className="text-3xl font-bold text-center mb-4 text-primary">{exercise.title}</h2>
             <p className="text-lg text-muted-foreground mb-8">{exercise.exerciseName}</p>
            <div className="w-64 h-64 relative my-8">
                <CircularProgressbarWithChildren
                    value={progress}
                    strokeWidth={4}
                    styles={buildStyles({
                        pathColor: `hsl(var(--primary))`,
                        trailColor: 'hsl(var(--secondary))',
                        pathTransitionDuration: 0.5,
                    })}
                >
                    <div className="text-center">
                        <p className="text-6xl font-bold font-mono tracking-tighter">{formatTime(timeLeft)}</p>
                    </div>
                </CircularProgressbarWithChildren>
            </div>
            <div className="flex items-center gap-4">
                <Button variant="outline" size="lg" onClick={() => setIsPaused(!isPaused)}>
                    {isPaused ? <Play className="w-6 h-6 mr-2"/> : <Pause className="w-6 h-6 mr-2"/>}
                    {isPaused ? 'Reanudar' : 'Pausar'}
                </Button>
                <Button size="lg" onClick={onFinish} variant="ghost">
                    <SkipForward className="w-6 h-6 mr-2"/>
                    Saltar
                </Button>
            </div>
        </motion.div>
    );
};


const PrepStep = ({ step, onStart, isLocked, isCompleted }) => {
    return (
        <div className={`glass-effect p-6 rounded-lg relative overflow-hidden transition-all duration-300 ${isLocked ? 'opacity-40 saturate-0' : 'opacity-100'} ${isCompleted ? 'border-primary/50' : ''}`}>
            {isCompleted && (
                 <motion.div layoutId={`completed-check-${step.id}`} className="absolute top-4 right-4 bg-green-500/20 text-green-400 rounded-full p-2">
                    <Check className="w-5 h-5"/>
                </motion.div>
            )}
            <div className="flex flex-col h-full">
                <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center mb-3">{step.icon}</div>
                <h3 className="text-xl font-bold">{step.title}</h3>
                <p className="text-sm text-muted-foreground flex-1">{step.duration} min - {step.exerciseName}</p>
                <div className="mt-4">
                    {isLocked ? (
                        <Button disabled className="w-full"><Lock className="w-4 h-4 mr-2"/> Bloqueado</Button>
                    ) : (
                        <Button onClick={onStart} disabled={isCompleted} className="w-full btn-primary">
                            {isCompleted ? 'Completado' : 'Iniciar'}
                        </Button>
                    )}
                </div>
            </div>
        </div>
    );
};

const RoutineDesigner = ({ level, userId, onStartWorkout, pplData }) => {
    const [isLoading, setIsLoading] = useState(false);

    const handleStart = async () => {
        setIsLoading(true);
        try {
            await onStartWorkout();
        } catch (error) {
            console.error("Error starting workout:", error);
            toast({ variant: 'destructive', title: "Error", description: "No se pudo iniciar el entrenamiento." });
        } finally {
            setIsLoading(false);
        }
    };
    
    const isRestDay = pplData?.type === 'Rest';

    return (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6 text-center">
            <div className="w-20 h-20 bg-primary/10 text-primary mx-auto rounded-full flex items-center justify-center animate-pulse">
                <Sparkles className="w-10 h-10" />
            </div>
            <h2 className="text-2xl font-bold">¡Preparación Completada!</h2>
            
            {pplData ? (
                <div className="mb-6">
                    <p className="text-muted-foreground mb-2">Tu módulo PPL asignado para hoy es:</p>
                    <h3 className="text-3xl font-black uppercase text-white">{pplData.name}</h3>
                    <p className="text-sm text-primary mt-1">{pplData.description}</p>
                    {isRestDay && <p className="text-amber-400 font-bold mt-4">¡Hoy toca descanso activo!</p>}
                </div>
            ) : (
                 <p className="text-muted-foreground max-w-xl mx-auto">Has calentado como un profesional. Ahora es el momento de conquistar tu rutina.</p>
            )}

            <Button onClick={handleStart} size="lg" className="btn-primary" disabled={isLoading}>
                {isLoading ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Play className="w-5 h-5 mr-2" />}
                {isLoading ? 'Generando PPL...' : isRestDay ? 'Registrar Descanso' : 'Empezar Entrenamiento'}
            </Button>
        </motion.div>
    );
};


const SessionPrepScreen = () => {
    const { date, level } = useParams();
    const navigate = useNavigate();
    const { user } = useAuth();
    const [currentScreen, setCurrentScreen] = useState('analysis'); // 'analysis', 'prep', 'designer'
    const [activeTimer, setActiveTimer] = useState(null); 
    const [completedSteps, setCompletedSteps] = useState([]);
    const [showPPLSetup, setShowPPLSetup] = useState(false);
    const [pplWorkout, setPplWorkout] = useState(null);
    
    const preferences = useMemo(() => user ? getWorkoutPreferences(user.id) : {}, [user]);

    const prepSteps = [
        { id: 'cardio', title: 'Cardio', duration: 5, exerciseName: preferences.cardio?.name || 'Bici', icon: <Bike className="w-6 h-6 text-primary" /> },
        { id: 'mobility', title: 'Movilidad', duration: 3, exerciseName: preferences.mobility?.name || 'Círculos', icon: <Sparkles className="w-6 h-6 text-primary" /> },
        { id: 'stretching', title: 'Estiramientos', duration: 2, exerciseName: preferences.stretching?.name || 'Isquios', icon: <Stretch className="w-6 h-6 text-primary" /> },
    ];
    
    useEffect(() => {
        if (user) {
            const config = getUserPPLConfig(user.id);
            if (!config) {
                setShowPPLSetup(true);
            } else {
                initializePPLExercises(); 
                const todays = getTodaysPPLWorkout(user.id);
                setPplWorkout(todays);
            }
        }
    }, [user]);

    useEffect(() => {
        if (completedSteps.length === prepSteps.length) {
            setTimeout(() => {
                setCurrentScreen('designer');
            }, 500);
        }
    }, [completedSteps, prepSteps.length]);

    const handleTimerFinish = () => {
        toast({ title: `${prepSteps.find(s=>s.id === activeTimer).title} completado!`, description: '¡Un paso más cerca!' });
        setCompletedSteps(prev => [...prev, activeTimer]);
        setActiveTimer(null);
    };

     const handleAdaptSession = () => {
        toast({ title: "Sesión Adaptada", description: "Se ha reducido la intensidad sugerida.", variant: "default" });
        setCurrentScreen('prep');
    }

    const handleStartWorkout = async () => {
        if (!user) return;

        try {
            if (pplWorkout) {
                if (pplWorkout.type === 'Rest') {
                    toast({ title: "Día de Descanso Registrado", description: "¡Recupérate bien para mañana!" });
                    navigate('/home');
                    return;
                }

                // Ensure we have the latest list of exercises
                const dbExercises = getExercises();
                const finalSets = [];

                // Process each item carefully to prevent crashes
                for (const item of pplWorkout.items) {
                    // Try to find existing exercise by name match (case insensitive safety)
                    let dbEx = dbExercises.find(e => e.name.toLowerCase() === item.exercise_name.toLowerCase());
                    
                    // If not found, create it safely
                    if (!dbEx) {
                        dbEx = createExercise({
                            name: item.exercise_name,
                            muscleGroup: 'fullbody', // fallback
                            description: item.description || 'Ejercicio generado automáticamente',
                            prMetric: 'peso',
                            rest_time_sec: 90
                        });
                    }

                    // CRITICAL FIX: Check if dbEx exists before accessing its properties
                    if (dbEx && dbEx.id) {
                        // Create sets
                        for (let i = 0; i < item.series; i++) {
                            finalSets.push({
                                exercise_id: dbEx.id,
                                set_index: i + 1,
                                reps: 0, // Initialize
                                peso: 0  // Initialize
                            });
                        }
                    } else {
                        console.warn(`Skipping exercise creation for ${item.exercise_name} due to error.`);
                    }
                }

                const newWorkout = createWorkout(user.id, {
                    programId: 'prog_ppl',
                    programName: `PPL: ${pplWorkout.name}`,
                    sets: finalSets
                });

                if (newWorkout && newWorkout.id) {
                    navigate(`/workout/${newWorkout.id}`);
                } else {
                    throw new Error("Workout creation returned null");
                }
            } else {
                toast({ variant: 'destructive', title: 'Error PPL', description: 'No se pudo generar la rutina PPL.' });
            }
        } catch (error) {
            console.error("Failed to start workout:", error);
            toast({ 
                variant: 'destructive', 
                title: 'Error de inicio', 
                description: 'Hubo un problema al crear tu sesión. Inténtalo de nuevo.' 
            });
        }
    };
    
    const renderPrepContent = () => (
        <motion.div key="prep" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
             <div className="text-center">
                <h2 className="text-2xl font-bold">Fase de Preparación</h2>
                <p className="text-muted-foreground">Completa cada paso en orden para desbloquear tu entrenamiento.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {prepSteps.map((step, index) => {
                    const isCompleted = completedSteps.includes(step.id);
                    const isLocked = index > 0 && !completedSteps.includes(prepSteps[index - 1].id);
                    return (
                        <PrepStep 
                            key={step.id}
                            step={step}
                            isCompleted={isCompleted}
                            isLocked={isLocked}
                            onStart={() => setActiveTimer(step.id)}
                        />
                    );
                })}
            </div>
        </motion.div>
    );

    if (!user) return null;

    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
             <AnimatePresence>
                {showPPLSetup && (
                    <PPLSetupModal 
                        userId={user.id} 
                        onClose={() => setShowPPLSetup(false)} 
                        onComplete={() => {
                            initializePPLExercises();
                            setPplWorkout(getTodaysPPLWorkout(user.id));
                        }} 
                    />
                )}
            </AnimatePresence>

            <div className="flex items-center gap-4">
                <Button variant="ghost" size="icon" onClick={() => navigate('/boost')}>
                    <ArrowLeft />
                </Button>
                <div>
                    <h2 className="text-2xl font-bold">Sesión de Entrenamiento</h2>
                    <p className="text-muted-foreground">{new Date().toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })} - <span className="capitalize font-bold text-primary">{pplWorkout?.name || level}</span></p>
                </div>
            </div>

            <AnimatePresence mode="wait">
                {currentScreen === 'analysis' && (
                    <motion.div key="analysis" exit={{ opacity: 0, y: -20 }}>
                        <BioAnalysisWidget userId={user.id} level={level} onAnalysisComplete={() => setCurrentScreen('prep')} onAdaptSession={handleAdaptSession} />
                    </motion.div>
                )}
                {currentScreen === 'prep' && renderPrepContent()}
                {currentScreen === 'designer' && <RoutineDesigner level={level} userId={user.id} onStartWorkout={handleStartWorkout} pplData={pplWorkout} />}
            </AnimatePresence>

            <AnimatePresence>
                {activeTimer && (
                    <TimerScreen 
                        exercise={prepSteps.find(s => s.id === activeTimer)}
                        duration={prepSteps.find(s => s.id === activeTimer).duration * 60}
                        onFinish={handleTimerFinish}
                    />
                )}
            </AnimatePresence>
        </motion.div>
    );
};

export default SessionPrepScreen;