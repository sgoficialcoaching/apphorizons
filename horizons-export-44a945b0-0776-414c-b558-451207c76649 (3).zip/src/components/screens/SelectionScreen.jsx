import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Dumbbell, UtensilsCrossed, Zap, BookOpen, UserCheck } from 'lucide-react';
import ClusterCard from '@/components/common/ClusterCard';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/components/ui/use-toast';

const SelectionScreen = () => {
    const navigate = useNavigate();

    const clusters = [
        {
            title: 'Boost',
            icon: Zap,
            action: () => navigate('/boost'),
            imageUrl: 'https://sergiconstance-9fn0dyoiqm.live-website.com/wp-content/uploads/2025/11/ShottingAtlas-157-scaled.jpg',
            imageAlt: 'Hombre mostrando la app Boost en su móvil en el gimnasio',
        },
        {
            title: 'Entrenamiento',
            icon: Dumbbell,
            action: () => navigate('/training'),
            imageUrl: 'https://sergiconstance-9fn0dyoiqm.live-website.com/wp-content/uploads/2025/09/Foto-14-12-19-15-39-12-scaled.jpg',
            imageAlt: 'Hombre realizando un ejercicio de entrenamiento intenso',
        },
        {
            title: 'Nutrición',
            icon: UtensilsCrossed,
            action: () => navigate('/boost?tab=nutrition'),
            imageUrl: 'https://sergiconstance-9fn0dyoiqm.live-website.com/wp-content/uploads/2025/11/hq720.jpg',
            imageAlt: 'Plato de comida saludable y nutritiva',
        },
        {
            title: 'Ebooks',
            icon: BookOpen,
            action: () => toast({ title: "🚧 ¡Próximamente!", description: "La sección de Ebooks estará disponible pronto." }),
            imageUrl: 'https://sergiconstance-9fn0dyoiqm.live-website.com/wp-content/uploads/2025/11/ShottingAtlas-154-scaled.jpg',
            imageAlt: 'Mujer leyendo un ebook sobre fitness',
            backgroundPosition: 'center top 20%',
        },
        {
            title: 'Coaching',
            icon: UserCheck,
            action: () => toast({ title: "🚧 ¡Próximamente!", description: "El coaching personalizado estará disponible pronto." }),
            imageUrl: 'https://sergiconstance-9fn0dyoiqm.live-website.com/wp-content/uploads/2025/09/MV5BZDg0MTBjZWUtZmJkYi00MDQxLThkMDQtNGVmMTkwNGI5ZGQ2XkEyXkFqcGdeQXRyYW5zY29kZS13b3JrZmxvdw@@._V1_.jpg',
            imageAlt: 'Entrenador personal ayudando a un cliente',
            backgroundPosition: 'center top 20%',
        },
    ];

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.1,
            },
        },
    };

    return (
        <>
            <Helmet>
                <title>Elige tu camino - Boost App</title>
                <meta name="description" content="Selecciona cómo quieres empezar tu transformación: Entrenamiento, Nutrición, la App Boost, Ebooks o Coaching." />
            </Helmet>
            <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center p-6 md:p-10">
                <motion.div 
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="text-center mb-12"
                >
                    <h1 className="text-5xl md:text-7xl font-bebas tracking-wider text-white drop-shadow-lg">
                        ELIGE TU <span className="text-primary">CAMINO</span>
                    </h1>
                    <p className="text-muted-foreground mt-4 text-lg md:text-xl max-w-2xl mx-auto">
                        Personaliza tu experiencia y comienza tu transformación hoy mismo.
                    </p>
                </motion.div>

                <motion.div 
                    className="w-full max-w-7xl"
                    variants={containerVariants}
                    initial="hidden"
                    animate="visible"
                >
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-8">
                        {clusters.slice(0, 3).map((cluster, i) => (
                            <ClusterCard key={i} {...cluster} />
                        ))}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:max-w-4xl md:mx-auto">
                        {clusters.slice(3).map((cluster, i) => (
                             <ClusterCard key={i + 3} {...cluster} />
                        ))}
                    </div>
                </motion.div>
            </div>
        </>
    );
};

export default SelectionScreen;