import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Target, TrendingUp, Dumbbell, Calendar, ChevronRight, ChevronLeft, User, Heart, Coffee, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { calculateNutrition, upsertNutritionProfile, generateInitialPlan, updateNotificationSettings } from '@/lib/database';

const OnboardingWizard = ({ user, onComplete }) => {
  const [step, setStep] = useState(0);
  const [data, setData] = useState({
    objective: '',
    level: '',
    equipment: [],
    schedule: '3-5',
    bodyType: '',
    diet: '',
    activityLevel: 'moderate',
    wakeUpTime: '07:00',
    weight: '75',
    height: '180',
    age: '30',
    sex: 'male'
  });

  const steps = [
    {
      title: '¿Cuál es tu objetivo principal?',
      icon: Target,
      field: 'objective',
      options: [
        { value: 'cut', label: 'Perder Grasa', emoji: '🔥' },
        { value: 'maintain', label: 'Mantener', emoji: '⚖️' },
        { value: 'bulk', label: 'Ganar Músculo', emoji: '💪' }
      ],
    },
    {
      title: '¿Tu tipo de cuerpo?',
      description: 'Esto nos ayuda a ajustar tu plan inicial. Elige el que más se parezca a ti o "No estoy seguro".',
      icon: User,
      field: 'bodyType',
      options: [
        { value: 'ectomorph', label: 'Ectomorfo', description: 'Delgado, dificultad para ganar peso.', emoji: 'ố' },
        { value: 'mesomorph', label: 'Mesomorfo', description: 'Atlético, gana músculo con facilidad.', emoji: '🏋️' },
        { value: 'endomorph', label: 'Endomorfo', description: 'Robusto, tiende a almacenar grasa.', emoji: '🍔' },
        { value: 'unsure', label: 'No estoy seguro', description: '¡No hay problema! Te ayudaremos a descubrirlo.', emoji: '🤔' }
      ],
    },
    {
      title: '¿Tu experiencia entrenando?',
      icon: TrendingUp,
      field: 'level',
      options: [
        { value: 'beginner', label: 'Principiante', description: 'Menos de 1 año. Aprendiendo la técnica.', emoji: '🌱' },
        { value: 'intermediate', label: 'Intermedio', description: '1-3 años. Buscando mejorar y progresar.', emoji: '🚀' },
        { value: 'advanced', label: 'Avanzado', description: '+3 años. Buscando máxima intensidad.', emoji: '⚡' }
      ],
    },
    {
        title: '¿Tus preferencias de nutrición?',
        icon: Heart,
        field: 'diet',
        options: [
          { value: 'omnivore', label: 'Como de todo', description: 'Incluye carne, pescado, vegetales, etc.', emoji: '🍗🍎' },
          { value: 'vegetarian', label: 'Como pescado y/o huevos (sin carne)', description: 'Excluye carnes rojas y aves.', emoji: '🐟🥚' },
          { value: 'vegan', label: 'Como solo vegetales', description: 'Excluye cualquier producto animal.', emoji: '🥑🥕' }
        ],
      },
    {
      title: '¿Equipamiento disponible?',
      icon: Dumbbell,
      field: 'equipment',
      multiple: true,
      options: [
        { value: 'barbell', label: 'Barra', emoji: '🏋️' },
        { value: 'dumbbells', label: 'Mancuernas', emoji: '💪' },
        { value: 'machines', label: 'Máquinas', emoji: '🤖' },
        { value: 'bodyweight', label: 'Peso Corporal', emoji: '🧘' }
      ],
    },
    {
      title: '¿Cuántos días entrenas por semana?',
      icon: Calendar,
      field: 'schedule',
      options: [
        { value: '1-3', label: 'Ocasional', description: '1-3 días/semana', emoji: '🧘' },
        { value: '3-5', label: 'Consistente', description: '3-5 días/semana', emoji: '🏃' },
        { value: '5-7', label: 'Intensivo', description: '5-7 días/semana', emoji: '⚡' }
      ],
    },
    {
        title: '¿A qué hora te levantas?',
        description: 'Usaremos esto para tu notificación matutina "¡Despiértate!".',
        icon: Coffee,
        field: 'wakeUpTime',
        type: 'time'
    }
  ];

  const handleSelect = (field, value, multiple = false) => {
    setData(prevData => {
        if (multiple) {
            const current = prevData[field] || [];
            const updated = current.includes(value)
              ? current.filter(v => v !== value)
              : [...current, value];
            return { ...prevData, [field]: updated };
          } else {
            return { ...prevData, [field]: value };
          }
    });
  };
  
  const handleTimeChange = (e) => {
    setData({ ...data, wakeUpTime: e.target.value });
  };

  const handleNext = () => {
    const currentStep = steps[step];
    if (currentStep && currentStep.field) {
      const value = data[currentStep.field];
      if (!value || (Array.isArray(value) && value.length === 0)) {
        toast({
          title: 'Selecciona una opción',
          description: 'Debes elegir al menos una opción para continuar.',
          variant: 'destructive'
        });
        return;
      }
    }

    if (step < steps.length - 1) {
      setStep(step + 1);
    } else {
      completeOnboarding();
    }
  };

  const completeOnboarding = async () => {
    const profileData = {
        peso_kg: parseInt(data.weight, 10),
        altura_cm: parseInt(data.height, 10),
        edad: parseInt(data.age, 10),
        sexo: data.sex,
        factor_actividad: data.activityLevel,
        objetivo: data.objective,
        dieta: data.diet,
        nivel_entrenamiento: data.level,
        dias_entrenamiento_rango: data.schedule,
    };

    const nutrition = calculateNutrition(profileData);
    const finalProfile = { ...profileData, ...nutrition };
    await upsertNutritionProfile(user.id, finalProfile);
    
    generateInitialPlan(user.id, {
        objective: data.objective,
        level: data.level,
        scheduleRange: data.schedule,
        diet: data.diet,
    });
    
    await updateNotificationSettings(user.id, {
        morning_hour: parseInt(data.wakeUpTime.split(':')[0], 10),
    });

    toast({
      title: '🎉 ¡Bienvenido al equipo!',
      description: 'Hemos creado tu plan personalizado. ¡A por ello!'
    });

    onComplete(profileData);
  };

  const currentStep = steps[step];

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-2xl"
      >
        <div className="glass-effect rounded-3xl p-6 sm:p-8 shadow-2xl shadow-primary/5">
          <div className="mb-8">
            <div className="flex flex-col sm:flex-row items-center justify-between mb-4 gap-4">
              <div className="flex items-center gap-3">
                {currentStep && <currentStep.icon className="w-8 h-8 text-primary" />}
                <div>
                    <h2 className="text-xl sm:text-2xl font-bold">{currentStep?.title}</h2>
                    {currentStep.description && <p className="text-sm text-muted-foreground">{currentStep.description}</p>}
                </div>
              </div>
              <span className="text-muted-foreground font-medium text-sm">
                Paso {step + 1} / {steps.length}
              </span>
            </div>
            
            <div className="h-2 bg-secondary rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-primary to-amber-400"
                initial={{ width: 0 }}
                animate={{ width: `${((step + 1) / steps.length) * 100}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="min-h-[200px] mb-8"
            >
              {currentStep.type === 'time' ? (
                <div className="flex justify-center items-center h-full">
                    <div className="flex items-center gap-4 bg-secondary/50 rounded-xl p-4 border-2 border-border">
                        <Clock className="w-8 h-8 text-muted-foreground" />
                        <input 
                            type="time" 
                            value={data.wakeUpTime} 
                            onChange={handleTimeChange}
                            className="bg-transparent text-4xl font-bold focus:outline-none"
                        />
                    </div>
                </div>
              ) : (
                <div className={`grid grid-cols-1 ${currentStep.options.length > 2 ? 'md:grid-cols-2' : 'md:grid-cols-1'} gap-3`}>
                    {currentStep?.options.map((option) => {
                        const isSelected = currentStep.multiple
                        ? (data[currentStep.field] || []).includes(option.value)
                        : data[currentStep.field] === option.value;

                        return (
                        <motion.button
                            key={option.value}
                            onClick={() => handleSelect(currentStep.field, option.value, currentStep.multiple)}
                            whileHover={{ scale: 1.03 }}
                            whileTap={{ scale: 0.97 }}
                            className={`w-full p-4 rounded-xl border-2 transition-all text-left ${
                            isSelected
                                ? 'border-primary bg-primary/10'
                                : 'border-border bg-secondary/50 hover:border-border/50'
                            }`}
                        >
                            <div className="flex items-start gap-4">
                            <span className="text-2xl mt-1">{option.emoji}</span>
                            <div>
                                <span className="text-lg font-medium">{option.label}</span>
                                {option.description && <p className="text-sm text-muted-foreground text-left">{option.description}</p>}
                            </div>
                            </div>
                        </motion.button>
                        );
                    })}
                </div>
              )}
            </motion.div>
          </AnimatePresence>

          <div className="flex gap-3">
            {step > 0 && (
              <Button
                onClick={() => setStep(step - 1)}
                variant="outline"
                className="flex-1 btn-secondary"
              >
                <ChevronLeft className="w-4 h-4 mr-2" />
                Atrás
              </Button>
            )}
            <Button
              onClick={handleNext}
              className="flex-1 btn-primary"
            >
              {step === steps.length - 1 ? 'Completar' : 'Siguiente'}
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
        <p className="text-center text-xs text-muted-foreground mt-4">
            ¡Empecemos a construir tu mejor versión!
        </p>
      </motion.div>
    </div>
  );
};

export default OnboardingWizard;