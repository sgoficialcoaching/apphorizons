import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Crown, Zap, Star, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { toast } from '@/components/ui/use-toast';

const PlanSelectionScreen = ({ onComplete }) => {
    const { user } = useAuth();
    const [selectedPlan, setSelectedPlan] = useState('plata');

    const plans = [
        { id: 'clasico', name: 'Clásico', price: 'Gratis', features: ['Acceso a entrenos básicos', 'Diario de nutrición', 'Comunidad'], icon: Star, color: 'text-gray-400' },
        { id: 'plata', name: 'Plata', price: '€9.99/mes', features: ['Todo en Clásico', 'Programas de entreno completos', 'Recetas avanzadas'], icon: Zap, color: 'text-gray-300' },
        { id: 'oro', name: 'Oro', price: '€19.99/mes', features: ['Todo en Plata', 'Analíticas detalladas', 'Contenido exclusivo de Sergi'], icon: Crown, color: 'text-amber-400' },
        { id: 'vip', name: 'VIP', price: 'Personalizado', features: ['Acceso total', 'Contacto directo con Sergi', 'Entrenamiento 1 a 1'], icon: Crown, color: 'text-purple-400' },
    ];

    const handleSelectPlan = (planId) => {
        setSelectedPlan(planId);
    };

    const handleContinue = () => {
        if (!user) return;

        if (selectedPlan === 'vip') {
            const whatsappUrl = `https://wa.me/34613840656?text=Hola,%20estoy%20interesado%20en%20el%20plan%20VIP%20de%20la%20app%20de%20Sergi%20Constance.%20Mi%20email%20es%20${user.email}`;
            window.open(whatsappUrl, '_blank');
            toast({
                title: 'Redirigiendo a WhatsApp',
                description: 'Contacta con nosotros para finalizar tu suscripción VIP.',
            });
        } else {
             // Here you would typically redirect to a payment provider like Stripe
             toast({
                title: `Plan ${selectedPlan} seleccionado`,
                description: 'La integración de pagos se añadirá pronto. Por ahora, continuarás con el plan básico.',
            });
        }
        
        localStorage.setItem(`plan_selected_${user.id}`, selectedPlan);
        onComplete();
    };

    return (
        <div className="min-h-screen flex items-center justify-center p-4 bg-background">
            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-full max-w-4xl"
            >
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold gradient-text">Elige tu Plan</h1>
                    <p className="text-muted-foreground mt-2">Selecciona el plan que mejor se adapte a tus objetivos.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {plans.map(plan => (
                        <motion.div
                            key={plan.id}
                            onClick={() => handleSelectPlan(plan.id)}
                            className={`glass-effect rounded-2xl p-6 cursor-pointer border-2 transition-all ${selectedPlan === plan.id ? 'border-primary' : 'border-transparent'}`}
                            whileHover={{ y: -5 }}
                        >
                            <plan.icon className={`w-10 h-10 mb-4 ${plan.color}`} />
                            <h2 className="text-2xl font-bold">{plan.name}</h2>
                            <p className={`text-xl font-semibold my-2 ${plan.color}`}>{plan.price}</p>
                            <ul className="space-y-2 text-sm text-muted-foreground mt-4">
                                {plan.features.map((feature, i) => (
                                    <li key={i} className="flex items-start gap-2">
                                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                                        <span>{feature}</span>
                                    </li>
                                ))}
                            </ul>
                        </motion.div>
                    ))}
                </div>

                <div className="mt-8 text-center">
                    <Button onClick={handleContinue} className="btn-primary px-12 py-6 text-lg">
                        Continuar
                    </Button>
                </div>
            </motion.div>
        </div>
    );
};

export default PlanSelectionScreen;