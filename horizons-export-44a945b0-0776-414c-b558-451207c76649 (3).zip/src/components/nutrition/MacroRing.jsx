import React from 'react';
import { CircularProgressbar, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

const MacroRing = ({ totals, profile }) => {
    if (!profile) return null;

    const { kcal_objetivo } = profile;
    const { kcal } = totals;

    const percentage = kcal_objetivo > 0 ? (kcal / kcal_objetivo) * 100 : 0;

    const pathColor = percentage > 110 ? '#ef4444' : percentage > 90 ? '#22c55e' : 'hsl(var(--primary))';
    const trailColor = 'rgba(255,255,255,0.1)';
    
    return (
        <div className="w-full h-full relative flex items-center justify-center">
            <CircularProgressbar
                value={percentage}
                strokeWidth={8}
                styles={buildStyles({
                    pathColor: pathColor,
                    trailColor: trailColor,
                    strokeLinecap: 'round',
                    pathTransitionDuration: 0.8
                })}
            />
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center z-10">
                <span className="text-3xl sm:text-4xl font-black tracking-tighter text-white drop-shadow-lg">{Math.round(kcal)}</span>
                <span className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-muted-foreground">de {kcal_objetivo} Kcal</span>
            </div>
        </div>
    );
};

export default MacroRing;