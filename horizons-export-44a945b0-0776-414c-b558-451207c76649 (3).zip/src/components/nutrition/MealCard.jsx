import React, { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    PlusCircle, Trash2, CheckCircle2, Circle, MoreHorizontal, 
    Utensils, ChefHat, Info, ChevronDown, ChevronUp, RefreshCw 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { addXpAndBoosties } from '@/lib/gamification';
import { getEquivalentFoods } from '@/lib/nutritionLogic';

const MealCard = ({ meal, items = [], onAddFood, onDeleteFood, userId, onCompleteToggle, onUpdateItem }) => {
    const [isCompleting, setIsCompleting] = useState(false);
    const [swappingItemId, setSwappingItemId] = useState(null);
    const [equivalents, setEquivalents] = useState([]);
    
    // Calculate totals: Base Meal + All Ingredients
    const totals = useMemo(() => {
        // Base stats from the meal itself (e.g., from a recipe)
        const baseKcal = Number(meal.kcal) || 0;
        const baseP = Number(meal.protein) || 0;
        const baseC = Number(meal.carbs) || 0;
        const baseF = Number(meal.fat) || 0;

        return items.reduce((acc, item) => {
            acc.kcal += item.total_kcal || 0;
            acc.p += item.total_p || 0;
            acc.c += item.total_c || 0;
            acc.f += item.total_f || 0;
            return acc;
        }, { kcal: baseKcal, p: baseP, c: baseC, f: baseF });
    }, [items, meal]);

    const handleComplete = async () => {
        // Toggle logic: if true, make false. If false, make true.
        const newStatus = !meal.is_completed;
        
        setIsCompleting(true);
        try {
            if (onCompleteToggle) {
                // Pass the NEW desired status
                await onCompleteToggle(meal.id, meal.is_completed);
            }
            
            // Only award XP if we are marking AS complete (not unmarking)
            if (newStatus) {
                const reward = await addXpAndBoosties(userId, 'MEAL_LOGGED');
                if (reward) {
                    toast({
                        title: "¡Comida Registrada! 🍽️",
                        description: `+${reward.earnedBoosties} Boosties | +${reward.earnedXp} XP`,
                        className: "bg-green-600 text-white border-none"
                    });
                    window.dispatchEvent(new Event('boosties_updated'));
                }
            } else {
                 toast({
                    title: "Comida Desmarcada",
                    description: "Se ha actualizado tu diario.",
                });
            }
        } catch (e) {
            console.error(e);
            toast({ variant: "destructive", title: "Error", description: "No se pudo actualizar el estado." });
        } finally {
            setIsCompleting(false);
        }
    };

    const handleSwapClick = (item) => {
        if(swappingItemId === item.id) {
            setSwappingItemId(null);
            setEquivalents([]);
            return;
        }

        const foundEquivalents = getEquivalentFoods(item, item.gramos);
        if(foundEquivalents.length === 0) {
            toast({ title: 'Sin equivalentes', description: 'No se encontraron alternativas directas.' });
            return;
        }
        
        setSwappingItemId(item.id);
        setEquivalents(foundEquivalents);
    };

    const handleConfirmSwap = (originalItemId, newItem) => {
        if(onUpdateItem) {
            // We delete the old one and add the new one (simple swap simulation)
            onDeleteFood(originalItemId);
            onAddFood(meal.id, newItem.id, newItem.equivalent_grams);
            
            toast({
                title: 'Alimento Intercambiado',
                description: `Cambiado por ${newItem.equivalent_grams}g de ${newItem.name}`
            });
            
            setSwappingItemId(null);
            setEquivalents([]);
        } else if (onDeleteFood && onAddFood) {
             // Fallback if direct update prop isn't passed but individual ones are
             onDeleteFood(originalItemId);
             onAddFood(meal.id, newItem.id, newItem.equivalent_grams);
             setSwappingItemId(null);
             setEquivalents([]);
        }
    };

    return (
        <motion.div 
            initial={{opacity: 0, y: 20}} 
            animate={{opacity: 1, y: 0}} 
            className={`rounded-3xl overflow-hidden border transition-all duration-300 ${meal.is_completed ? 'bg-green-900/10 border-green-500/30' : 'glass-effect border-white/5'}`}
        >
            <div className="p-5 flex flex-col gap-4 border-b border-white/5 bg-white/[0.02]">
                <div className="flex justify-between items-start">
                    <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                             <span className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground">{meal.nombre || meal.name}</span>
                             {meal.isRecipe ? (
                                <span className="bg-purple-500/10 text-purple-400 text-[10px] px-1.5 py-0.5 rounded border border-purple-500/20 flex items-center gap-1">
                                    <ChefHat className="w-3 h-3"/> Plato Completo
                                </span>
                             ) : (
                                <span className="bg-blue-500/10 text-blue-400 text-[10px] px-1.5 py-0.5 rounded border border-blue-500/20 flex items-center gap-1">
                                    <Utensils className="w-3 h-3"/> Ingredientes
                                </span>
                             )}
                        </div>
                        
                        <h3 className="font-black text-xl flex items-center gap-2 leading-tight mb-2">
                            {meal.dishName || "Selección Libre"}
                            {meal.is_completed && <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />}
                        </h3>

                        {meal.instructions && (
                             <div className="text-xs text-gray-400 leading-relaxed bg-black/20 p-2.5 rounded-lg border border-white/5 flex gap-2">
                                <Info className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                                <div>
                                    <span className="font-bold text-gray-300 block mb-0.5">Instrucciones:</span>
                                    {meal.instructions}
                                </div>
                             </div>
                        )}
                    </div>
                    
                    <div className="flex flex-col items-end gap-2 ml-4">
                        <Button 
                            variant="ghost" 
                            size="icon" 
                            className={`rounded-full ${meal.is_completed ? 'text-green-500 bg-green-500/10' : 'text-muted-foreground hover:text-white hover:bg-white/10'}`}
                            onClick={handleComplete}
                            disabled={isCompleting}
                        >
                            {isCompleting ? <span className="animate-spin text-xs">...</span> : (meal.is_completed ? <CheckCircle2 className="w-6 h-6" /> : <Circle className="w-6 h-6" />)}
                        </Button>
                    </div>
                </div>

                {/* Macro Summary Badge */}
                <div className="flex gap-4 text-xs font-bold pt-2 border-t border-white/5">
                    <span className="text-[var(--neon-yellow)] bg-[var(--neon-yellow)]/10 px-2 py-0.5 rounded">{Math.round(totals.kcal)} kcal</span>
                    <span className="text-blue-400">P: {Math.round(totals.p)}g</span>
                    <span className="text-orange-400">C: {Math.round(totals.c)}g</span>
                    <span className="text-yellow-400">G: {Math.round(totals.f)}g</span>
                </div>
            </div>

            <div className="divide-y divide-white/5">
                {/* Base Meal Entry (if applicable) */}
                {meal.kcal > 0 && (
                    <div className="flex justify-between items-center p-4 hover:bg-white/[0.02] bg-purple-500/5">
                        <div className="flex items-center gap-4 flex-1">
                            <div className="w-10 h-10 rounded-lg flex items-center justify-center text-lg bg-purple-500/20 text-purple-400">
                                <ChefHat className="w-4 h-4" />
                            </div>
                            <div>
                                <p className="font-bold text-sm text-white mb-0.5">Base del Plato: {meal.dishName || meal.nombre}</p>
                                <div className="flex items-center gap-3 text-[11px] font-medium text-muted-foreground">
                                    <span className="text-white bg-purple-500/10 px-1.5 rounded">Ración</span>
                                    <span className="w-1 h-1 rounded-full bg-white/20"></span>
                                    <span className="text-[var(--neon-yellow)]">{meal.kcal} kcal</span>
                                    <span className="w-1 h-1 rounded-full bg-white/20"></span>
                                    <span className="text-blue-300">P: {meal.protein}g</span>
                                    <span className="text-orange-300">C: {meal.carbs}g</span>
                                    <span className="text-yellow-300">G: {meal.fat}g</span>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                <div className="px-5 py-3 text-[10px] uppercase font-bold text-muted-foreground bg-black/10">Ingredientes</div>
                {items.length > 0 ? items.map((item, index) => {
                    const key = `${meal.id}-item-${index}-${item.id}`;
                    const isSwapping = swappingItemId === item.id;

                    return (
                        <div key={key}>
                            <div className={`flex justify-between items-center p-4 hover:bg-white/[0.02] transition-colors group relative ${isSwapping ? 'bg-white/5' : ''}`}>
                                <div className="flex items-center gap-4 flex-1">
                                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-lg bg-white/5`}>
                                       {/* Simple category icon based on item info if available, else generic */}
                                       <Utensils className="w-4 h-4 text-muted-foreground" />
                                    </div>
                                    <div>
                                        <p className="font-bold text-sm text-white mb-0.5">{item.name}</p>
                                        <div className="flex items-center gap-3 text-[11px] font-medium text-muted-foreground">
                                            <span className="text-white bg-white/10 px-1.5 rounded">{Math.round(item.gramos)}g</span>
                                            <span className="w-1 h-1 rounded-full bg-white/20"></span>
                                            <span className="text-[var(--neon-yellow)]">{Math.round(item.total_kcal)} kcal</span>
                                            <span className="w-1 h-1 rounded-full bg-white/20"></span>
                                            <span className="text-blue-300">P: {Math.round(item.total_p)}g</span>
                                            <span className="text-orange-300">C: {Math.round(item.total_c)}g</span>
                                            <span className="text-yellow-300">G: {Math.round(item.total_f)}g</span>
                                        </div>
                                    </div>
                                </div>
                                
                                {!meal.is_completed && (
                                    <div className="flex items-center gap-1 opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity">
                                        <Button 
                                            variant="ghost" 
                                            size="icon" 
                                            className={`h-8 w-8 transition-colors ${isSwapping ? 'text-[var(--neon-yellow)] bg-[var(--neon-yellow)]/20' : 'text-muted-foreground hover:text-blue-400 hover:bg-blue-400/10'}`}
                                            onClick={() => handleSwapClick(item)}
                                            title="Buscar equivalentes"
                                        >
                                            <RefreshCw className={`w-4 h-4 ${isSwapping ? 'animate-spin' : ''}`}/> 
                                        </Button>
                                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-red-500 hover:bg-red-500/10" onClick={() => onDeleteFood(item.id)}>
                                            <Trash2 className="w-4 h-4"/>
                                        </Button>
                                    </div>
                                )}
                            </div>
                            
                            {/* Equivalents Panel */}
                            <AnimatePresence>
                                {isSwapping && (
                                    <motion.div 
                                        initial={{ height: 0, opacity: 0 }}
                                        animate={{ height: 'auto', opacity: 1 }}
                                        exit={{ height: 0, opacity: 0 }}
                                        className="overflow-hidden bg-black/40 border-b border-white/5"
                                    >
                                        <div className="p-3 text-[10px] uppercase font-bold text-gray-400 flex items-center gap-2">
                                            <RefreshCw className="w-3 h-3" />
                                            Alternativas Saludables (Mismas Calorías)
                                        </div>
                                        {equivalents.length > 0 ? (
                                            <div className="grid gap-2 p-3 pt-0">
                                                {equivalents.map(eq => (
                                                    <button 
                                                        key={eq.id}
                                                        onClick={() => handleConfirmSwap(item.id, eq)}
                                                        className="flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-[var(--neon-yellow)]/50 transition-all text-left group/eq"
                                                    >
                                                        <div>
                                                            <div className="font-bold text-sm text-white flex items-center gap-2">
                                                                {eq.name}
                                                                <span className="text-[10px] bg-[var(--neon-yellow)]/20 text-[var(--neon-yellow)] px-1.5 rounded">{eq.equivalent_grams}g</span>
                                                            </div>
                                                            <div className="text-[10px] text-gray-500 mt-0.5">
                                                                Aporta: P:{eq.p_100g} C:{eq.c_100g} G:{eq.g_100g}
                                                            </div>
                                                        </div>
                                                        <div className="text-[10px] font-bold text-gray-400 group-hover/eq:text-white">
                                                            Intercambiar
                                                        </div>
                                                    </button>
                                                ))}
                                            </div>
                                        ) : (
                                            <div className="p-4 text-center text-xs text-gray-500 italic">No se encontraron equivalentes directos.</div>
                                        )}
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>
                    );
                }) : (
                    <div className="text-center py-8">
                         <p className="text-sm text-muted-foreground mb-3 italic">No hay ingredientes adicionales</p>
                         <Button variant="outline" size="sm" onClick={() => onAddFood(meal.id)} className="border-dashed border-white/20 hover:border-[var(--neon-yellow)] hover:text-[var(--neon-yellow)]">
                            <PlusCircle className="mr-2 h-4 w-4" /> Añadir Alimentos
                        </Button>
                    </div>
                )}
            </div>

            {!meal.is_completed && items.length > 0 && (
                <div className="p-3 bg-black/20 border-t border-white/5">
                    <Button variant="ghost" className="w-full text-xs font-bold text-muted-foreground hover:text-[var(--neon-yellow)] hover:bg-transparent h-8 uppercase tracking-wider" onClick={() => onAddFood(meal.id)}>
                        <PlusCircle className="mr-2 h-3 w-3" /> Añadir otro alimento
                    </Button>
                </div>
            )}
        </motion.div>
    );
};

export default React.memo(MealCard);