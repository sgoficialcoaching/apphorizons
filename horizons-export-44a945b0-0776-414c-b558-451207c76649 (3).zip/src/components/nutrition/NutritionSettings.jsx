import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, Droplets } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { upsertNutritionProfile, calculateNutrition } from '@/lib/database';

const NutritionSettings = ({ user, profile, onBack }) => {
    const [formData, setFormData] = useState({
        peso_kg: profile?.peso_kg || 80,
        altura_cm: profile?.altura_cm || 180,
        edad: profile?.edad || 30,
        sexo: profile?.sexo || 'male',
        factor_actividad: profile?.factor_actividad || 'moderate',
        objetivo: profile?.objetivo || 'mantenimiento',
        dieta: profile?.dieta || 'flexible',
    });
    const [isSaving, setIsSaving] = useState(false);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleCalculateMacros = async () => {
        setIsSaving(true);
        try {
            const calculatedMacros = calculateNutrition(formData);
            const newProfile = { ...profile, ...formData, ...calculatedMacros };
            upsertNutritionProfile(user.id, newProfile);
            toast({ title: "Macros Actualizadas", description: "Tu perfil nutricional se ha actualizado con éxito." });
            onBack();
        } catch (error) {
            toast({ variant: "destructive", title: "Error", description: "No se pudieron calcular los macros." });
        } finally {
            setIsSaving(false);
        }
    };
    
    const handleHydrationGoal = async () => {
        setIsSaving(true);
        try {
            const agua_ml_objetivo = formData.peso_kg * 35;
            upsertNutritionProfile(user.id, { ...profile, ...formData, agua_ml_objetivo });
            toast({ title: "Objetivo de Hidratación Actualizado", description: `Tu nuevo objetivo es de ${agua_ml_objetivo} ml.` });
        } catch(error) {
            toast({ variant: "destructive", title: "Error", description: "No se pudo actualizar el objetivo." });
        } finally {
            setIsSaving(false);
        }
    }

    const formFields = [
        { name: 'peso_kg', label: 'Peso (kg)', type: 'number' },
        { name: 'altura_cm', label: 'Altura (cm)', type: 'number' },
        { name: 'edad', label: 'Edad', type: 'number' },
        { name: 'sexo', label: 'Sexo', type: 'select', options: [{value: 'male', label: 'Masculino'}, {value: 'female', label: 'Femenino'}] },
        { name: 'factor_actividad', label: 'Factor de Actividad', type: 'select', options: [
            { value: 'sedentary', label: 'Sedentario' },
            { value: 'light', label: 'Ligero (1-3 días/sem)' },
            { value: 'moderate', label: 'Moderado (3-5 días/sem)' },
            { value: 'active', label: 'Activo (6-7 días/sem)' },
            { value: 'veryActive', label: 'Muy Activo (2x día)' },
        ]},
        { name: 'objetivo', label: 'Objetivo', type: 'select', options: [
            { value: 'déficit', label: 'Déficit Calórico' },
            { value: 'mantenimiento', label: 'Mantenimiento' },
            { value: 'superávit', label: 'Superávit (Masa)' },
        ]},
        { name: 'dieta', label: 'Estilo de Dieta', type: 'select', options: [
            { value: 'flexible', label: 'Flexible' },
            { value: 'mediterránea', label: 'Mediterránea' },
            { value: 'keto', label: 'Cetogénica (Keto)' },
            { value: 'veg', label: 'Vegana' },
        ]},
    ];

    return (
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
            <div className="flex items-center gap-4">
                <Button variant="ghost" size="icon" onClick={onBack}><ChevronLeft/></Button>
                <h2 className="text-2xl font-bold">Perfil Nutricional</h2>
            </div>

            <div className="glass-effect rounded-2xl p-6 space-y-4">
                {formFields.map(field => (
                    <div key={field.name}>
                        <label className="text-sm font-medium text-muted-foreground mb-2 block">{field.label}</label>
                        {field.type === 'select' ? (
                            <select name={field.name} value={formData[field.name]} onChange={handleChange} className="w-full px-4 py-3 bg-input border-border rounded-xl">
                                {field.options.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                            </select>
                        ) : (
                             <input type={field.type} name={field.name} value={formData[field.name]} onChange={handleChange} className="w-full px-4 py-3 bg-input border-border rounded-xl"/>
                        )}
                    </div>
                ))}
            </div>

            <div className="space-y-3">
                 <Button id="btn-calc-macros" onClick={handleCalculateMacros} disabled={isSaving} className="w-full btn-primary">
                    {isSaving ? "Guardando..." : "Calcular y Guardar Macros"}
                 </Button>
                 <Button id="btn-hydration-goal" onClick={handleHydrationGoal} disabled={isSaving} className="w-full btn-secondary">
                    <Droplets className="w-4 h-4 mr-2" />
                    {isSaving ? "Guardando..." : "Calcular Objetivo de Hidratación"}
                 </Button>
            </div>
        </motion.div>
    );
};

export default NutritionSettings;