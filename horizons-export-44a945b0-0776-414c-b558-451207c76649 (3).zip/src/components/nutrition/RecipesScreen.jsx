import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, Lock, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { SEED_RECIPES } from '@/lib/database';

const RecipesScreen = ({ user, subscriptionStatus, onBack }) => {
    const [recipes, setRecipes] = useState(SEED_RECIPES);
    
    const handleRecipeClick = (recipe) => {
        if(recipe.premium && !subscriptionStatus?.isPremium) {
            toast({
                title: '🔒 Contenido Premium',
                description: 'Mejora tu plan para ver esta receta.',
                variant: 'destructive',
            });
            return;
        }
        toast({ title: '🚧 Próximamente', description: 'La vista detallada de recetas llegará pronto.' });
    };
    
    const handleNewRecipe = () => {
        toast({ title: '🚧 Próximamente', description: 'El constructor de recetas estará disponible pronto.' });
    };

    return (
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                    <Button variant="ghost" size="icon" onClick={onBack}><ChevronLeft/></Button>
                    <h2 className="text-2xl font-bold">Recetas</h2>
                </div>
                 <Button id="btn-new-recipe" onClick={handleNewRecipe}>
                    <Plus className="w-4 h-4 mr-2"/>
                    Nueva Receta
                 </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {recipes.map((recipe, index) => {
                    const isLocked = recipe.premium && !subscriptionStatus?.isPremium;
                    return (
                        <motion.div
                            key={recipe.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                            onClick={() => handleRecipeClick(recipe)}
                            className={`glass-effect rounded-2xl overflow-hidden card-hover cursor-pointer ${isLocked ? 'content-locked' : ''}`}
                        >
                            <div className="relative h-40 bg-secondary">
                                <img className="w-full h-full object-cover" alt={recipe.name} src="https://images.unsplash.com/photo-1557349964-34f68e722d29" />
                                {isLocked && (
                                    <div className="absolute inset-0 flex items-center justify-center bg-black/70 backdrop-blur-sm z-10">
                                         <Lock className="w-12 h-12 text-primary" />
                                    </div>
                                )}
                            </div>
                            <div className="p-4">
                                <h3 className="font-semibold">{recipe.name}</h3>
                                <p className="text-sm text-muted-foreground">{recipe.kcalPerServing} kcal por ración</p>
                            </div>
                        </motion.div>
                    );
                })}
            </div>
        </motion.div>
    );
};

export default RecipesScreen;