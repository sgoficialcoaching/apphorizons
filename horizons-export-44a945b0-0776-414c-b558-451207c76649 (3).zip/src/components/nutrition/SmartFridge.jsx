import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Beef, Wheat, Droplet, Carrot, Apple, CheckCircle2 } from 'lucide-react';
import { getPantryItems } from '@/lib/nutritionLogic';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const CATEGORIES = [
  { id: 'protein', label: 'Proteína', icon: Beef, color: 'text-blue-400', bg: 'bg-blue-400/10' },
  { id: 'carbs', label: 'Carbos', icon: Wheat, color: 'text-orange-400', bg: 'bg-orange-400/10' },
  { id: 'fat', label: 'Grasas', icon: Droplet, color: 'text-yellow-400', bg: 'bg-yellow-400/10' },
  { id: 'vegetable', label: 'Verduras', icon: Carrot, color: 'text-green-400', bg: 'bg-green-400/10' },
  { id: 'fruit', label: 'Frutas', icon: Apple, color: 'text-red-400', bg: 'bg-red-400/10' },
];

const SmartFridge = ({ onSelectFood, onClose }) => {
  const [activeCategory, setActiveCategory] = useState('protein');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFoodId, setSelectedFoodId] = useState(null);
  const allFoods = getPantryItems();

  const filteredFoods = allFoods.filter(f => 
    f.category === activeCategory && 
    f.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSelect = (food) => {
      setSelectedFoodId(food.id);
      // Slight delay for visual feedback
      setTimeout(() => {
          onSelectFood(food);
      }, 200);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="w-full max-w-md bg-[#0F1115] border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh] relative"
      >
        <div className="p-5 border-b border-white/5 bg-gradient-to-b from-white/5 to-transparent">
          <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-black flex items-center gap-2 italic">
                ❄️ NEVERA <span className="text-[var(--neon-yellow)] not-italic">INTELIGENTE</span>
              </h2>
              <Button variant="ghost" size="sm" onClick={onClose} className="h-8 w-8 p-0 rounded-full hover:bg-white/10">✕</Button>
          </div>
          
          <div className="relative mb-4">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
             <input 
               type="text" 
               placeholder="Buscar alimento..."
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               className="w-full bg-black/20 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-[var(--neon-yellow)] text-white placeholder:text-gray-500"
             />
          </div>

          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide -mx-1 px-1">
            {CATEGORIES.map(cat => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap border ${
                  activeCategory === cat.id 
                    ? `border-${cat.color.split('-')[1]} ${cat.bg} ${cat.color} ring-1 ring-white/20` 
                    : 'border-transparent bg-white/5 text-muted-foreground hover:bg-white/10'
                }`}
              >
                <cat.icon className="w-3.5 h-3.5" />
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-2 bg-black/20">
          {filteredFoods.map(food => (
             <motion.button
               key={food.id}
               onClick={() => handleSelect(food)}
               whileHover={{ scale: 1.01, backgroundColor: 'rgba(255,255,255,0.08)' }}
               whileTap={{ scale: 0.98 }}
               className={`w-full flex items-center justify-between p-3 rounded-2xl border transition-all group ${
                 selectedFoodId === food.id 
                 ? 'bg-[var(--neon-yellow)]/10 border-[var(--neon-yellow)]' 
                 : 'bg-[#1A1C20] border-transparent hover:border-white/10'
               }`}
             >
               <div className="flex items-center gap-4">
                 <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl shadow-inner ${CATEGORIES.find(c => c.id === food.category)?.bg}`}>
                    {food.category === 'protein' && '🥩'}
                    {food.category === 'carbs' && '🍚'}
                    {food.category === 'fat' && '🥑'}
                    {food.category === 'vegetable' && '🥦'}
                    {food.category === 'fruit' && '🍎'}
                 </div>
                 <div className="text-left">
                   <p className={`font-bold text-sm transition-colors ${selectedFoodId === food.id ? 'text-[var(--neon-yellow)]' : 'text-white'}`}>
                       {food.name}
                   </p>
                   <p className="text-[10px] text-muted-foreground font-medium mt-0.5">
                      <span className="text-white">{food.k} kcal</span> • P:{food.p} C:{food.c} G:{food.f}
                   </p>
                 </div>
               </div>
               
               {selectedFoodId === food.id ? (
                   <CheckCircle2 className="w-5 h-5 text-[var(--neon-yellow)]" />
               ) : (
                   <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-xs font-bold text-white">
                       +
                   </div>
               )}
             </motion.button>
          ))}
          {filteredFoods.length === 0 && (
            <div className="flex flex-col items-center justify-center h-48 text-muted-foreground text-sm opacity-50">
                <Search className="w-8 h-8 mb-2" />
                No hay alimentos en esta categoría.
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
};

export default SmartFridge;