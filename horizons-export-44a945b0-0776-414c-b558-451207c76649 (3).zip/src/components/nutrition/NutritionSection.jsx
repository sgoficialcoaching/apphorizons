import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    CalendarDays, ChefHat, Dumbbell, Flame, Zap, 
    ArrowRight, CheckCircle2, Circle, Trash2,
    User, RefreshCw, Calculator
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { CircularProgressbarWithChildren, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

// Logic & DB
import { 
    calculateDailyTargets, 
    generateDynamicPlans,
    getEquivalentFoods
} from '@/lib/nutritionLogic';
import { 
    getNutritionProfile, upsertNutritionProfile, 
    getMealsForDate, addMeal, addMealItem, deleteMealsForDate, 
    getMealItems, deleteMealItem, updateMeal
} from '@/lib/database';
import { addXpAndBoosties } from '@/lib/gamification';

// ----------------------------------------------------------------------
// MAIN COMPONENT
// ----------------------------------------------------------------------

const NutritionSection = ({ userId }) => {
    const [activeTab, setActiveTab] = useState('history');
    
    // State
    const [profile, setProfile] = useState(null);
    const [generatedPlans, setGeneratedPlans] = useState([]);
    const [meals, setMeals] = useState([]);
    const [dailyTotals, setDailyTotals] = useState({ kcal: 0, p: 0, c: 0, f: 0 });
    const [loading, setLoading] = useState(true);

    // Initial Load & Event Listener
    useEffect(() => {
        if (!userId) return;
        loadData();

        const handleGlobalUpdate = () => {
             loadData();
        };
        window.addEventListener('nutrition_updated', handleGlobalUpdate);
        return () => window.removeEventListener('nutrition_updated', handleGlobalUpdate);
    }, [userId]);

    const loadData = () => {
        setLoading(true);
        // 1. Get Profile
        const userProfile = getNutritionProfile(userId);
        setProfile(userProfile);

        // 2. If profile exists, calc plans
        if (userProfile) {
            const targets = calculateDailyTargets(userProfile);
            const plans = generateDynamicPlans(userProfile); // Pass full profile
            setGeneratedPlans(plans);
        }

        // 3. Get Today's History
        const today = new Date();
        const rawMeals = getMealsForDate(userId, today);
        
        // Enrich meals with items and stats
        let totals = { kcal: 0, p: 0, c: 0, f: 0 };
        const enrichedMeals = rawMeals.map(m => {
            const items = getMealItems(userId, m.id);
            let mStats = { kcal: 0, p: 0, c: 0, f: 0 };
            
            // Calculate item totals
            const itemsWithStats = items.map(i => {
                const k = (i.kcal_100g * i.gramos) / 100;
                const p = (i.p_100g * i.gramos) / 100;
                const c = (i.c_100g * i.gramos) / 100;
                const f = (i.g_100g * i.gramos) / 100;
                mStats.kcal += k; mStats.p += p; mStats.c += c; mStats.f += f;
                return { ...i, k, p, c, f };
            });
            
            // Only add to daily totals if meal is completed
            if (m.is_completed) {
                totals.kcal += mStats.kcal;
                totals.p += mStats.p;
                totals.c += mStats.c;
                totals.f += mStats.f;
            }

            return { ...m, items: itemsWithStats, stats: mStats };
        });

        setMeals(enrichedMeals);
        setDailyTotals(totals);
        setLoading(false);
    };

    const handleProfileUpdate = (newProfileData) => {
        upsertNutritionProfile(userId, newProfileData);
        // Dispatch event to update everything
        window.dispatchEvent(new Event('nutrition_updated'));
        
        toast({ title: "Perfil Actualizado", description: "Tus macros y planes se han recalculado." });
    };

    const handleLoadPlan = (plan) => {
        const today = new Date();
        // Clear existing meals for today
        deleteMealsForDate(userId, today);
        
        // Add new meals from plan
        plan.meals.forEach(m => {
            const newMeal = addMeal(userId, {
                nombre: m.name,
                dishName: m.dishName,
                type: m.type,
                fecha: today.toISOString()
            });

            m.items.forEach(item => {
                addMealItem(userId, newMeal.id, {
                    food_id: item.id,
                    gramos: item.grams
                });
            });
        });

        // Dispatch update
        window.dispatchEvent(new Event('nutrition_updated'));
        setActiveTab('history');
        toast({ title: "Plan Cargado", description: "Tu menú diario ha sido actualizado." });
    };

    const toggleMealComplete = async (mealId, currentStatus) => {
        const newStatus = !currentStatus;
        updateMeal(userId, mealId, { is_completed: newStatus });
        
        // Award XP only when marking as complete
        if (newStatus) {
            const reward = await addXpAndBoosties(userId, 'MEAL_LOGGED');
            if (reward) {
                toast({
                    title: "¡Comida Completada! 🎉",
                    description: `+${reward.earnedXp} XP  |  +${reward.earnedBoosties} Boosties`,
                    className: "bg-[var(--neon-yellow)] text-black border-none font-bold"
                });
            }
        }

        // Immediate Dispatch
        window.dispatchEvent(new Event('nutrition_updated'));
    };

    const deleteMeal = (mealId) => {
        const items = getMealItems(userId, mealId);
        items.forEach(i => deleteMealItem(userId, i.id));
        // Also delete the meal itself to clean up
        // Currently DB abstraction doesn't support direct meal delete by ID without complex logic, 
        // so we'll just remove items which effectively clears it from calculation, 
        // or re-fetch for cleaner UI. 
        // For now, let's just trigger update.
        window.dispatchEvent(new Event('nutrition_updated'));
    };

    const handleSwapFood = (mealId, oldItemId, newItem) => {
        deleteMealItem(userId, oldItemId);
        addMealItem(userId, mealId, { food_id: newItem.id, gramos: newItem.equivalent_grams });
        
        window.dispatchEvent(new Event('nutrition_updated'));
        toast({ title: "Alimento Sustituido", description: `${newItem.name} añadido al plan.` });
    };

    return (
        <div className="w-full max-w-4xl mx-auto px-4 pb-24 pt-6">
            <div className="flex items-center justify-center mb-8">
                <h1 className="text-3xl font-black italic uppercase text-white tracking-tighter">
                    Nutrition <span className="text-[var(--neon-yellow)]">OS</span>
                </h1>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid grid-cols-3 bg-[#15171B] border border-white/5 rounded-2xl p-1 mb-8 h-14 shadow-lg">
                    <TabsTrigger value="profile" className="rounded-xl data-[state=active]:bg-[var(--neon-yellow)] data-[state=active]:text-black font-bold uppercase tracking-wide text-xs md:text-sm">
                        <User className="w-4 h-4 mr-2" /> Perfil
                    </TabsTrigger>
                    <TabsTrigger value="plans" className="rounded-xl data-[state=active]:bg-[var(--neon-yellow)] data-[state=active]:text-black font-bold uppercase tracking-wide text-xs md:text-sm">
                        <ChefHat className="w-4 h-4 mr-2" /> Planes
                    </TabsTrigger>
                    <TabsTrigger value="history" className="rounded-xl data-[state=active]:bg-[var(--neon-yellow)] data-[state=active]:text-black font-bold uppercase tracking-wide text-xs md:text-sm">
                        <CalendarDays className="w-4 h-4 mr-2" /> Diario
                    </TabsTrigger>
                </TabsList>

                <AnimatePresence mode="wait">
                    {/* TAB: PROFILE */}
                    <TabsContent value="profile" key="profile" className="focus-visible:outline-none">
                        <ProfileTab 
                            profile={profile} 
                            onSave={handleProfileUpdate} 
                        />
                    </TabsContent>

                    {/* TAB: PLANS */}
                    <TabsContent value="plans" key="plans" className="focus-visible:outline-none">
                         <PlansTab 
                            plans={generatedPlans} 
                            onLoadPlan={handleLoadPlan}
                            hasProfile={!!profile}
                            onGoToProfile={() => setActiveTab('profile')}
                        />
                    </TabsContent>

                    {/* TAB: HISTORY */}
                    <TabsContent value="history" key="history" className="focus-visible:outline-none">
                        <HistoryTab 
                            meals={meals} 
                            totals={dailyTotals}
                            targets={profile ? calculateDailyTargets(profile) : { calories: 2000, protein: 150, carbs: 250, fat: 60 }}
                            onToggleComplete={toggleMealComplete}
                            onDeleteMeal={deleteMeal}
                            onSwapFood={handleSwapFood}
                        />
                    </TabsContent>
                </AnimatePresence>
            </Tabs>
        </div>
    );
};

// ----------------------------------------------------------------------
// SUB-COMPONENTS (TABS)
// ----------------------------------------------------------------------

const ProfileTab = ({ profile, onSave }) => {
    const [formData, setFormData] = useState({
        peso_kg: profile?.peso_kg || 75,
        altura_cm: profile?.altura_cm || 175,
        edad: profile?.edad || 25,
        sexo: profile?.sexo || 'male',
        factor_actividad: profile?.factor_actividad || 'moderate',
        objetivo: profile?.objetivo || 'gain'
    });
    
    // Live calculation for preview
    const targets = calculateDailyTargets(formData);

    const handleChange = (field, value) => {
        setFormData(prev => ({...prev, [field]: value}));
    };

    return (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <div className="bg-[#121212] border border-white/10 rounded-[2rem] p-6 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-[var(--neon-yellow)]/5 blur-[80px] rounded-full pointer-events-none" />
                
                {/* Inputs Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10">
                    <div className="space-y-5">
                        <h3 className="text-sm font-black uppercase text-gray-500 tracking-widest mb-4">Datos Biométricos</h3>
                        
                        <div className="grid grid-cols-3 gap-3">
                            <InputGroup label="Peso (kg)" value={formData.peso_kg} onChange={v => handleChange('peso_kg', parseFloat(v))} type="number" />
                            <InputGroup label="Altura (cm)" value={formData.altura_cm} onChange={v => handleChange('altura_cm', parseFloat(v))} type="number" />
                            <InputGroup label="Edad" value={formData.edad} onChange={v => handleChange('edad', parseFloat(v))} type="number" />
                        </div>

                        <div>
                            <label className="text-[10px] font-black uppercase text-gray-600 tracking-widest mb-2 block">Sexo</label>
                            <div className="grid grid-cols-2 gap-2">
                                <SelectButton active={formData.sexo === 'male'} onClick={() => handleChange('sexo', 'male')}>Hombre</SelectButton>
                                <SelectButton active={formData.sexo === 'female'} onClick={() => handleChange('sexo', 'female')}>Mujer</SelectButton>
                            </div>
                        </div>

                        <div>
                            <label className="text-[10px] font-black uppercase text-gray-600 tracking-widest mb-2 block">Actividad</label>
                            <select 
                                value={formData.factor_actividad} 
                                onChange={e => handleChange('factor_actividad', e.target.value)} 
                                className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white font-bold text-sm focus:border-[var(--neon-yellow)] outline-none"
                            >
                                <option value="sedentary">Sedentario (Poco/Nada)</option>
                                <option value="light">Ligero (1-3 días)</option>
                                <option value="moderate">Moderado (3-5 días)</option>
                                <option value="active">Activo (6-7 días)</option>
                                <option value="veryActive">Muy Activo (Físico + Gym)</option>
                            </select>
                        </div>
                    </div>

                    <div className="space-y-5">
                        <h3 className="text-sm font-black uppercase text-gray-500 tracking-widest mb-4">Objetivo</h3>
                        <div className="space-y-3">
                             <GoalButton 
                                active={formData.objetivo === 'loss'} 
                                onClick={() => handleChange('objetivo', 'loss')}
                                title="Definición"
                                subtitle="Déficit Calórico"
                                icon={Flame} color="text-orange-500"
                            />
                            <GoalButton 
                                active={formData.objetivo === 'maintenance'} 
                                onClick={() => handleChange('objetivo', 'maintenance')}
                                title="Mantenimiento"
                                subtitle="Recomposición"
                                icon={Zap} color="text-blue-500"
                            />
                            <GoalButton 
                                active={formData.objetivo === 'gain'} 
                                onClick={() => handleChange('objetivo', 'gain')}
                                title="Volumen"
                                subtitle="Superávit Calórico"
                                icon={Dumbbell} color="text-[var(--neon-yellow)]"
                            />
                        </div>

                        {/* Live Preview */}
                        <div className="mt-6 bg-white/5 rounded-xl p-4 border border-white/10">
                            <div className="text-center mb-3">
                                <div className="text-3xl font-black text-white">{targets.calories}</div>
                                <div className="text-[10px] font-bold uppercase text-gray-500">Kcal Objetivo</div>
                            </div>
                            <div className="flex justify-between text-xs font-bold text-gray-400">
                                <span>P: {targets.protein}g</span>
                                <span>C: {targets.carbs}g</span>
                                <span>G: {targets.fat}g</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="mt-8 relative z-10">
                    <Button onClick={() => onSave(formData)} className="w-full h-14 bg-[var(--neon-yellow)] text-black font-black uppercase tracking-widest rounded-xl hover:scale-[1.01] transition-transform">
                        Guardar y Calcular <Calculator className="w-4 h-4 ml-2" />
                    </Button>
                </div>
            </div>
        </motion.div>
    );
};

const PlansTab = ({ plans, onLoadPlan, hasProfile, onGoToProfile }) => {
    if (!hasProfile) {
        return (
            <div className="text-center py-20 bg-[#121212] rounded-3xl border border-white/5">
                <ChefHat className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">Configura tu Perfil</h3>
                <p className="text-gray-400 mb-6 max-w-xs mx-auto text-sm">Necesitamos tus datos para calcular las cantidades exactas de tus menús.</p>
                <Button onClick={onGoToProfile} variant="outline" className="border-[var(--neon-yellow)] text-[var(--neon-yellow)] hover:bg-[var(--neon-yellow)] hover:text-black">
                    Ir al Perfil
                </Button>
            </div>
        );
    }

    return (
        <div className="grid grid-cols-1 gap-6 pb-10">
            {plans.map((plan, idx) => (
                <motion.div 
                    key={plan.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className="bg-[#141414] border border-white/10 rounded-3xl overflow-hidden hover:border-[var(--neon-yellow)]/30 transition-colors group"
                >
                    {/* Header */}
                    <div className="p-6 bg-white/[0.02] border-b border-white/5 flex justify-between items-start">
                        <div>
                            <h3 className="text-xl font-black italic uppercase text-white mb-1 group-hover:text-[var(--neon-yellow)] transition-colors">{plan.title}</h3>
                            <p className="text-xs text-gray-400 max-w-md">{plan.description}</p>
                        </div>
                        <div className="text-right">
                            <div className="text-2xl font-black text-white leading-none">{plan.calories}</div>
                            <div className="text-[10px] font-bold uppercase text-gray-500">Kcal</div>
                        </div>
                    </div>

                    {/* Macros Bar */}
                    <div className="px-6 py-3 bg-black/20 flex gap-4 text-xs font-bold border-b border-white/5">
                        <span className="text-blue-400">P: {plan.macros.p}g</span>
                        <span className="text-orange-400">C: {plan.macros.c}g</span>
                        <span className="text-yellow-400">G: {plan.macros.f}g</span>
                    </div>

                    {/* Meals Preview */}
                    <div className="p-6 space-y-4">
                        {plan.meals.map((meal, i) => (
                            <div key={i} className="flex justify-between items-center text-sm">
                                <div className="flex items-center gap-3">
                                    <span className="text-[10px] font-bold text-gray-600 w-16 uppercase">{meal.name}</span>
                                    <span className="text-gray-300 font-medium">{meal.dishName}</span>
                                </div>
                                <div className="text-xs text-gray-500 font-mono">
                                    {Math.round(meal.stats.k)} kcal
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Action */}
                    <div className="p-4 bg-white/[0.02] border-t border-white/5">
                        <Button 
                            onClick={() => onLoadPlan(plan)}
                            className="w-full bg-white text-black hover:bg-[var(--neon-yellow)] font-bold uppercase tracking-wider"
                        >
                            Cargar Este Plan <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                    </div>
                </motion.div>
            ))}
        </div>
    );
};

const HistoryTab = ({ meals, totals, targets, onToggleComplete, onDeleteMeal, onSwapFood }) => {
    return (
        <div className="space-y-6">
            {/* Totals Card */}
            <div className="bg-[#121212] rounded-[2rem] p-6 border border-white/10 relative overflow-hidden">
                <div className="flex items-center gap-8 relative z-10">
                    {/* Donut */}
                    <div className="w-32 h-32 flex-shrink-0">
                        <CircularProgressbarWithChildren
                            value={(totals.kcal / targets.calories) * 100}
                            styles={buildStyles({ 
                                pathColor: totals.kcal > targets.calories ? '#ef4444' : '#FACC15', 
                                trailColor: 'rgba(255,255,255,0.05)'
                            })}
                        >
                            <div className="text-center">
                                <div className="text-2xl font-black text-white">{Math.round(totals.kcal)}</div>
                                <div className="text-[9px] uppercase font-bold text-gray-500">de {targets.calories}</div>
                            </div>
                        </CircularProgressbarWithChildren>
                    </div>

                    {/* Bars */}
                    <div className="flex-1 space-y-4">
                        <MacroBar label="Proteína" current={totals.p} target={targets.protein} color="bg-blue-500" />
                        <MacroBar label="Carbos" current={totals.c} target={targets.carbs} color="bg-orange-500" />
                        <MacroBar label="Grasas" current={totals.f} target={targets.fat} color="bg-yellow-500" />
                    </div>
                </div>
            </div>

            {/* Meals List */}
            <div className="space-y-4">
                {meals.length === 0 ? (
                    <div className="text-center py-12 border-2 border-dashed border-white/10 rounded-3xl">
                        <p className="text-gray-400 font-medium">No hay comidas hoy</p>
                        <p className="text-xs text-gray-600 mt-1">Ve a la pestaña "Planes" para cargar un menú</p>
                    </div>
                ) : (
                    meals.map((meal) => (
                        <MealItem 
                            key={meal.id} 
                            meal={meal} 
                            onToggleComplete={onToggleComplete}
                            onDeleteMeal={onDeleteMeal}
                            onSwapFood={onSwapFood}
                        />
                    ))
                )}
            </div>
        </div>
    );
};

// Subcomponent for Meal Item to handle swap state internally
const MealItem = ({ meal, onToggleComplete, onDeleteMeal, onSwapFood }) => {
    const [swappingItemId, setSwappingItemId] = useState(null);
    const [alternatives, setAlternatives] = useState([]);

    const handleSwapClick = (item) => {
        if (swappingItemId === item.id) {
            setSwappingItemId(null);
            return;
        }
        
        const alts = getEquivalentFoods(item, item.gramos);
        setAlternatives(alts);
        setSwappingItemId(item.id);
    };

    const confirmSwap = (item, alt) => {
        onSwapFood(meal.id, item.id, alt);
        setSwappingItemId(null);
        setAlternatives([]);
    };

    return (
        <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`rounded-2xl border transition-all ${meal.is_completed ? 'bg-green-900/10 border-green-500/20' : 'bg-[#141414] border-white/5'}`}
        >
            <div className="p-4 border-b border-white/5 flex justify-between items-start">
                <div>
                    <div className="text-[10px] font-black uppercase text-gray-500 tracking-widest mb-1">{meal.nombre}</div>
                    <div className="text-lg font-bold text-white flex items-center gap-2">
                        {meal.dishName}
                        {meal.is_completed && <CheckCircle2 className="w-5 h-5 text-green-500" />}
                    </div>
                </div>
                <div className="flex gap-2">
                    <Button 
                        size="icon" variant="ghost" 
                        onClick={() => onToggleComplete(meal.id, meal.is_completed)}
                        className={`rounded-full ${meal.is_completed ? 'text-green-500 bg-green-500/10 hover:bg-green-500/20' : 'text-gray-400 bg-white/5 hover:text-white hover:bg-white/10'}`}
                    >
                        {meal.is_completed ? <CheckCircle2 className="w-5 h-5" /> : <Circle className="w-5 h-5" />}
                    </Button>
                    {!meal.is_completed && (
                        <Button size="icon" variant="ghost" onClick={() => onDeleteMeal(meal.id)} className="text-gray-600 hover:text-red-500 hover:bg-red-500/10 rounded-full">
                            <Trash2 className="w-4 h-4" />
                        </Button>
                    )}
                </div>
            </div>

            <div className="divide-y divide-white/5">
                {meal.items.map((item, i) => (
                    <div key={i} className="p-4 hover:bg-white/[0.02] transition-colors">
                        <div className="flex justify-between items-center mb-2">
                            <div className="flex-1">
                                <div className="text-sm font-bold text-white mb-0.5">{item.name}</div>
                                <div className="flex items-center gap-3 text-[10px] uppercase font-bold text-gray-500">
                                    <span className="text-[var(--neon-yellow)] bg-[var(--neon-yellow)]/10 px-1.5 py-0.5 rounded">{Math.round(item.gramos)}g</span>
                                    <span>{Math.round(item.k)} kcal</span>
                                </div>
                            </div>
                            {!meal.is_completed && (
                                <Button 
                                    size="sm" 
                                    variant="ghost" 
                                    className={`h-8 w-8 p-0 rounded-full ${swappingItemId === item.id ? 'text-[var(--neon-yellow)] bg-[var(--neon-yellow)]/10' : 'text-gray-500 hover:text-white hover:bg-white/10'}`}
                                    onClick={() => handleSwapClick(item)}
                                >
                                    <RefreshCw className={`w-3.5 h-3.5 ${swappingItemId === item.id ? 'animate-spin' : ''}`} />
                                </Button>
                            )}
                        </div>
                        
                        {/* Macro details inline */}
                        <div className="grid grid-cols-3 gap-2 text-[10px] text-gray-600 font-medium">
                            <div className="flex items-center gap-1"><div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>P: {Math.round(item.p)}g</div>
                            <div className="flex items-center gap-1"><div className="w-1.5 h-1.5 rounded-full bg-orange-500"></div>C: {Math.round(item.c)}g</div>
                            <div className="flex items-center gap-1"><div className="w-1.5 h-1.5 rounded-full bg-yellow-500"></div>G: {Math.round(item.f)}g</div>
                        </div>

                        {/* Swap Interface */}
                        <AnimatePresence>
                            {swappingItemId === item.id && (
                                <motion.div 
                                    initial={{ height: 0, opacity: 0 }} 
                                    animate={{ height: 'auto', opacity: 1 }}
                                    exit={{ height: 0, opacity: 0 }}
                                    className="overflow-hidden mt-3"
                                >
                                    <div className="bg-[#0A0A0A] border border-white/10 rounded-xl p-2 space-y-2">
                                        <p className="text-[10px] uppercase font-bold text-gray-500 pl-1">Alternativas similares</p>
                                        {alternatives.length > 0 ? (
                                            alternatives.map(alt => (
                                                <button 
                                                    key={alt.id}
                                                    onClick={() => confirmSwap(item, alt)}
                                                    className="w-full flex justify-between items-center p-2 rounded-lg hover:bg-white/10 transition-colors text-left group"
                                                >
                                                    <div>
                                                        <div className="text-xs font-bold text-white group-hover:text-[var(--neon-yellow)]">{alt.name}</div>
                                                        <div className="text-[10px] text-gray-500">{alt.equivalent_grams}g (Eq. calórico)</div>
                                                    </div>
                                                    <div className="text-[10px] bg-white/5 px-2 py-1 rounded text-gray-400 group-hover:bg-[var(--neon-yellow)] group-hover:text-black font-bold">
                                                        Seleccionar
                                                    </div>
                                                </button>
                                            ))
                                        ) : (
                                            <p className="text-xs text-gray-500 p-2 italic">No se encontraron alternativas directas.</p>
                                        )}
                                    </div>
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </div>
                ))}
            </div>

            <div className="flex gap-4 p-4 bg-black/20 border-t border-white/5 text-[10px] uppercase font-bold text-gray-500">
                <span className="text-white">{Math.round(meal.stats.kcal)} kcal</span>
                <span className="text-blue-400">P: {Math.round(meal.stats.p)}</span>
                <span className="text-orange-400">C: {Math.round(meal.stats.c)}</span>
                <span className="text-yellow-400">G: {Math.round(meal.stats.f)}</span>
            </div>
        </motion.div>
    );
};

// ----------------------------------------------------------------------
// HELPER COMPONENTS
// ----------------------------------------------------------------------

const InputGroup = ({ label, value, onChange, type }) => (
    <div>
        <label className="text-[10px] font-black uppercase text-gray-600 tracking-widest ml-1">{label}</label>
        <input 
            type={type} value={value} onChange={e => onChange(e.target.value)}
            className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white font-bold text-lg focus:border-[var(--neon-yellow)] outline-none"
        />
    </div>
);

const SelectButton = ({ active, onClick, children }) => (
    <button 
        onClick={onClick}
        className={`p-3 rounded-xl border font-bold text-xs uppercase tracking-wider transition-all ${active ? 'bg-white text-black border-white' : 'bg-black/20 text-gray-500 border-white/5'}`}
    >
        {children}
    </button>
);

const GoalButton = ({ active, onClick, title, subtitle, icon: Icon, color }) => (
    <button 
        onClick={onClick}
        className={`w-full p-4 rounded-xl border flex items-center gap-4 text-left transition-all ${active ? 'bg-white/10 border-white/30' : 'bg-black/20 border-white/5 hover:bg-white/5'}`}
    >
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${active ? 'bg-white text-black' : 'bg-black/40 text-gray-500'}`}>
            <Icon className={`w-5 h-5 ${active ? color.replace('text-', 'text-black') : ''}`} />
        </div>
        <div>
            <div className={`text-sm font-black uppercase ${active ? 'text-white' : 'text-gray-400'}`}>{title}</div>
            <div className={`text-[10px] font-bold ${active ? 'text-[var(--neon-yellow)]' : 'text-gray-600'}`}>{subtitle}</div>
        </div>
    </button>
);

const MacroBar = ({ label, current, target, color }) => (
    <div>
        <div className="flex justify-between text-[10px] uppercase font-bold text-gray-500 mb-1">
            <span>{label}</span>
            <span>{Math.round(current)} / {target}g</span>
        </div>
        <div className="h-2 w-full bg-black/40 rounded-full overflow-hidden">
            <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(100, (current/target)*100)}%` }}
                className={`h-full ${color}`}
            />
        </div>
    </div>
);

export default NutritionSection;