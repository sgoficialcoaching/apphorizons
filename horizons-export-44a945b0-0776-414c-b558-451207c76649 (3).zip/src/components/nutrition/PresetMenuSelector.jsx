import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Flame, Zap, Dumbbell, ChefHat, CheckCircle2, ChevronDown, ChevronUp, Repeat, ArrowRight, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { 
    DropdownMenu, 
    DropdownMenuContent, 
    DropdownMenuItem, 
    DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const PresetMenuSelector = ({ onClose, onSelect, plans }) => {
    const { user } = useAuth();
    const [localPlans, setLocalPlans] = useState([]);
    const [expandedMeals, setExpandedMeals] = useState({});
    const [selectedTab, setSelectedTab] = useState('loss');

    // Initialize - PLANS ARE ALREADY PRE-CALCULATED PASSED AS PROP
    useEffect(() => {
        if(plans && plans.length > 0) {
             setLocalPlans(JSON.parse(JSON.stringify(plans)));
        }
    }, [plans]);

    const recalculatePlanTotals = (plan) => {
         let totalKcal = 0, totalP = 0, totalC = 0, totalF = 0;
         plan.meals.forEach(meal => {
             meal.items.forEach(item => {
                 totalKcal += (item.k * item.grams / 100);
                 totalP += (item.p * item.grams / 100);
                 totalC += (item.c * item.grams / 100);
                 totalF += (item.f * item.grams / 100);
             });
         });
         return {
             ...plan,
             calories: Math.round(totalKcal),
             macros: {
                 p: Math.round(totalP),
                 c: Math.round(totalC),
                 f: Math.round(totalF)
             }
         };
    };

    const handleSwap = (planId, mealIndex, itemIndex, newFood) => {
        setLocalPlans(prevPlans => prevPlans.map(p => {
            if (p.id !== planId) return p;

            const updatedMeals = [...p.meals];
            const oldItem = updatedMeals[mealIndex].items[itemIndex];
            
            const newItem = {
                ...newFood,
                grams: newFood.grams, 
                alternatives: oldItem.alternatives 
            };

            updatedMeals[mealIndex].items[itemIndex] = newItem;
            return recalculatePlanTotals({ ...p, meals: updatedMeals });
        }));
    };

    const toggleMeal = (planId, mealIndex) => {
        setExpandedMeals(prev => ({
            ...prev,
            [`${planId}-${mealIndex}`]: !prev[`${planId}-${mealIndex}`]
        }));
    };

    const MacroBar = ({ label, value, max, colorClass, bgClass }) => {
        const percent = Math.min(100, Math.max(0, (value / max) * 100));
        return (
            <div className="flex flex-col gap-1 w-full">
                <div className="flex justify-between text-[10px] uppercase font-bold tracking-wider text-muted-foreground">
                    <span>{label}</span>
                    <span className="text-white">{Math.round(value)}g</span>
                </div>
                <div className="h-1.5 w-full bg-black/40 rounded-full overflow-hidden border border-white/5">
                    <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${percent}%` }}
                        transition={{ duration: 0.5, ease: "easeOut" }}
                        className={`h-full rounded-full ${bgClass} shadow-[0_0_10px_rgba(255,255,255,0.2)]`}
                    />
                </div>
            </div>
        );
    };

    const PlanCard = ({ plan }) => {
        const isMed = plan.id.includes('med');
        const isBudget = plan.id.includes('budget');
        
        // Visual themes based on Goal/Type
        let Icon = Dumbbell;
        let themeColor = "var(--neon-yellow)"; 
        let bgGradient = "from-yellow-500/10";
        let borderColor = "border-yellow-500/30";
        let shadowColor = "shadow-yellow-900/20";
        let barColorP = "bg-blue-500";
        let barColorC = "bg-green-500";
        let barColorF = "bg-orange-500";

        if(isMed) { 
            Icon = Zap; 
            themeColor = "#60A5FA"; // Blue-400
            bgGradient = "from-blue-500/10";
            borderColor = "border-blue-500/30";
            shadowColor = "shadow-blue-900/20";
        }
        if(isBudget) { 
            Icon = Flame; 
            themeColor = "#FB923C"; // Orange-400
            bgGradient = "from-orange-500/10";
            borderColor = "border-orange-500/30";
            shadowColor = "shadow-orange-900/20";
        }

        return (
            <motion.div 
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex flex-col rounded-[24px] border ${borderColor} bg-[#141518]/90 backdrop-blur-xl overflow-hidden group hover:border-opacity-100 hover:scale-[1.01] transition-all duration-300 w-full relative shadow-xl ${shadowColor}`}
            >
                {/* Background Glow */}
                <div className={`absolute -top-20 -right-20 w-64 h-64 bg-gradient-to-bl ${bgGradient} to-transparent blur-3xl rounded-full pointer-events-none opacity-40`}></div>

                {/* Header Section */}
                <div className="p-5 md:p-6 relative z-10 flex flex-col gap-4">
                    <div className="flex justify-between items-start">
                        <div className="flex items-center gap-3">
                            <div className="w-12 h-12 rounded-2xl flex items-center justify-center bg-black/40 border border-white/10 shadow-inner" style={{ color: themeColor }}>
                                <Icon className="w-6 h-6" />
                            </div>
                            <div>
                                <h3 className="font-black text-lg md:text-xl text-white uppercase italic leading-none mb-1 tracking-tight">{plan.title}</h3>
                                <p className="text-[10px] md:text-xs text-gray-400 font-medium leading-tight max-w-[200px]">{plan.description}</p>
                            </div>
                        </div>
                        <div className="text-right bg-black/40 px-3 py-2 rounded-xl border border-white/5">
                            <span className="text-2xl md:text-3xl font-black text-white italic tracking-tighter block leading-none" style={{ textShadow: `0 0 20px ${themeColor}40` }}>{plan.calories}</span>
                            <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest block mt-0.5">Kcal / Día</span>
                        </div>
                    </div>

                    {/* Macro Bars */}
                    <div className="grid grid-cols-3 gap-3 bg-black/20 p-3 rounded-2xl border border-white/5">
                        <MacroBar label="Prot" value={plan.macros.p} max={250} bgClass={barColorP} />
                        <MacroBar label="Carb" value={plan.macros.c} max={400} bgClass={barColorC} />
                        <MacroBar label="Fat" value={plan.macros.f} max={120} bgClass={barColorF} />
                    </div>
                </div>

                {/* Meals Accordion List */}
                <div className="flex-1 bg-[#0A0B0D]/50 border-t border-white/5 p-3 space-y-2 max-h-[350px] overflow-y-auto custom-scrollbar">
                    {plan.meals.map((meal, mIdx) => {
                        const isExpanded = expandedMeals[`${plan.id}-${mIdx}`];
                        return (
                            <div key={mIdx} className={`rounded-xl border transition-all duration-300 ${isExpanded ? 'bg-white/5 border-white/10' : 'bg-transparent border-transparent hover:bg-white/5'}`}>
                                <button 
                                    onClick={() => toggleMeal(plan.id, mIdx)}
                                    className="w-full p-3 flex items-center justify-between text-left outline-none"
                                >
                                    <div className="flex items-center gap-3 overflow-hidden">
                                        <div className="flex flex-col items-center justify-center w-8 h-8 rounded-lg bg-black/40 border border-white/5 text-[10px] font-bold text-gray-500">
                                            {mIdx + 1}
                                        </div>
                                        <div className="min-w-0">
                                            <div className="text-[9px] font-bold text-[var(--neon-yellow)] uppercase tracking-widest mb-0.5">{meal.name}</div>
                                            <div className="text-xs md:text-sm font-bold text-white leading-tight truncate pr-2">{meal.dishName}</div>
                                        </div>
                                    </div>
                                    {isExpanded ? <ChevronUp className="w-4 h-4 text-gray-400 flex-shrink-0" /> : <ChevronDown className="w-4 h-4 text-gray-400 flex-shrink-0" />}
                                </button>
                                
                                <AnimatePresence>
                                    {isExpanded && (
                                        <motion.div 
                                            initial={{ height: 0, opacity: 0 }}
                                            animate={{ height: "auto", opacity: 1 }}
                                            exit={{ height: 0, opacity: 0 }}
                                            className="overflow-hidden"
                                        >
                                            <div className="px-3 pb-3 space-y-2">
                                                <div className="h-px w-full bg-white/5 mb-2"></div>
                                                {meal.items.map((item, iIdx) => (
                                                    <div key={iIdx} className="flex justify-between items-start text-xs group/item">
                                                        <div className="flex-1 text-gray-300 pr-2">
                                                            <span className="text-white font-medium block">{item.name}</span>
                                                            <span className="text-gray-500 text-[10px]">
                                                                {Math.round(item.grams)}g • {Math.round(item.k)} kcal
                                                            </span>
                                                        </div>
                                                        
                                                        {item.alternatives && item.alternatives.length > 0 && (
                                                            <DropdownMenu>
                                                                <DropdownMenuTrigger asChild>
                                                                    <Button variant="ghost" size="sm" className="h-6 w-6 p-0 rounded-full hover:bg-[var(--neon-yellow)] hover:text-black text-gray-600">
                                                                        <Repeat className="w-3 h-3" />
                                                                    </Button>
                                                                </DropdownMenuTrigger>
                                                                <DropdownMenuContent align="end" className="w-56 bg-[#1A1C20] border border-white/10 text-white rounded-xl p-1 shadow-2xl z-[200]">
                                                                    <div className="px-2 py-1.5 text-[10px] font-bold text-gray-500 uppercase tracking-widest border-b border-white/5 mb-1">
                                                                        Alternativas ({item.name})
                                                                    </div>
                                                                    {item.alternatives.map((alt) => (
                                                                        <DropdownMenuItem 
                                                                            key={alt.id}
                                                                            onClick={() => handleSwap(plan.id, mIdx, iIdx, alt)}
                                                                            className="text-xs flex justify-between cursor-pointer focus:bg-white/10 rounded-lg p-2 transition-colors"
                                                                        >
                                                                            <span className="font-medium">{alt.name}</span>
                                                                            <span className="text-gray-500 bg-black/30 px-1.5 py-0.5 rounded text-[10px]">{Math.round(alt.grams)}g</span>
                                                                        </DropdownMenuItem>
                                                                    ))}
                                                                </DropdownMenuContent>
                                                            </DropdownMenu>
                                                        )}
                                                    </div>
                                                ))}
                                                <div className="flex justify-end pt-2 mt-2 border-t border-white/5">
                                                    <div className="text-[9px] font-mono text-gray-500 bg-black/30 px-2 py-1 rounded-md border border-white/5">
                                                        Total: <span className="text-white">{meal.stats.k}</span> kcal • P<span className="text-blue-400">{meal.stats.p}</span> C<span className="text-green-400">{meal.stats.c}</span> F<span className="text-orange-400">{meal.stats.f}</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </div>
                        );
                    })}
                </div>

                {/* Footer Action */}
                <div className="p-4 border-t border-white/5 bg-[#141518] relative z-20">
                    <Button 
                        className="w-full h-12 text-xs md:text-sm font-black uppercase tracking-widest bg-white text-black hover:bg-[var(--neon-yellow)] hover:scale-[1.02] transition-all shadow-lg flex items-center justify-center gap-2"
                        onClick={() => {
                            onSelect(plan);
                        }}
                    >
                        <CheckCircle2 className="w-4 h-4 md:w-5 md:h-5" />
                        Cargar Plan Completo
                    </Button>
                </div>
            </motion.div>
        );
    };

    // Filter plans by goal
    const lossPlans = localPlans.filter(p => p.goal === 'loss');
    const maintPlans = localPlans.filter(p => p.goal === 'maintenance');
    const gainPlans = localPlans.filter(p => p.goal === 'gain');

    return (
        <AnimatePresence>
            <div className="fixed inset-0 bg-black/95 backdrop-blur-2xl flex items-center justify-center z-[100] md:p-6 overflow-hidden">
                <motion.div
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.98 }}
                    className="bg-[#0F1115] border border-white/10 w-full h-full md:rounded-[32px] md:max-w-7xl md:h-[90vh] flex flex-col shadow-2xl overflow-hidden relative"
                >
                    {/* Main Header */}
                    <div className="p-4 md:p-6 border-b border-white/5 bg-gradient-to-r from-[#1A1C20] to-transparent flex justify-between items-center shrink-0 z-30 relative">
                        <div className="flex items-center gap-3 md:gap-4">
                            <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl bg-[var(--neon-yellow)] flex items-center justify-center text-black shadow-[0_0_25px_rgba(255,214,0,0.3)] shrink-0">
                                <ChefHat className="w-5 h-5 md:w-6 md:h-6" />
                            </div>
                            <div className="min-w-0">
                                <h2 className="text-lg md:text-2xl font-black italic uppercase text-white tracking-tighter leading-none truncate">
                                    Menús <span className="text-[var(--neon-yellow)]">Profesionales</span>
                                </h2>
                                <p className="text-[10px] md:text-xs text-gray-400 font-medium truncate">
                                    9 Estrategias Nutricionales Optimizadas
                                </p>
                            </div>
                        </div>
                        <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full hover:bg-white/10 text-white shrink-0 -mr-2">
                            <X className="w-6 h-6" />
                        </Button>
                    </div>

                    {/* Tabs Navigation */}
                    <Tabs defaultValue="loss" className="flex-1 flex flex-col h-full overflow-hidden" onValueChange={setSelectedTab}>
                        <div className="px-4 md:px-6 py-2 border-b border-white/5 bg-[#0F1115] z-20 overflow-x-auto no-scrollbar">
                            <TabsList className="bg-transparent md:bg-black/40 border-0 md:border border-white/5 p-0 md:p-1 rounded-xl flex gap-2 md:gap-1 w-full md:w-auto min-w-max h-auto">
                                <TabsTrigger 
                                    value="loss" 
                                    className="flex-1 md:flex-none data-[state=active]:bg-green-600 data-[state=active]:text-white data-[state=active]:shadow-[0_0_15px_rgba(22,163,74,0.4)] rounded-lg text-[10px] md:text-xs font-bold uppercase tracking-wider px-4 py-2.5 md:py-2 transition-all border border-transparent data-[state=active]:border-green-400/50 bg-white/5 md:bg-transparent"
                                >
                                    Pérdida de Grasa
                                </TabsTrigger>
                                <TabsTrigger 
                                    value="maintenance" 
                                    className="flex-1 md:flex-none data-[state=active]:bg-blue-600 data-[state=active]:text-white data-[state=active]:shadow-[0_0_15px_rgba(37,99,235,0.4)] rounded-lg text-[10px] md:text-xs font-bold uppercase tracking-wider px-4 py-2.5 md:py-2 transition-all border border-transparent data-[state=active]:border-blue-400/50 bg-white/5 md:bg-transparent"
                                >
                                    Mantenimiento
                                </TabsTrigger>
                                <TabsTrigger 
                                    value="gain" 
                                    className="flex-1 md:flex-none data-[state=active]:bg-orange-600 data-[state=active]:text-white data-[state=active]:shadow-[0_0_15px_rgba(234,88,12,0.4)] rounded-lg text-[10px] md:text-xs font-bold uppercase tracking-wider px-4 py-2.5 md:py-2 transition-all border border-transparent data-[state=active]:border-orange-400/50 bg-white/5 md:bg-transparent"
                                >
                                    Ganancia Muscular
                                </TabsTrigger>
                            </TabsList>
                        </div>

                        {/* Content Area */}
                        <div className="flex-1 overflow-y-auto custom-scrollbar bg-[url('https://images.unsplash.com/photo-1550989460-0adf9ea622e2?q=80&w=2787&auto=format&fit=crop')] bg-cover bg-center relative">
                            <div className="absolute inset-0 bg-[#0F1115]/95 backdrop-blur-sm pointer-events-none" />
                            
                            <div className="relative z-10 max-w-7xl mx-auto p-4 md:p-6 pb-24 md:pb-6">
                                <TabsContent value="loss" className="mt-0 outline-none h-full focus:ring-0">
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                        {lossPlans.map(plan => <PlanCard key={plan.id} plan={plan} />)}
                                    </div>
                                </TabsContent>
                                
                                <TabsContent value="maintenance" className="mt-0 outline-none h-full focus:ring-0">
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                        {maintPlans.map(plan => <PlanCard key={plan.id} plan={plan} />)}
                                    </div>
                                </TabsContent>

                                <TabsContent value="gain" className="mt-0 outline-none h-full focus:ring-0">
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                        {gainPlans.map(plan => <PlanCard key={plan.id} plan={plan} />)}
                                    </div>
                                </TabsContent>
                            </div>
                        </div>
                    </Tabs>
                </motion.div>
            </div>
        </AnimatePresence>
    );
};

export default PresetMenuSelector;