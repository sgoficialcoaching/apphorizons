import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, Camera, Upload, Loader2, Sparkles, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import FoodSearchModal from './FoodSearchModal';

const AiScanScreen = ({ user, onBack, onAddFood, date }) => {
    const [image, setImage] = useState(null);
    const [imageUrl, setImageUrl] = useState(null);
    const [isScanning, setIsScanning] = useState(false);
    const [scanResult, setScanResult] = useState(null);
    const [error, setError] = useState(null);
    const fileInputRef = useRef(null);
    const [isSearchModalOpen, setSearchModalOpen] = useState(false);

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            if (file.size > 10 * 1024 * 1024) {
                 toast({
                    variant: 'destructive',
                    title: 'Imagen demasiado grande',
                    description: 'Por favor, selecciona una imagen de menos de 10MB.'
                });
                return;
            }
            const reader = new FileReader();
            reader.onloadend = () => {
                setImageUrl(reader.result);
                setImage(file);
                handleScan(file);
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleScan = async (file) => {
        if (!file) return;

        setIsScanning(true);
        setError(null);
        setScanResult(null);

        // SIMULACIÓN DE IA (Mock Local)
        setTimeout(() => {
            try {
                // Simular resultado exitoso el 90% de las veces
                if (Math.random() > 0.1) {
                     const mockData = {
                        description: "Plato saludable con proteína magra y vegetales.",
                        macros: {
                            calories: 450 + Math.random() * 100,
                            protein: 35 + Math.random() * 10,
                            carbs: 40 + Math.random() * 10,
                            fat: 15 + Math.random() * 5
                        }
                     };
                     setScanResult(mockData);
                } else {
                    throw new Error("No se pudo identificar el alimento claramente.");
                }
            } catch (err) {
                console.error('Error scanning food:', err);
                setError(`Error al analizar: ${err.message}. (Simulación)`);
            } finally {
                setIsScanning(false);
            }
        }, 2500);
    };

    const reset = () => {
        setImage(null);
        setImageUrl(null);
        setIsScanning(false);
        setScanResult(null);
        setError(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const handleSelectFood = (food, grams) => {
        onAddFood(food, grams, date);
        setSearchModalOpen(false);
    };

    return (
        <motion.div 
            initial={{ opacity: 0, x: 20 }} 
            animate={{ opacity: 1, x: 0 }} 
            className="p-4 md:p-0 space-y-6"
        >
             {isSearchModalOpen && <FoodSearchModal onSelectFood={handleSelectFood} onClose={() => setSearchModalOpen(false)} />}
            <div className="flex items-center gap-4">
                <Button variant="ghost" size="icon" onClick={imageUrl ? reset : onBack}><ChevronLeft /></Button>
                <h2 className="text-xl sm:text-2xl font-bold">Escanear Comida</h2>
            </div>

            {!imageUrl && (
                <div className="text-center space-y-4 p-6 sm:p-8 glass-effect rounded-2xl">
                    <h3 className="text-lg sm:text-xl font-semibold">Analiza tu plato con IA</h3>
                    <p className="text-muted-foreground text-sm sm:text-base">Haz una foto de tu comida y la IA identificará los alimentos y sus macros aproximados.</p>
                    <input
                        type="file"
                        accept="image/*"
                        ref={fileInputRef}
                        onChange={handleImageChange}
                        className="hidden"
                    />
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        <Button onClick={() => { if(fileInputRef.current) { fileInputRef.current.capture = 'environment'; fileInputRef.current.click(); } }} className="w-full sm:w-auto btn-primary py-6">
                            <Camera className="w-5 h-5 mr-2" /> Hacer Foto
                        </Button>
                        <Button onClick={() => { if(fileInputRef.current) { fileInputRef.current.removeAttribute('capture'); fileInputRef.current.click(); } }} className="w-full sm:w-auto btn-secondary py-6">
                            <Upload className="w-5 h-5 mr-2" /> Subir Imagen
                        </Button>
                    </div>
                </div>
            )}

            {imageUrl && (
                <div className="space-y-4">
                    <div className="relative">
                        <img src={imageUrl} alt="Comida para analizar" className="rounded-xl w-full h-auto max-h-60 sm:max-h-80 object-cover" />
                        {isScanning && (
                            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm flex flex-col items-center justify-center rounded-xl">
                                <Loader2 className="w-8 h-8 animate-spin text-primary" />
                                <p className="mt-2 text-white font-semibold">Analizando (Simulado)...</p>
                            </div>
                        )}
                    </div>

                    {error && (
                        <div className="text-center p-6 sm:p-8 glass-effect rounded-2xl space-y-3 border-l-4 border-destructive">
                             <AlertTriangle className="w-10 h-10 mx-auto text-destructive" />
                             <h3 className="font-semibold">Error en el Análisis</h3>
                             <p className="text-sm text-muted-foreground">{error}</p>
                             <Button onClick={reset} variant="outline">Intentar de Nuevo</Button>
                        </div>
                    )}
                    
                    {scanResult && (
                        <motion.div initial={{opacity: 0, y:10}} animate={{opacity:1, y:0}} className="p-4 sm:p-6 glass-effect rounded-2xl space-y-4">
                            <div className='flex items-center gap-2'>
                                <Sparkles className="w-6 h-6 text-primary" />
                                <h3 className="text-lg font-bold">Resultados (Demo IA)</h3>
                            </div>
                           
                            <p className='text-sm text-muted-foreground'>{scanResult.description}</p>
                            
                            <div className="grid grid-cols-3 gap-2 text-center">
                                <div className="bg-input p-2 rounded-lg">
                                    <p className="text-xs text-muted-foreground">Calorías</p>
                                    <p className="font-bold text-lg">{Math.round(scanResult.macros.calories)}</p>
                                </div>
                                <div className="bg-input p-2 rounded-lg">
                                    <p className="text-xs text-muted-foreground">Proteína</p>
                                    <p className="font-bold text-lg">{Math.round(scanResult.macros.protein)}g</p>
                                </div>
                                <div className="bg-input p-2 rounded-lg">
                                    <p className="text-xs text-muted-foreground">Carbs</p>
                                    <p className="font-bold text-lg">{Math.round(scanResult.macros.carbs)}g</p>
                                </div>
                            </div>
                             <p className="text-xs text-center text-muted-foreground pt-2">Valores simulados. En producción esto conectaría con GPT-4.</p>

                            <div className='flex gap-2'>
                                <Button variant="outline" className="w-full" onClick={reset}>Escanear Otro</Button>
                                <Button className="w-full btn-primary" onClick={() => setSearchModalOpen(true)}>Añadir Manualmente</Button>
                            </div>
                        </motion.div>
                    )}
                </div>
            )}
        </motion.div>
    );
};

export default AiScanScreen;