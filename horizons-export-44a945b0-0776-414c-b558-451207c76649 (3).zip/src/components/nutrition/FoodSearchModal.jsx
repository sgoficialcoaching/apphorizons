import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Search, PlusCircle, ScanLine, Zap, Flame, Droplet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getFoods, createFood } from '@/lib/database';
import { getPantryItems } from '@/lib/nutritionLogic';
import { toast } from '@/components/ui/use-toast';

const FoodSearchModal = ({ onClose, onSelectFood }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedFood, setSelectedFood] = useState(null);
    const [grams, setGrams] = useState(100);
    const [view, setView] = useState('search');
    
    // Fixed: Properly merge both food databases
    const [allFoods, setAllFoods] = useState([]);

    useEffect(() => {
        try {
            const local = getFoods();
            const pantry = getPantryItems();
            
            // Merge and normalize food data
            const merged = [...local, ...pantry].map(food => ({
                id: food.id,
                name: food.name,
                brand: food.brand || 'Genérico',
                kcal_100g: food.kcal_100g || food.k || 0,
                p_100g: food.p_100g || food.p || 0,
                c_100g: food.c_100g || food.c || 0,
                g_100g: food.g_100g || food.f || 0,
                tags: food.tags || [],
                category: food.category || 'other'
            }));
            
            setAllFoods(merged);
        } catch (error) {
            console.error("Error loading foods:", error);
            setAllFoods([]);
        }
    }, []);

    const filteredFoods = allFoods.filter(food =>
        food.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (food.tags && food.tags.some(t => t.includes(searchTerm.toLowerCase())))
    ).slice(0, 50);

    const handleSelect = (food) => {
        setSelectedFood(food);
        setView('confirm');
    };

    const handleConfirm = () => {
        onSelectFood(selectedFood, grams);
    };

    const quickFilters = [
        { label: 'Proteína', icon: Zap, color: 'text-blue-400', term: 'protein' },
        { label: 'Carbos', icon: Flame, color: 'text-orange-400', term: 'carbs' },
        { label: 'Grasas', icon: Droplet, color: 'text-yellow-400', term: 'fat' },
    ];

    return (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-[60] flex flex-col sm:items-center sm:justify-center p-4">
            <motion.div 
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="w-full max-w-lg bg-[#0F1115] border border-white/10 rounded-3xl overflow-hidden flex flex-col max-h-[90vh] shadow-2xl"
            >
                {/* Header */}
                <div className="p-4 border-b border-white/5 flex justify-between items-center bg-white/[0.02]">
                    <h2 className="text-lg font-bold text-white">Añadir Alimento</h2>
                    <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full hover:bg-white/10">
                        <X className="w-5 h-5" />
                    </Button>
                </div>

                {view === 'search' ? (
                    <>
                        <div className="p-4 space-y-4">
                            <div className="relative">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                                <input
                                    autoFocus
                                    type="text"
                                    placeholder="Buscar (ej. Pollo, Arroz, Avena...)"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="w-full bg-black/40 border border-white/10 rounded-xl py-4 pl-12 pr-4 text-white placeholder:text-gray-600 focus:outline-none focus:border-[var(--neon-yellow)] focus:ring-1 focus:ring-[var(--neon-yellow)] transition-all"
                                />
                            </div>

                            {/* Quick Tags */}
                            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                                {quickFilters.map(f => (
                                    <button 
                                        key={f.label}
                                        onClick={() => setSearchTerm(f.term === 'protein' ? 'pollo' : f.term === 'carbs' ? 'arroz' : 'aguacate')}
                                        className="flex items-center gap-2 px-3 py-2 bg-white/5 rounded-lg border border-white/5 hover:bg-white/10 transition-colors whitespace-nowrap"
                                    >
                                        <f.icon className={`w-3.5 h-3.5 ${f.color}`} />
                                        <span className="text-xs font-bold text-gray-300">{f.label}</span>
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="flex-1 overflow-y-auto">
                            {filteredFoods.map(food => (
                                <button 
                                    key={food.id}
                                    onClick={() => handleSelect(food)}
                                    className="w-full flex items-center justify-between p-4 hover:bg-white/5 border-b border-white/5 transition-colors group text-left"
                                >
                                    <div>
                                        <p className="font-bold text-white group-hover:text-[var(--neon-yellow)] transition-colors">{food.name}</p>
                                        <p className="text-xs text-gray-500 font-medium mt-0.5 flex gap-2">
                                            <span>{Math.round(food.kcal_100g)} kcal</span>
                                            <span className="text-blue-400">P:{food.p_100g}</span>
                                            <span className="text-orange-400">C:{food.c_100g}</span>
                                            <span className="text-yellow-400">G:{food.g_100g}</span>
                                        </p>
                                    </div>
                                    <PlusCircle className="w-5 h-5 text-gray-600 group-hover:text-[var(--neon-yellow)]" />
                                </button>
                            ))}
                            {filteredFoods.length === 0 && (
                                <div className="p-8 text-center text-gray-500 text-sm">
                                    No se encontraron resultados.
                                </div>
                            )}
                        </div>
                    </>
                ) : (
                    // CONFIRM VIEW
                    <div className="p-6 flex flex-col h-full">
                        <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6">
                            <div className="w-24 h-24 rounded-full bg-[var(--neon-yellow)]/10 flex items-center justify-center border border-[var(--neon-yellow)]/20 mb-4">
                                <span className="text-4xl">🍽️</span>
                            </div>
                            <div>
                                <h3 className="text-2xl font-black text-white mb-2">{selectedFood.name}</h3>
                                <p className="text-gray-400 text-sm">Información nutricional por 100g</p>
                            </div>

                            <div className="grid grid-cols-4 gap-2 w-full max-w-xs">
                                <div className="bg-white/5 p-2 rounded-lg text-center">
                                    <div className="text-[10px] uppercase text-gray-500">Kcal</div>
                                    <div className="font-bold text-white">{selectedFood.kcal_100g}</div>
                                </div>
                                <div className="bg-blue-500/10 p-2 rounded-lg text-center">
                                    <div className="text-[10px] uppercase text-blue-300">Prot</div>
                                    <div className="font-bold text-blue-400">{selectedFood.p_100g}</div>
                                </div>
                                <div className="bg-orange-500/10 p-2 rounded-lg text-center">
                                    <div className="text-[10px] uppercase text-orange-300">Carb</div>
                                    <div className="font-bold text-orange-400">{selectedFood.c_100g}</div>
                                </div>
                                <div className="bg-yellow-500/10 p-2 rounded-lg text-center">
                                    <div className="text-[10px] uppercase text-yellow-300">Grasa</div>
                                    <div className="font-bold text-yellow-400">{selectedFood.g_100g}</div>
                                </div>
                            </div>

                            <div className="w-full max-w-xs bg-white/5 p-4 rounded-xl border border-white/10">
                                <div className="flex justify-between mb-2">
                                    <label className="text-xs font-bold uppercase text-gray-400">Cantidad (gramos)</label>
                                    <span className="text-xs font-bold text-[var(--neon-yellow)]">{grams}g</span>
                                </div>
                                <input 
                                    type="range" 
                                    min="10" 
                                    max="500" 
                                    step="5"
                                    value={grams}
                                    onChange={(e) => setGrams(parseInt(e.target.value))}
                                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-[var(--neon-yellow)]"
                                />
                                <div className="flex justify-between mt-4">
                                    <button onClick={() => setGrams(Math.max(0, grams - 10))} className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20">-</button>
                                    <input 
                                        type="number" 
                                        value={grams} 
                                        onChange={(e) => setGrams(parseInt(e.target.value) || 0)}
                                        className="bg-transparent text-center font-bold text-xl w-20 border-b border-white/20 focus:outline-none focus:border-[var(--neon-yellow)]"
                                    />
                                    <button onClick={() => setGrams(grams + 10)} className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20">+</button>
                                </div>
                            </div>
                        </div>

                        <div className="flex gap-3 mt-6">
                            <Button variant="ghost" onClick={() => setView('search')} className="flex-1">Atrás</Button>
                            <Button onClick={handleConfirm} className="flex-[2] btn-primary">Añadir al Diario</Button>
                        </div>
                    </div>
                )}
            </motion.div>
        </div>
    );
};

export default FoodSearchModal;