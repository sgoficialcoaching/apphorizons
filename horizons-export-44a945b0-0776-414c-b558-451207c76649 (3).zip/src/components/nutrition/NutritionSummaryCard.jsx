import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Edit3, Settings2, Flame } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { CircularProgressbarWithChildren, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

const NutritionSummaryCard = ({ totals, targets, profile, onAdjustClick }) => {
    
    // Fixed: Comprehensive null checks and number conversion
    const targetCalories = Number(targets?.calories) || 2500;
    const targetProtein = Number(targets?.protein) || 180;
    const targetCarbs = Number(targets?.carbs) || 300;
    const targetFat = Number(targets?.fat) || 80;

    const currentKcal = Number(totals?.kcal) || 0;
    const currentProtein = Number(totals?.protein) || 0;
    const currentCarbs = Number(totals?.carbs) || 0;
    const currentFat = Number(totals?.fat) || 0;

    // Calculate main percentage
    let rawPercentage = 0;
    if (targetCalories > 0) {
        rawPercentage = (currentKcal / targetCalories) * 100;
    }
    
    const percentage = Math.min(100, Math.max(0, rawPercentage));
    
    const isSurplus = profile?.objetivo === 'gain';
    const isOverLimit = currentKcal > targetCalories;

    // Determine color based on status
    let pathColor = '#3b82f6';
    if (isSurplus) pathColor = '#22c55e';
    if (isOverLimit && !isSurplus) pathColor = '#ef4444';
    if (isOverLimit && isSurplus) pathColor = '#22c55e';

    // Macro Percentages
    const pPerc = targetProtein > 0 ? Math.min(100, (currentProtein / targetProtein) * 100) : 0;
    const cPerc = targetCarbs > 0 ? Math.min(100, (currentCarbs / targetCarbs) * 100) : 0;
    const fPerc = targetFat > 0 ? Math.min(100, (currentFat / targetFat) * 100) : 0;
    
    const MacroBadge = ({ label, current, target, colorClass, bgClass, barColor, percentage }) => (
        <div className={`flex flex-col items-center justify-center px-2 py-1.5 rounded-lg ${bgClass} border border-white/5 min-w-[70px] relative overflow-hidden`}>
            <span className={`text-[9px] font-black uppercase tracking-wider ${colorClass} z-10`}>{label}</span>
            <span className="text-[10px] font-bold text-white leading-none mt-1 mb-1 z-10">
                {Math.round(current)}<span className="opacity-50 text-[8px]">/{target}g</span>
            </span>
            <div className="absolute bottom-0 left-0 h-1 bg-black/20 w-full">
                <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${percentage}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className={`h-full ${barColor}`}
                />
            </div>
        </div>
    );

    return (
        <div className="bg-[#101114] rounded-[32px] p-4 md:p-6 border border-white/5 relative overflow-hidden shadow-2xl">
            {/* Header */}
            <div className="flex justify-between items-start mb-4 md:mb-6">
                 <div className="flex items-center gap-2">
                    <span className="flex items-center justify-center w-8 h-8 rounded-full bg-orange-500/10 text-orange-500">
                        <Flame className="w-4 h-4 fill-orange-500" />
                    </span>
                    <span className="text-xs font-bold text-gray-400 uppercase tracking-widest hidden md:inline">Resumen Diario</span>
                 </div>
                 
                 <div className="text-center">
                    <div className="flex items-center gap-2 justify-center bg-white/5 px-3 py-1 rounded-full border border-white/5">
                        <span className={`text-[10px] font-black uppercase tracking-widest ${isSurplus ? 'text-green-400' : 'text-blue-400'}`}>
                            {profile?.objetivo || 'MANT'}
                        </span>
                    </div>
                 </div>

                 <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-white" onClick={onAdjustClick}>
                     <Settings2 className="w-4 h-4" />
                 </Button>
            </div>

            <div className="flex flex-col items-center relative z-10">
                {/* Fixed: Circular Progress with proper animation key */}
                <div className="w-48 h-48 md:w-64 md:h-64 relative mb-6 md:mb-8">
                     <CircularProgressbarWithChildren
                        key={`progress-${currentKcal}-${targetCalories}`}
                        value={percentage}
                        strokeWidth={6}
                        styles={buildStyles({
                            pathColor: pathColor,
                            trailColor: 'rgba(255,255,255,0.05)',
                            strokeLinecap: 'round',
                            pathTransitionDuration: 0.8 
                        })}
                     >
                        <div className="flex flex-col items-center justify-center text-center mt-[-10px]">
                            {/* Fixed: Number animation with proper exit/enter */}
                            <AnimatePresence mode="wait">
                                <motion.div
                                    key={`kcal-${currentKcal}`}
                                    initial={{ scale: 0.8, opacity: 0 }}
                                    animate={{ scale: 1, opacity: 1 }}
                                    exit={{ scale: 1.2, opacity: 0 }}
                                    transition={{ type: "spring", stiffness: 200, damping: 15 }}
                                    className="flex flex-col items-center"
                                >
                                    <span className="text-4xl md:text-5xl font-black tracking-tighter text-white drop-shadow-2xl tabular-nums">
                                        {Math.round(currentKcal)}
                                    </span>
                                </motion.div>
                            </AnimatePresence>
                            
                            <span className="text-xs font-bold text-gray-500 mt-1 uppercase tracking-wider">
                                de {targetCalories} Kcal
                            </span>
                            
                            {/* Inner Macros Row */}
                            <div className="flex gap-2 mt-4 md:mt-6">
                                <MacroBadge 
                                    label="PRO" 
                                    current={currentProtein} 
                                    target={targetProtein} 
                                    colorClass="text-blue-400" 
                                    bgClass="bg-blue-500/10" 
                                    barColor="bg-blue-500"
                                    percentage={pPerc}
                                />
                                <MacroBadge 
                                    label="CARB" 
                                    current={currentCarbs} 
                                    target={targetCarbs} 
                                    colorClass="text-orange-400" 
                                    bgClass="bg-orange-500/10" 
                                    barColor="bg-orange-500"
                                    percentage={cPerc}
                                />
                                <MacroBadge 
                                    label="FAT" 
                                    current={currentFat} 
                                    target={targetFat} 
                                    colorClass="text-yellow-400" 
                                    bgClass="bg-yellow-400/10" 
                                    barColor="bg-yellow-400"
                                    percentage={fPerc}
                                />
                            </div>
                        </div>
                     </CircularProgressbarWithChildren>
                     
                     {/* Decorative glow */}
                     <motion.div 
                        animate={{ 
                            backgroundColor: pathColor,
                            opacity: percentage > 0 ? 0.15 : 0 
                        }}
                        transition={{ duration: 1 }}
                        className="absolute inset-0 blur-3xl rounded-full -z-10 transform scale-75"
                     />
                </div>

                {/* Adjust Button */}
                <Button 
                    variant="ghost" 
                    onClick={onAdjustClick}
                    className="h-10 px-4 md:px-6 rounded-full text-xs font-bold uppercase tracking-widest text-gray-500 hover:text-white hover:bg-white/5 transition-all"
                >
                    <Edit3 className="w-3 h-3 mr-2" />
                    <span className="hidden md:inline">Editar Objetivos</span>
                    <span className="md:hidden">Editar</span>
                </Button>
            </div>
        </div>
    );
};

export default NutritionSummaryCard;