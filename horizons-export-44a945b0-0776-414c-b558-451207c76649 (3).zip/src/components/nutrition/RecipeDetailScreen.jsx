import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, PlusCircle, Lock, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { SEED_RECIPES, addMeal, addMealItem } from '@/lib/database';
import { checkSubscriptionStatus } from '@/lib/subscription';
import LoadingScreen from '@/components/common/LoadingScreen';
import { toast } from '@/components/ui/use-toast';
import MacroRing from '@/components/nutrition/MacroRing';

const RecipeDetailScreen = () => {
    const { recipeId } = useParams();
    const navigate = useNavigate();
    const { user } = useAuth();

    const [recipe, setRecipe] = useState(null);
    const [loading, setLoading] = useState(true);

    const subscriptionStatus = useMemo(() => user ? checkSubscriptionStatus(user.id) : null, [user]);

    useEffect(() => {
        // Find in SEED_RECIPES from DB (which we ensure is updated)
        const allRecipes = JSON.parse(localStorage.getItem('recipes') || '[]');
        const recipeData = allRecipes.find(r => r.id === recipeId) || SEED_RECIPES.find(r => r.id === recipeId);
        
        if (!recipeData) {
            toast({ variant: 'destructive', title: 'Error', description: 'Receta no encontrada.' });
            navigate('/nutrition');
            return;
        }
        
        if (recipeData.premium && !subscriptionStatus?.isPremium) {
            toast({ variant: 'destructive', title: 'Contenido Bloqueado', description: 'Necesitas una suscripción PRO para ver esta receta.' });
            navigate('/nutrition');
            return;
        }

        setRecipe(recipeData);
        setLoading(false);
    }, [recipeId, navigate, subscriptionStatus]);

    const handleUseToday = () => {
        if (!user || !recipe) return;

        // Pass the recipe's base macros directly to the meal
        addMeal(user.id, {
            nombre: recipe.name,
            dishName: recipe.name,
            isRecipe: true,
            notas: `Receta: ${recipe.name}`,
            fecha: new Date().toISOString(),
            type: 'main',
            kcal: recipe.kcalPerServing,
            protein: recipe.proteinPerServing,
            carbs: recipe.carbsPerServing,
            fat: recipe.fatPerServing
        });

        toast({
            title: '¡Receta añadida!',
            description: `${recipe.name} ha sido añadida a tu diario de hoy.`,
        });
        navigate('/nutrition');
    };

    if (loading || !recipe) {
        return <LoadingScreen />;
    }

    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div>
                <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="mb-2">
                    <ArrowLeft />
                </Button>
                <h2 className="text-3xl font-bold">{recipe.name}</h2>
                {recipe.premium && <p className="text-primary font-semibold flex items-center gap-2"><Zap className="w-4 h-4"/> Receta Premium</p>}
            </div>

            <div className="aspect-video rounded-xl overflow-hidden glass-effect shadow-lg">
                <img-replace alt={recipe.name} className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1540189549336-e6e99c3679fe" />
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <MacroRing label="Calorías" value={recipe.kcalPerServing} target={2500} unit="kcal" isStatic={true} />
                <MacroRing label="Proteínas" value={recipe.proteinPerServing} target={180} unit="g" color="blue" isStatic={true} />
                <MacroRing label="Carbs" value={recipe.carbsPerServing} target={300} unit="g" color="orange" isStatic={true} />
                <MacroRing label="Grasas" value={recipe.fatPerServing} target={80} unit="g" color="yellow" isStatic={true} />
            </div>

            <div className="glass-effect rounded-2xl p-6">
                <h3 className="text-xl font-bold mb-4">Ingredientes (Ejemplo)</h3>
                <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                    <li>200g Pechuga de Pollo</li>
                    <li>150g Arroz Basmati</li>
                    <li>100g Brócoli</li>
                    <li>10ml Aceite de Oliva</li>
                    <li>Especias al gusto</li>
                </ul>
            </div>
            
            <div className="glass-effect rounded-2xl p-6">
                <h3 className="text-xl font-bold mb-4">Preparación (Ejemplo)</h3>
                <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
                    <li>Cocinar el arroz según las instrucciones.</li>
                    <li>Sazonar y cocinar la pechuga de pollo a la plancha.</li>
                    <li>Cocer el brócoli al vapor.</li>
                    <li>Mezclar todo en un bol y añadir el aceite de oliva.</li>
                </ol>
            </div>

            <Button onClick={handleUseToday} className="w-full btn-primary shadow-lg shadow-primary/20 py-6 text-lg">
                <PlusCircle className="w-6 h-6 mr-3" />
                Usar Receta Hoy
            </Button>
        </motion.div>
    );
};

export default RecipeDetailScreen;