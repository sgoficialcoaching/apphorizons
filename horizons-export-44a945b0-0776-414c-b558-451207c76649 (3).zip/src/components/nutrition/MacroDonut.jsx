import React from 'react';
import { motion } from 'framer-motion';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

const MacroDonut = ({ analysis }) => {
    if (!analysis) return null;

    const { p_g, c_g, g_g, kcal_est } = analysis;
    const p_kcal = p_g * 4;
    const c_kcal = c_g * 4;
    const g_kcal = g_g * 9;
    const total_kcal_from_macros = p_kcal + c_kcal + g_kcal;

    const data = [
        { name: 'Proteínas', value: p_kcal, grams: p_g, fill: '#3b82f6' },
        { name: 'Carbs', value: c_kcal, grams: c_g, fill: '#f97316' },
        { name: 'Grasas', value: g_kcal, grams: g_g, fill: '#f59e0b' },
    ];

    const CustomTooltip = ({ active, payload }) => {
        if (active && payload && payload.length) {
            const percent = ((payload[0].value / total_kcal_from_macros) * 100).toFixed(0);
            return (
                <div className="p-2 bg-secondary text-foreground rounded-lg shadow-lg">
                    <p className="font-bold">{`${payload[0].name}: ${payload[0].payload.grams.toFixed(1)}g`}</p>
                    <p className="text-sm text-muted-foreground">{`${percent}% de las calorías`}</p>
                </div>
            );
        }
        return null;
    };

    return (
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="glass-effect rounded-2xl p-6 space-y-4">
            <h3 className="text-xl font-bold text-center">Estimación Nutricional (IA)</h3>
            <div className="relative w-full h-64">
                <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie
                            data={data}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                            cornerRadius={8}
                        >
                            {data.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.fill} />
                            ))}
                        </Pie>
                        <Tooltip content={<CustomTooltip />} />
                    </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                    <span className="text-4xl font-bold gradient-text">{Math.round(kcal_est)}</span>
                    <span className="text-sm font-medium text-muted-foreground">KCAL (EST.)</span>
                </div>
            </div>
            <div className="grid grid-cols-3 gap-4 text-center">
                {data.map(item => (
                    <div key={item.name}>
                        <p className="font-bold text-lg" style={{ color: item.fill }}>{Math.round(item.grams)}g</p>
                        <p className="text-sm font-medium text-muted-foreground">{item.name}</p>
                    </div>
                ))}
            </div>
            {analysis.items && analysis.items.length > 0 && (
                <div>
                    <h4 className="font-semibold mb-2">Alimentos Detectados:</h4>
                    <div className="space-y-2">
                        {analysis.items.map((item, index) => (
                            <div key={index} className="flex justify-between p-2 bg-secondary/50 rounded-lg text-sm">
                                <span>{item.name}</span>
                                <span className="font-semibold">{item.qty}{item.unit}</span>
                            </div>
                        ))}
                    </div>
                </div>
            )}
             <p className="text-xs text-center text-muted-foreground pt-2">La estimación es aproximada. Ajusta los valores si es necesario.</p>
        </motion.div>
    );
};

export default MacroDonut;