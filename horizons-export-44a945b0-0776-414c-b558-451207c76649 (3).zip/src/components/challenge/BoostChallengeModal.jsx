import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { X, Award, Sparkles, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { startBoostChallenge } from '@/lib/database';
import { toast } from '@/components/ui/use-toast';

const BoostChallengeModal = ({ onClose }) => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const handleStartChallenge = () => {
    if (user) {
      // 1. Persist the change
      startBoostChallenge(user.id, null);
      
      // 2. Notify other components (like BoostWorkoutProgram) to refresh immediately
      window.dispatchEvent(new Event('boost_challenge_updated'));
      
      toast({
        title: "¡Reto Aceptado!",
        description: "Tu programa de 12 semanas ha comenzado.",
        variant: "default",
      });

      // 3. Close modal
      onClose();
      
      // 4. Navigate to refresh view if needed
      navigate('/boost');
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 50 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 50 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          className="bg-card border border-white/10 rounded-2xl p-5 max-w-sm w-full relative shadow-2xl overflow-hidden"
        >
           {/* Background decorative elements */}
           <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[var(--neon-yellow)] to-transparent opacity-50" />
           
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="absolute top-2 right-2 h-8 w-8 text-muted-foreground hover:text-foreground z-10"
          >
            <X className="w-4 h-4" />
          </Button>

          <div className="text-center pt-2">
            <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br from-[var(--neon-yellow)] to-amber-600 flex items-center justify-center shadow-[0_0_15px_rgba(255,214,0,0.3)]">
              <Award className="w-6 h-6 text-black fill-black/20" />
            </div>
            
            <h2 className="text-xl font-black italic uppercase mb-1 tracking-wide text-white">
              ¡Reto Boost Activado!
            </h2>
            
            <p className="text-xs text-muted-foreground mb-4 px-2 leading-relaxed">
              Estás a punto de desbloquear el <span className="text-[var(--neon-yellow)]">programa definitivo</span> de 12 semanas.
            </p>
          </div>

          <div className="space-y-2 mb-5 text-xs text-left p-3 bg-white/5 rounded-xl border border-white/5">
            <p className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-[var(--neon-yellow)]" />
                <span>Plan de entrenamiento de élite.</span>
            </p>
            <p className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-[var(--neon-yellow)]" />
                <span>Gana <span className="font-bold text-white">500 Boosties</span> al finalizar.</span>
            </p>
            <p className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-[var(--neon-yellow)]" />
                <span>Consigue el <span className="font-bold text-white">Rango Plata</span>.</span>
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Button onClick={onClose} variant="outline" className="h-10 text-xs font-semibold hover:bg-white/5 border-white/10">
              Cancelar
            </Button>
            <Button onClick={handleStartChallenge} className="btn-primary h-10 text-xs font-bold uppercase tracking-wide">
              ¡Aceptar Reto!
            </Button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default BoostChallengeModal;