import React from 'react';
import { motion } from 'framer-motion';
import { Award, Target, Calendar, BarChart } from 'lucide-react';

const ProgressBar = ({ label, value, color }) => (
    <div className="space-y-1.5">
        <div className="flex justify-between items-center text-xs">
            <span className="font-semibold">{label}</span>
            <span className={`font-bold ${color}`}>{Math.round(value)}%</span>
        </div>
        <div className="w-full bg-secondary h-2.5 rounded-full overflow-hidden">
            <motion.div
                className={`h-full rounded-full ${color.replace('text-', 'bg-')}`}
                initial={{ width: 0 }}
                animate={{ width: `${value}%` }}
                transition={{ duration: 1, ease: 'easeOut', delay: 0.2 }}
            />
        </div>
    </div>
);

const BoostChallengeProgress = ({ challengeStatus, title }) => {
    const { progress, workoutsCompleted, totalWorkouts } = challengeStatus;

    const progressItems = [
        { label: 'Tiempo', value: progress.time, icon: Calendar, color: 'text-blue-400' },
        { label: 'Entrenamientos', value: progress.workouts, icon: Target, color: 'text-green-400', subtext: `${workoutsCompleted} / ${totalWorkouts}` },
        { label: 'Adherencia', value: progress.adherence, icon: BarChart, color: 'text-amber-400' }
    ];

    return (
        <motion.div 
            className="glass-effect rounded-2xl p-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
        >
            <h3 className="text-2xl font-bold flex items-center gap-3 mb-4">
                <Award className="text-primary" />
                {title}
            </h3>
            <div className="space-y-4">
                {progressItems.map((item, index) => (
                    <motion.div
                        key={item.label}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.1 * index }}
                    >
                        <ProgressBar label={item.label} value={item.value} color={item.color} />
                        {item.subtext && <p className="text-right text-xs text-muted-foreground mt-1">{item.subtext}</p>}
                    </motion.div>
                ))}
            </div>
        </motion.div>
    );
};

export default BoostChallengeProgress;