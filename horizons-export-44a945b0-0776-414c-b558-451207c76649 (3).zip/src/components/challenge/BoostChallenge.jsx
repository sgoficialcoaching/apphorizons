import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Award, Camera, Check, Upload, X } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { startBoostChallenge, completeBoostChallenge } from '@/lib/database';
import BoostChallengeProgress from './BoostChallengeProgress';
import LoadingScreen from '@/components/common/LoadingScreen';

const BoostChallenge = ({ userId, challengeStatus, onUpdate }) => {
    const [beforeImage, setBeforeImage] = useState(null);
    const [afterImage, setAfterImage] = useState(null);
    const [showCamera, setShowCamera] = useState(null); // 'before' or 'after'

    const handleStart = () => {
        if (!beforeImage) {
            toast({ variant: 'destructive', title: '¡Foto Requerida!', description: 'Sube tu foto de "Antes" para empezar el reto.' });
            return;
        }
        startBoostChallenge(userId, 'simulated_before_image_url');
        onUpdate();
    };

    const handleComplete = () => {
        if (!afterImage) {
            toast({ variant: 'destructive', title: '¡Foto Requerida!', description: '¡Sube tu foto de "Después" para reclamar tus premios!' });
            return;
        }
        completeBoostChallenge(userId, 'simulated_after_image_url');
        onUpdate();
    };

    const handleImageUpload = (type, file) => {
        if (type === 'before') setBeforeImage(file);
        if (type === 'after') setAfterImage(file);
    };

    const CameraView = ({ type }) => (
        <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="absolute inset-0 bg-background z-20 flex flex-col items-center justify-center p-4"
        >
            <h3 className="text-2xl font-bold mb-2">Cámara Simulada</h3>
            <p className="text-muted-foreground mb-4 text-center">En una app real, aquí se activaría tu cámara.</p>
            <div className="w-full h-64 bg-secondary rounded-lg flex items-center justify-center mb-4">
                <Camera className="w-16 h-16 text-muted-foreground" />
            </div>
            <Button onClick={() => { handleImageUpload(type, 'simulated_image_file'); setShowCamera(null); }}>
                <Check className="mr-2 h-4 w-4" /> Simular Captura
            </Button>
            <Button variant="ghost" size="icon" className="absolute top-2 right-2" onClick={() => setShowCamera(null)}>
                <X className="h-4 w-4" />
            </Button>
        </motion.div>
    );

    const ImageUploader = ({ type, image, onUpload }) => (
        <div className="w-full text-center">
            <h4 className="font-bold text-lg mb-2">Foto de "{type === 'before' ? 'Antes' : 'Después'}"</h4>
            <div className="relative w-40 h-52 mx-auto bg-secondary rounded-lg flex items-center justify-center overflow-hidden">
                {image ? (
                    <div className="w-full h-full flex items-center justify-center bg-green-500/20 text-green-400">
                        <Check className="w-16 h-16" />
                    </div>
                ) : (
                    <Camera className="w-12 h-12 text-muted-foreground" />
                )}
            </div>
            <Button onClick={() => setShowCamera(type)} className="mt-3 w-full">
                <Upload className="mr-2 h-4 w-4" /> {image ? 'Cambiar Foto' : 'Subir Foto'}
            </Button>
        </div>
    );
    
    if (showCamera) return <CameraView type={showCamera} />;

    if (!challengeStatus) {
        return <LoadingScreen />;
    }

    if (challengeStatus.isCompleted) {
        return (
            <div className="text-center p-6 glass-effect rounded-2xl">
                <Award className="w-20 h-20 text-amber-400 mx-auto mb-4 animate-pulse" />
                <h2 className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 to-primary">¡RETO COMPLETADO!</h2>
                <p className="text-muted-foreground mt-2">Has demostrado una dedicación increíble. ¡Disfruta de tus 500 Boosties y tu nuevo Rango Plata!</p>
                <div className="flex justify-around mt-6 gap-4">
                     <div className="text-center">
                        <p className="font-bold text-lg">Foto "Antes"</p>
                        <div className="w-32 h-40 bg-secondary rounded-lg flex items-center justify-center"><Check className="text-green-500"/></div>
                    </div>
                     <div className="text-center">
                        <p className="font-bold text-lg">Foto "Después"</p>
                        <div className="w-32 h-40 bg-secondary rounded-lg flex items-center justify-center"><Check className="text-green-500"/></div>
                    </div>
                </div>
            </div>
        );
    }

    if (challengeStatus.isActive) {
        return (
            <div>
                <BoostChallengeProgress challengeStatus={challengeStatus} title="Tu Progreso en el Reto" />

                <div className="mt-8 text-center p-6 glass-effect rounded-2xl">
                    <h3 className="text-2xl font-bold">¡Estás en la semana {challengeStatus.currentWeek} de 12!</h3>
                    <p className="text-muted-foreground mt-2 mb-6">Sigue así. Cuando terminen las 12 semanas, sube tu foto de "Después" para completar el reto.</p>
                    <ImageUploader type="after" image={afterImage} onUpload={(file) => handleImageUpload('after', file)} />
                    <Button onClick={handleComplete} disabled={!afterImage || challengeStatus.progress.time < 100} className="w-full mt-4 btn-primary">
                        <Award className="mr-2 h-4 w-4" /> Completar Reto y Reclamar Premios
                    </Button>
                     {challengeStatus.progress.time < 100 && (
                        <p className="text-xs text-muted-foreground mt-2">El botón se activará al completar el 100% del tiempo del reto.</p>
                     )}
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-3xl font-bold flex items-center gap-3"><Award className="text-primary" /> Reto Boost de 12 Semanas</h2>
                <p className="text-muted-foreground">La transformación definitiva. Completa el reto y gana 500 Boosties y el Rango Plata.</p>
            </div>
            <div className="glass-effect p-6 rounded-2xl">
                <ImageUploader type="before" image={beforeImage} onUpload={(file) => handleImageUpload('before', file)} />
                <Button onClick={handleStart} disabled={!beforeImage} className="w-full mt-6 btn-primary">
                    Comenzar mi Transformación
                </Button>
            </div>
        </div>
    );
};

export default BoostChallenge;