import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, Droplets, Zap, Activity, Dumbbell, Info, Calculator, Check, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { upsertNutritionProfile, deleteMealsForDate, addMeal, addMealItem } from '@/lib/database';
import { calculateDailyTargets, generateDynamicPlans, calculateBMI, recommendPlanType } from '@/lib/nutritionLogic';

const NutritionSettings = ({ user, profile, onBack }) => {
    const [formData, setFormData] = useState({
        peso_kg: profile?.peso_kg || 77,
        altura_cm: profile?.altura_cm || 183,
        edad: profile?.edad || 26,
        sexo: profile?.sexo || 'male',
        factor_actividad: profile?.factor_actividad || 'active',
        objetivo: profile?.objetivo || 'gain',
    });
    const [isSaving, setIsSaving] = useState(false);
    const [calculatedTargets, setCalculatedTargets] = useState(null);
    const [calculatedBMI, setCalculatedBMI] = useState(null);

    const handleChange = (e) => {
        const { name, value, type } = e.target;
        setFormData({ ...formData, [name]: type === 'number' ? parseFloat(value) : value });
    };

    const handleCalculateAndGenerate = async () => {
        if (!formData.peso_kg || !formData.altura_cm || !formData.edad) {
             toast({ variant: "destructive", title: "Faltan datos", description: "Por favor completa todos los campos." });
             return;
        }

        setIsSaving(true);
        try {
            // 1. Calculate Metrics
            const targets = calculateDailyTargets(formData);
            const bmi = calculateBMI(formData.peso_kg, formData.altura_cm);
            
            setCalculatedTargets(targets);
            setCalculatedBMI(bmi);

            const newProfileData = { 
                ...profile, 
                ...formData, 
                kcal_objetivo: targets.calories,
                p_gramos: targets.protein,
                c_gramos: targets.carbs,
                g_gramos: targets.fat,
                agua_ml_objetivo: targets.water_ml
            };
            
            // 2. Save Profile FIRST to ensure DB is updated
            const savedProfile = upsertNutritionProfile(user.id, newProfileData);
            
            // 3. Generate Plans & Auto-Assign
            const plans = generateDynamicPlans(savedProfile);
            
            // LOGIC: Recommend specific plan based on BMI + Goal
            const recommendedType = recommendPlanType(bmi, formData.objetivo);
            
            // Find the exact plan object that matches goal + recommendation
            const bestFitPlan = plans.find(p => p.goal === formData.objetivo && p.id.includes(recommendedType));

            if (bestFitPlan) {
                const today = new Date();
                // Clear today's meals
                deleteMealsForDate(user.id, today);
                
                // Apply the recommended plan
                bestFitPlan.meals.forEach(m => {
                    const newMeal = addMeal(user.id, {
                        nombre: m.name,
                        dishName: m.dishName,
                        type: m.type,
                        fecha: today.toISOString()
                    });

                    m.items.forEach(item => {
                        addMealItem(user.id, newMeal.id, {
                            food_id: item.id,
                            gramos: item.grams
                        });
                    });
                });
                
                // Force Update
                window.dispatchEvent(new Event('nutrition_updated'));
                
                toast({ 
                    title: "Plan Asignado Automáticamente", 
                    description: `Basado en tu IMC (${bmi}) y objetivo, hemos asignado el plan: ${bestFitPlan.title}`,
                    className: "bg-[var(--neon-yellow)] text-black border-none font-bold"
                });
            } else {
                 console.warn("Could not find a best fit plan for", formData.objetivo, recommendedType);
            }

            // Save all generated plans for manual selection later if needed
            localStorage.setItem(`generated_plans_${user.id}`, JSON.stringify(plans));

            // Delay back to show success
            setTimeout(() => onBack(true), 2500);

        } catch (error) {
            console.error("Error saving nutrition settings:", error);
            toast({ variant: "destructive", title: "Error", description: "No se pudieron guardar los cambios." });
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6 pb-20">
            <div className="flex items-center gap-4">
                <Button variant="ghost" size="icon" onClick={() => onBack(false)}><ChevronLeft/></Button>
                <div>
                    <h2 className="text-2xl font-black italic uppercase">Configuración <span className="text-[var(--neon-yellow)]">Pro</span></h2>
                    <p className="text-muted-foreground text-xs font-bold uppercase tracking-widest">Calculadora Metabólica Avanzada</p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Inputs Column */}
                <div className="lg:col-span-2 glass-effect rounded-[32px] p-8 space-y-8 border border-white/5 bg-[#121212]">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase text-gray-500 tracking-widest ml-1">Peso (kg)</label>
                            <input type="number" name="peso_kg" value={formData.peso_kg} onChange={handleChange} className="w-full px-5 py-4 bg-black/40 border border-white/10 rounded-2xl focus:ring-1 focus:ring-[var(--neon-yellow)] focus:border-[var(--neon-yellow)] font-black text-2xl text-white outline-none transition-all placeholder:text-gray-700"/>
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase text-gray-500 tracking-widest ml-1">Altura (cm)</label>
                            <input type="number" name="altura_cm" value={formData.altura_cm} onChange={handleChange} className="w-full px-5 py-4 bg-black/40 border border-white/10 rounded-2xl focus:ring-1 focus:ring-[var(--neon-yellow)] focus:border-[var(--neon-yellow)] font-black text-2xl text-white outline-none transition-all placeholder:text-gray-700"/>
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase text-gray-500 tracking-widest ml-1">Edad</label>
                            <input type="number" name="edad" value={formData.edad} onChange={handleChange} className="w-full px-5 py-4 bg-black/40 border border-white/10 rounded-2xl focus:ring-1 focus:ring-[var(--neon-yellow)] focus:border-[var(--neon-yellow)] font-black text-2xl text-white outline-none transition-all placeholder:text-gray-700"/>
                        </div>
                    </div>

                    <div className="space-y-2">
                         <label className="text-[10px] font-black uppercase text-gray-500 tracking-widest ml-1">Sexo Biológico</label>
                         <div className="grid grid-cols-2 gap-4">
                            {['male', 'female'].map(g => (
                                <button
                                    key={g}
                                    onClick={() => setFormData({...formData, sexo: g})}
                                    className={`p-4 rounded-2xl border transition-all font-bold text-sm uppercase tracking-wider ${formData.sexo === g ? 'bg-white text-black border-white' : 'bg-black/20 border-white/5 text-gray-500 hover:bg-white/5'}`}
                                >
                                    {g === 'male' ? 'Masculino' : 'Femenino'}
                                </button>
                            ))}
                         </div>
                    </div>

                    <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-gray-500 tracking-widest ml-1">Nivel de Actividad</label>
                        <div className="grid grid-cols-1 gap-2">
                            {[
                                { val: 'sedentary', label: 'Sedentario', desc: 'Poco o nada de ejercicio' },
                                { val: 'moderate', label: 'Moderado', desc: 'Ejercicio 3-5 días/semana' },
                                { val: 'active', label: 'Activo', desc: 'Ejercicio 6-7 días/semana (Intenso)' },
                                { val: 'veryActive', label: 'Atleta', desc: 'Entrenamiento muy intenso / 2x día' }
                            ].map((opt) => (
                                <div 
                                    key={opt.val}
                                    onClick={() => setFormData({...formData, factor_actividad: opt.val})}
                                    className={`p-4 rounded-2xl border cursor-pointer transition-all flex justify-between items-center group ${formData.factor_actividad === opt.val ? 'bg-[var(--neon-yellow)] border-[var(--neon-yellow)] shadow-[0_0_15px_rgba(255,214,0,0.2)]' : 'bg-black/40 border-white/5 hover:border-white/20'}`}
                                >
                                    <span className={`font-black text-sm uppercase tracking-wider ${formData.factor_actividad === opt.val ? 'text-black' : 'text-white'}`}>{opt.label}</span>
                                    <span className={`text-xs font-medium ${formData.factor_actividad === opt.val ? 'text-black/70' : 'text-gray-500'}`}>{opt.desc}</span>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-gray-500 tracking-widest ml-1">Objetivo Principal</label>
                        <div className="grid grid-cols-3 gap-3">
                            {[
                                { val: 'loss', label: 'Perder Grasa', icon: Activity, note: 'Déficit Calórico' },
                                { val: 'maintenance', label: 'Mantener', icon: Zap, note: 'Normocalórica' },
                                { val: 'gain', label: 'Ganar Músculo', icon: Dumbbell, note: 'Superávit' }
                            ].map(opt => (
                                <div 
                                    key={opt.val}
                                    onClick={() => setFormData({...formData, objetivo: opt.val})}
                                    className={`p-5 rounded-2xl border cursor-pointer transition-all flex flex-col items-center justify-center gap-2 text-center h-32 ${formData.objetivo === opt.val ? 'bg-gradient-to-br from-white to-gray-200 text-black border-white shadow-[0_0_20px_rgba(255,255,255,0.2)]' : 'bg-black/40 border-white/5 hover:border-white/20'}`}
                                >
                                    <opt.icon className={`w-6 h-6 ${formData.objetivo === opt.val ? 'text-black' : 'text-white'}`} />
                                    <span className="text-xs font-black uppercase tracking-widest leading-tight">{opt.label}</span>
                                    <span className={`text-[9px] font-bold ${formData.objetivo === opt.val ? 'text-black/60' : 'text-gray-600'}`}>{opt.note}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Results Preview Column */}
                <div className="space-y-6 flex flex-col">
                    <div className="glass-effect rounded-[32px] p-8 border border-white/5 flex flex-col items-center justify-center text-center flex-1 relative overflow-hidden bg-[#151515]">
                        {calculatedTargets ? (
                            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="space-y-8 relative z-10 w-full">
                                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-500/20 text-green-400 mb-2 border border-green-500/30 shadow-[0_0_30px_rgba(34,197,94,0.3)]">
                                    <Check className="w-8 h-8" />
                                </div>
                                <div>
                                    <h3 className="text-gray-400 text-xs font-bold uppercase tracking-[0.2em] mb-2">Tu Objetivo Diario</h3>
                                    <div className="text-7xl font-black text-white tracking-tighter italic leading-none">
                                        {calculatedTargets.calories}
                                        <span className="text-2xl text-[var(--neon-yellow)] not-italic ml-2">kcal</span>
                                    </div>
                                    <div className="flex items-center justify-center gap-2 mt-4 text-xs font-medium text-gray-500 bg-white/5 py-2 px-4 rounded-full inline-flex">
                                        <Info className="w-3 h-3" />
                                        <span>TDEE Base: {calculatedTargets.tdee} kcal</span>
                                        {calculatedBMI && <span>• IMC: {calculatedBMI}</span>}
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 gap-3 w-full">
                                    <div className="bg-blue-500/10 p-4 rounded-2xl border border-blue-500/20 flex justify-between items-center">
                                        <div className="text-left">
                                            <div className="text-[10px] font-bold uppercase text-blue-200/50 tracking-widest">Proteína</div>
                                            <div className="text-3xl font-black text-blue-400">{calculatedTargets.protein}g</div>
                                        </div>
                                        <div className="h-10 w-1 bg-blue-500/30 rounded-full"></div>
                                    </div>
                                    <div className="bg-orange-500/10 p-4 rounded-2xl border border-orange-500/20 flex justify-between items-center">
                                        <div className="text-left">
                                            <div className="text-[10px] font-bold uppercase text-orange-200/50 tracking-widest">Carbos</div>
                                            <div className="text-3xl font-black text-orange-400">{calculatedTargets.carbs}g</div>
                                        </div>
                                        <div className="h-10 w-1 bg-orange-500/30 rounded-full"></div>
                                    </div>
                                    <div className="bg-yellow-500/10 p-4 rounded-2xl border border-yellow-500/20 flex justify-between items-center">
                                        <div className="text-left">
                                            <div className="text-[10px] font-bold uppercase text-yellow-200/50 tracking-widest">Grasas</div>
                                            <div className="text-3xl font-black text-yellow-400">{calculatedTargets.fat}g</div>
                                        </div>
                                        <div className="h-10 w-1 bg-yellow-500/30 rounded-full"></div>
                                    </div>
                                </div>
                            </motion.div>
                        ) : (
                            <div className="text-gray-600 flex flex-col items-center justify-center h-full">
                                <div className="w-24 h-24 rounded-full bg-white/5 flex items-center justify-center mb-6">
                                    <Calculator className="w-10 h-10 opacity-40" />
                                </div>
                                <h4 className="text-white font-bold text-lg mb-2">Calculadora Inteligente</h4>
                                <p className="text-sm font-medium text-gray-500 max-w-[200px] leading-relaxed">
                                    Introduce tus datos biométricos para generar tu plan nutricional a medida.
                                </p>
                            </div>
                        )}
                    </div>
                    
                    <Button 
                        onClick={handleCalculateAndGenerate} 
                        disabled={isSaving} 
                        className={`w-full py-9 text-lg font-black uppercase tracking-widest shadow-xl transition-all ${isSaving ? 'bg-gray-800 text-gray-500 cursor-not-allowed' : 'bg-[var(--neon-yellow)] text-black hover:scale-[1.02] hover:bg-[#ffe14d] shadow-[0_0_30px_rgba(255,214,0,0.2)]'}`}
                    >
                        {isSaving ? (
                            <span className="flex items-center gap-2">
                                <span className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin"/>
                                Asignando Plan...
                            </span>
                        ) : (
                            <span className="flex items-center gap-2">
                                Calcular y Generar Dieta
                                <ArrowRight className="w-5 h-5" />
                            </span>
                        )}
                    </Button>
                </div>
            </div>
        </motion.div>
    );
};

export default NutritionSettings;