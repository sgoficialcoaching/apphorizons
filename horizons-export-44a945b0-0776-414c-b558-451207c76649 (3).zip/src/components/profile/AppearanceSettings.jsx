import React, { useState, useEffect } from 'react';
import { useTheme } from '@/hooks/useTheme';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { ArrowLeft, Sun, Moon, Sparkles, Monitor, Clock } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const AppearanceSettings = ({ onBack }) => {
  const { settings, updateSettings, loading } = useTheme();
  const [localSettings, setLocalSettings] = useState(settings);

  useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);

  const handleSave = async () => {
    await updateSettings(localSettings);
    toast({
      title: '✅ ¡Ajustes guardados!',
      description: 'Tu nueva apariencia ha sido aplicada.',
    });
    if (onBack) onBack();
  };
  
  const ModeButton = ({ mode, icon: Icon, label }) => (
    <Button
      variant={localSettings.mode === mode ? 'default' : 'outline'}
      className="flex-1 flex flex-col h-24 gap-2"
      onClick={() => setLocalSettings(s => ({...s, mode}))}
    >
      <Icon className="w-6 h-6" />
      <span>{label}</span>
    </Button>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft />
        </Button>
        <div>
          <h2 className="text-2xl font-bold">Apariencia</h2>
          <p className="text-muted-foreground">Personaliza el aspecto de la aplicación.</p>
        </div>
      </div>
      
      <div className="glass-effect p-6 rounded-2xl">
        <Label className="text-lg font-semibold mb-4 block">Modo</Label>
        <div className="flex gap-4 mb-6">
          <ModeButton mode="light" icon={Sun} label="Claro" />
          <ModeButton mode="dark" icon={Moon} label="Oscuro" />
          <ModeButton mode="auto" icon={Sparkles} label="Auto" />
        </div>

        {localSettings.mode === 'auto' && (
          <div className="space-y-4 p-4 bg-secondary rounded-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Monitor className="w-5 h-5 text-primary" />
                <Label htmlFor="follow_system">Seguir tema del sistema</Label>
              </div>
              <Switch
                id="follow_system"
                checked={localSettings.follow_system}
                onCheckedChange={(checked) => setLocalSettings(s => ({...s, follow_system: checked}))}
              />
            </div>
            {!localSettings.follow_system && (
               <div className="space-y-4 pt-4 border-t border-border">
                 <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Clock className="w-5 h-5 text-primary" />
                      <Label>Horario personalizado</Label>
                    </div>
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div>
                        <Label htmlFor="day_start" className="text-sm">Inicio del día</Label>
                        <input type="time" id="day_start" value={`${String(localSettings.day_start_hour).padStart(2,'0')}:00`} onChange={(e) => setLocalSettings(s => ({...s, day_start_hour: parseInt(e.target.value.split(':')[0])}))} className="w-full mt-1 p-2 bg-input rounded-md"/>
                    </div>
                    <div>
                        <Label htmlFor="night_start" className="text-sm">Inicio de la noche</Label>
                        <input type="time" id="night_start" value={`${String(localSettings.night_start_hour).padStart(2,'0')}:00`} onChange={(e) => setLocalSettings(s => ({...s, night_start_hour: parseInt(e.target.value.split(':')[0])}))} className="w-full mt-1 p-2 bg-input rounded-md"/>
                    </div>
                 </div>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="flex justify-end gap-4">
        <Button variant="ghost" onClick={onBack}>Cancelar</Button>
        <Button onClick={handleSave} disabled={loading} className="btn-primary">
          {loading ? 'Guardando...' : 'Guardar Cambios'}
        </Button>
      </div>
    </div>
  );
};

export default AppearanceSettings;