import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, Bell, Clock, MessageSquare, Zap, Apple, Flame, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { getNotificationSettings, updateNotificationSettings } from '@/lib/database';
import { toast } from '@/components/ui/use-toast';

const NotificationSettings = ({ user, onBack }) => {
    const [settings, setSettings] = useState(null);
    const [loading, setLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        const fetchSettings = async () => {
            if (user) {
                setLoading(true);
                const fetchedSettings = await getNotificationSettings(user.id);
                setSettings(fetchedSettings);
                setLoading(false);
            }
        };
        fetchSettings();
    }, [user]);

    const handleUpdate = (key, value) => {
        setSettings(prev => ({ ...prev, [key]: value }));
    };

    const handleTypeUpdate = (type, value) => {
        setSettings(prev => ({
            ...prev,
            types: { ...prev.types, [type]: value }
        }));
    };

    const handleSave = async () => {
        setIsSaving(true);
        await updateNotificationSettings(user.id, settings);
        setIsSaving(false);
        toast({
            title: '✅ Ajustes Guardados',
            description: 'Tus preferencias de notificación han sido actualizadas.',
        });
        onBack();
    };

    if (loading || !settings) {
        return (
            <div className="flex items-center justify-center h-64">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
        );
    }

    const timeSlots = [
        { key: 'morning_hour', label: 'Mañana', icon: Clock },
        { key: 'midday_hour', label: 'Mediodía', icon: Clock },
        { key: 'evening_hour', label: 'Tarde/Noche', icon: Clock },
    ];

    const typeToggles = [
        { key: 'motivation', label: 'Motivación', icon: MessageSquare },
        { key: 'workout', label: 'Entrenamiento', icon: Zap },
        { key: 'nutrition', label: 'Nutrición', icon: Apple },
        { key: 'streaks', label: 'Rachas', icon: Flame },
    ];

    return (
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
            <div className="flex items-center gap-4">
                <Button variant="ghost" size="icon" onClick={onBack}><ChevronLeft /></Button>
                <h2 className="text-2xl font-bold">Ajustes de Notificaciones</h2>
            </div>

            <div className="glass-effect rounded-2xl p-6 space-y-6">
                <div className="flex items-center justify-between">
                    <Label htmlFor="push-enabled" className="flex items-center gap-3">
                        <Bell className="w-5 h-5 text-primary" />
                        <span className="font-semibold text-lg">Activar Notificaciones Push</span>
                    </Label>
                    <Switch
                        id="push-enabled"
                        checked={settings.push_enabled}
                        onCheckedChange={(val) => handleUpdate('push_enabled', val)}
                    />
                </div>
            </div>

            <AnimatePresence>
                {settings.push_enabled && (
                    <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="space-y-6 overflow-hidden"
                    >
                        <div className="glass-effect rounded-2xl p-6">
                            <h3 className="text-xl font-bold mb-4">Horarios de Envío</h3>
                            <div className="space-y-6">
                                {timeSlots.map(slot => (
                                    <div key={slot.key}>
                                        <Label className="flex items-center gap-2 mb-2">
                                            <slot.icon className="w-4 h-4" />
                                            <span>{slot.label} (aprox. {settings[slot.key]}:00h)</span>
                                        </Label>
                                        <Slider
                                            value={[settings[slot.key]]}
                                            onValueChange={(val) => handleUpdate(slot.key, val[0])}
                                            min={slot.key === 'evening_hour' ? 17 : (slot.key === 'midday_hour' ? 12 : 6)}
                                            max={slot.key === 'evening_hour' ? 22 : (slot.key === 'midday_hour' ? 15 : 9)}
                                            step={1}
                                        />
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="glass-effect rounded-2xl p-6">
                            <h3 className="text-xl font-bold mb-4">Tipos de Mensajes</h3>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                {typeToggles.map(toggle => (
                                    <div key={toggle.key} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                                        <Label htmlFor={`type-${toggle.key}`} className="flex items-center gap-2">
                                            <toggle.icon className="w-4 h-4" />
                                            <span>{toggle.label}</span>
                                        </Label>
                                        <Switch
                                            id={`type-${toggle.key}`}
                                            checked={settings.types[toggle.key]}
                                            onCheckedChange={(val) => handleTypeUpdate(toggle.key, val)}
                                        />
                                    </div>
                                ))}
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            <Button onClick={handleSave} disabled={isSaving} className="w-full btn-primary py-6">
                {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isSaving ? 'Guardando...' : 'Guardar Cambios'}
            </Button>
        </motion.div>
    );
};

export default NotificationSettings;