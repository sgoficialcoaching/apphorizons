import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Crown, Download, Shield, CreditCard, Star, User, Palette, Bell, LogOut, ShieldCheck, Apple, Zap, Trophy, Flame } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { exportUserData, getNutritionProfile } from '@/lib/database';
import { getUserProgress, RANKS, getNextRank } from '@/lib/gamification';
import SubscriptionModal from '@/components/subscription/SubscriptionModal';
import NotificationSettings from '@/components/profile/NotificationSettings';
import AppearanceSettings from '@/components/profile/AppearanceSettings';
import NutritionSettings from '@/components/profile/NutritionSettings';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { checkSubscriptionStatus } from '@/lib/subscription';
import { motion } from 'framer-motion';

const ProfileScreen = () => {
  const { user, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [activeScreen, setActiveScreen] = useState('main'); 
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  
  // Gamification State
  const [progress, setProgress] = useState(null);
  const [currentRankData, setCurrentRankData] = useState(RANKS[0]);
  const [nextRankData, setNextRankData] = useState(RANKS[1]);
  
  const [subscriptionStatus, setSubscriptionStatus] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [nutritionProfile, setNutritionProfile] = useState(null);

  useEffect(() => {
    if (user) {
      // Load Gamification Data
      const loadProgress = async () => {
        const p = await getUserProgress(user.id);
        if (p) {
            setProgress(p);
            const rData = RANKS.find(r => r.name === p.rank) || RANKS[0];
            setCurrentRankData(rData);
            setNextRankData(getNextRank(p.xp));
        }
      };
      loadProgress();

      // Load Other Data
      const subStatus = checkSubscriptionStatus(user.id);
      setSubscriptionStatus(subStatus);
      const profile = getNutritionProfile(user.id);
      setNutritionProfile(profile);

      if (user.email === 'dimi.ivelinov.d@gmail.com' || user.email === 'admin@boost.com') {
        setIsAdmin(true);
      }
      
      if (location.state?.screen) {
        setActiveScreen(location.state.screen);
        navigate(location.pathname, { replace: true });
      }
    }
  }, [user, location.state, navigate, location.pathname]);

  const handleBackToMain = (refresh = false) => {
    setActiveScreen('main');
    if (refresh && user) {
        setNutritionProfile(getNutritionProfile(user.id));
    }
  };

  if (!user) return null;

  const handleExportData = () => {
    exportUserData(user.id);
    toast({ title: '✅ ¡Datos exportados!', description: 'Tus datos han sido descargados en formato JSON.' });
  };

  const handleDeleteAccount = () => {
    toast({ title: '🚧 Función no implementada', description: 'La eliminación de cuenta estará disponible pronto.' });
  };
  
  const handleAdminPanel = () => {
    toast({ title: '🚧 Panel de Admin', description: 'Disponible próximamente.' });
  };

  if (activeScreen === 'notifications') return <NotificationSettings user={user} onBack={handleBackToMain} />;
  if (activeScreen === 'appearance') return <AppearanceSettings onBack={handleBackToMain} />;
  if (activeScreen === 'nutrition') return <NutritionSettings user={user} profile={nutritionProfile} onBack={() => handleBackToMain(true)} />;

  const userName = user?.user_metadata?.full_name || user?.email || 'Usuario';
  const userInitial = userName?.charAt(0)?.toUpperCase() || 'U';

  // Calculate XP Progress Bar
  const currentXp = progress?.xp || 0;
  const nextRankXp = nextRankData ? nextRankData.minXp : currentXp;
  const prevRankXp = currentRankData.minXp;
  const xpRange = nextRankXp - prevRankXp;
  const xpGainedInRank = currentXp - prevRankXp;
  const progressPercent = nextRankData ? Math.min(100, Math.max(0, (xpGainedInRank / xpRange) * 100)) : 100;

  return (
    <div className="space-y-6 pb-20">
      <div>
        <h2 className="text-3xl font-bold mb-2">Perfil de Leyenda</h2>
        <p className="text-muted-foreground">Tu progreso, rango y logros.</p>
      </div>

      {/* Gamification Hero Card */}
      <div className="glass-effect rounded-3xl p-6 relative overflow-hidden border border-white/10">
         <div className={`absolute top-0 right-0 w-48 h-48 blur-[80px] rounded-full pointer-events-none opacity-40 ${currentRankData.bg.replace('/20', '')}`} />
         
         <div className="relative z-10 flex flex-col sm:flex-row items-center gap-6">
            {/* Avatar with Rank Border */}
            <div className={`relative w-24 h-24 sm:w-28 sm:h-28 rounded-full border-4 ${currentRankData.border} flex items-center justify-center bg-[#1E1F22] shadow-2xl`}>
                <span className="text-4xl">{currentRankData.icon}</span>
                <div className="absolute -bottom-3 bg-[#1E1F22] px-3 py-1 rounded-full border border-white/10 text-xs font-bold uppercase tracking-wider text-white shadow-lg">
                    {currentRankData.name}
                </div>
            </div>

            <div className="flex-1 text-center sm:text-left w-full">
                <h3 className="text-2xl font-bold text-white mb-1">{userName}</h3>
                <div className="flex flex-wrap justify-center sm:justify-start gap-4 mb-4">
                    <div className="flex items-center gap-1.5 text-gray-300 bg-black/30 px-2 py-1 rounded-lg">
                        <Flame className="w-4 h-4 text-orange-500" />
                        <span className="text-sm font-bold">{progress?.active_days || 0} Días Activos</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-[var(--neon-yellow)] bg-[var(--neon-yellow)]/10 px-2 py-1 rounded-lg border border-[var(--neon-yellow)]/20">
                        <Zap className="w-4 h-4 fill-[var(--neon-yellow)]" />
                        <span className="text-sm font-bold">{progress?.boosties || 0} Boosties</span>
                    </div>
                </div>

                {/* XP Bar */}
                <div className="space-y-1.5">
                    <div className="flex justify-between text-xs font-bold text-gray-400">
                        <span>XP: {currentXp}</span>
                        <span>{nextRankData ? `Siguiente: ${nextRankData.name} (${nextRankData.minXp} XP)` : 'Rango Máximo'}</span>
                    </div>
                    <div className="h-3 w-full bg-black/50 rounded-full overflow-hidden border border-white/5">
                        <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${progressPercent}%` }}
                            transition={{ duration: 1, ease: "easeOut" }}
                            className={`h-full rounded-full ${currentRankData.color.replace('text-', 'bg-')}`}
                        />
                    </div>
                </div>
            </div>
         </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
          <div className="glass-effect p-4 rounded-2xl flex flex-col items-center justify-center text-center">
             <Trophy className="w-8 h-8 text-yellow-500 mb-2" />
             <span className="text-2xl font-bold text-white">{progress?.rank || 'Bronce'}</span>
             <span className="text-xs text-gray-400 uppercase">Rango Actual</span>
          </div>
          <div className="glass-effect p-4 rounded-2xl flex flex-col items-center justify-center text-center">
             <Zap className="w-8 h-8 text-[var(--neon-yellow)] mb-2" />
             <span className="text-2xl font-bold text-white">{progress?.boosties || 0}</span>
             <span className="text-xs text-gray-400 uppercase">Saldo Tienda</span>
          </div>
      </div>

      {/* Admin Panel */}
      {isAdmin && (
        <div className="glass-effect rounded-2xl p-6 bg-primary/10 border border-primary">
            <div className="flex items-center gap-3 mb-4">
                <ShieldCheck className="w-6 h-6 text-primary" />
                <h3 className="text-xl font-bold">Panel de Administrador</h3>
            </div>
            <Button onClick={handleAdminPanel} className="w-full btn-primary">Acceder al Panel</Button>
        </div>
      )}

      {/* Subscription Section */}
      <div className="glass-effect rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
            <CreditCard className="w-6 h-6 text-primary" />
            <h3 className="text-xl font-bold">Suscripción</h3>
        </div>

        {subscriptionStatus?.isPremium ? (
          <div className="space-y-4">
            <div className="p-4 bg-primary/10 rounded-xl border border-primary/20">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-lg">Plan {subscriptionStatus.plan.toUpperCase()}</span>
                <span className="premium-badge">ACTIVO</span>
              </div>
              <p className="text-sm text-muted-foreground">
                {subscriptionStatus.trialEnd && new Date(subscriptionStatus.trialEnd) > new Date()
                  ? `La prueba termina el ${new Date(subscriptionStatus.trialEnd).toLocaleDateString()}`
                  : `Se renueva el ${new Date(subscriptionStatus.currentPeriodEnd).toLocaleDateString()}`
                }
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 bg-secondary rounded-xl border border-border">
              <p className="font-semibold mb-1">Plan Básico</p>
              <p className="text-sm text-muted-foreground">Funciones limitadas</p>
            </div>
            <Button onClick={() => setShowSubscriptionModal(true)} className="w-full btn-primary">
              <Crown className="w-4 h-4 mr-2" /> Mejorar a Premium
            </Button>
          </div>
        )}
      </div>

      {/* Settings Section */}
      <div className="glass-effect rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <Shield className="w-6 h-6 text-green-400" />
          <h3 className="text-xl font-bold">Ajustes</h3>
        </div>

        <div className="space-y-3">
          <Button onClick={() => setActiveScreen('appearance')} variant="outline" className="w-full justify-start btn-secondary">
            <Palette className="w-4 h-4 mr-2" /> Apariencia
          </Button>
          <Button onClick={() => setActiveScreen('nutrition')} variant="outline" className="w-full justify-start btn-secondary">
            <Apple className="w-4 h-4 mr-2" /> Perfil Nutricional
          </Button>
          <Button onClick={() => setActiveScreen('notifications')} variant="outline" className="w-full justify-start btn-secondary">
            <Bell className="w-4 h-4 mr-2" /> Notificaciones
          </Button>
          <Button onClick={handleExportData} variant="outline" className="w-full justify-start btn-secondary">
            <Download className="w-4 h-4 mr-2" /> Exportar Datos
          </Button>
          <Button onClick={signOut} variant="ghost" className="w-full justify-start text-muted-foreground hover:text-red-500">
            <LogOut className="w-4 h-4 mr-2" /> Cerrar Sesión
          </Button>
        </div>
      </div>

      {showSubscriptionModal && <SubscriptionModal onClose={() => setShowSubscriptionModal(false)} />}
    </div>
  );
};

export default ProfileScreen;