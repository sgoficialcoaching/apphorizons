import React from 'react';
import { motion } from 'framer-motion';
import { Flame, GitCommit, HeartPulse } from 'lucide-react';

const StatCard = ({ icon, value, label, color, delay }) => {
    const Icon = icon;
    return (
        <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay, type: 'spring', stiffness: 100 }}
            className="relative flex flex-col items-center justify-center p-4 rounded-xl overflow-hidden glass-effect h-36"
        >
            <div className="relative z-10 flex flex-col items-center text-center">
                <div className={`relative w-16 h-16 flex items-center justify-center`}>
                     <svg className="absolute w-full h-full" viewBox="0 0 100 100">
                        <motion.circle
                            cx="50"
                            cy="50"
                            r="40"
                            strokeWidth="6"
                            className="stroke-secondary"
                            fill="none"
                        />
                        <motion.circle
                            cx="50"
                            cy="50"
                            r="40"
                            strokeWidth="6"
                            className={`stroke-current`}
                            style={{ color }}
                            fill="none"
                            strokeLinecap="round"
                            initial={{ strokeDashoffset: 251.2 }}
                            animate={{ strokeDashoffset: 0 }}
                            transition={{ duration: 1.5, delay: delay + 0.5, ease: 'easeInOut' }}
                            strokeDasharray="251.2"
                        />
                    </svg>
                    <Icon className="w-6 h-6" style={{ color }} />
                </div>
                <motion.p 
                    className="text-2xl font-bold mt-2"
                    initial={{ y: 10, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ duration: 0.5, delay: delay + 1 }}
                >
                    {value}
                </motion.p>
                <p className="text-xs text-muted-foreground">{label}</p>
            </div>
            
            <motion.div 
                className="absolute inset-0 w-full h-full opacity-10"
                style={{ background: `radial-gradient(circle at center, ${color} 0%, transparent 70%)` }}
                initial={{ scale: 0 }}
                animate={{ scale: 3 }}
                transition={{ duration: 2, delay, repeat: Infinity, repeatType: 'reverse' }}
            />
        </motion.div>
    );
};

const VitalStatsWidget = ({ streakData, nutritionData }) => {
    return (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <StatCard
                icon={Flame}
                value={streakData.current_streak}
                label="Días de Racha"
                color="hsl(var(--color-orange))"
                delay={0}
            />
            <StatCard
                icon={GitCommit}
                value={streakData.best_streak}
                label="Mejor Racha"
                color="hsl(var(--color-green))"
                delay={0.2}
            />
            <StatCard
                icon={HeartPulse}
                value={Math.round(nutritionData.totals.kcal)}
                label="Kcal Hoy"
                color="hsl(var(--color-blue))"
                delay={0.4}
            />
        </div>
    );
};

export default VitalStatsWidget;