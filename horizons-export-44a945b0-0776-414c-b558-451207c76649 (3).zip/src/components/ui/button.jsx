import { cn } from '@/lib/utils';
import { Slot } from '@radix-ui/react-slot';
import { cva } from 'class-variance-authority';
import React from 'react';

const buttonVariants = cva(
	'inline-flex items-center justify-center rounded-full text-sm font-black uppercase tracking-wider transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 active:scale-95 duration-300 relative overflow-hidden',
	{
		variants: {
			variant: {
				default: 'btn-primary', // Uses CSS defined class for complex effects
				destructive:
          'bg-red-600 text-white hover:bg-red-700 shadow-[0_0_15px_rgba(220,38,38,0.4)] border border-red-500/20',
				outline:
          'bg-transparent text-[#FFD600] border-2 border-[#FFD600] hover:bg-[#FFD600] hover:text-black shadow-[0_0_10px_rgba(255,214,0,0.1)] hover:shadow-[0_0_20px_rgba(255,214,0,0.4)]',
				secondary:
          'btn-secondary', // Uses CSS defined class
				ghost: 'hover:bg-[#25282C] hover:text-[#FFD600] hover:shadow-lg',
				link: 'text-[#FFD600] underline-offset-4 hover:underline drop-shadow-[0_0_5px_rgba(255,214,0,0.5)]',
        gold: 'bg-gradient-to-br from-[#FFD700] via-[#FDB931] to-[#D4AF37] text-black font-bold shadow-[0_5px_20px_rgba(253,185,49,0.3)] hover:brightness-110 border border-white/20',
			},
			size: {
				default: 'h-14 px-8 py-2', // Taller, chunkier buttons
				sm: 'h-10 rounded-full px-5 text-xs',
				lg: 'h-16 rounded-full px-10 text-base',
				icon: 'h-12 w-12',
			},
		},
		defaultVariants: {
			variant: 'default',
			size: 'default',
		},
	},
);

const Button = React.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	const Comp = asChild ? Slot : 'button';
	return (
		<Comp
			className={cn(buttonVariants({ variant, size, className }))}
			ref={ref}
			{...props}
		/>
	);
});
Button.displayName = 'Button';

export { Button, buttonVariants };