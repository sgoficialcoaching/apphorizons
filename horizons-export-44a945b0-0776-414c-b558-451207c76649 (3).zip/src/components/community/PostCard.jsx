import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Heart, MessageCircle, Bookmark, Copy, MoreHorizontal, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getPostDetails, toggleLike, addComment, copyWorkout, copyMeal } from '@/lib/community';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/components/ui/use-toast';

const PostCard = ({ post, currentUser, onRefresh, isCompact = false }) => {
    const navigate = useNavigate();
    const [details, setDetails] = useState({ likes: [], comments: [] });
    const [showComments, setShowComments] = useState(false);
    const [newComment, setNewComment] = useState('');
    const [isLiking, setIsLiking] = useState(false);

    const users = useMemo(() => {
        try { return JSON.parse(localStorage.getItem('users') || '[]'); }
        catch { return []; }
    }, []);
    const profiles = useMemo(() => {
        try { return JSON.parse(localStorage.getItem('community_profiles') || '{}'); }
        catch { return {}; }
    }, []);
    
    const author = useMemo(() => users.find(u => u.id === post.user_id), [users, post.user_id]);
    const authorProfile = useMemo(() => profiles[post.user_id] || {}, [profiles, post.user_id]);

    const authorName = author?.name || 'Usuario Anónimo';
    const authorAvatar = authorProfile.avatar_url || `https://ui-avatars.com/api/?name=${authorName.charAt(0)}&background=c9a227&color=0e0f11`;

    useEffect(() => {
        try {
            const postDetails = getPostDetails(post.id);
            if (postDetails) {
                setDetails(postDetails);
            }
        } catch (error) {
            console.error("Error loading post details:", error);
        }
    }, [post.id]);

    const isLiked = useMemo(() => details.likes.some(like => like.user_id === currentUser.id), [details.likes, currentUser.id]);

    const handleLike = async (e) => {
        e.stopPropagation();
        if(isLiking || !currentUser) return;
        setIsLiking(true);
        
        toggleLike(post.id, currentUser.id);
        onRefresh();
        
        const optimisticLikes = isLiked 
            ? details.likes.filter(l => l.user_id !== currentUser.id)
            : [...details.likes, { user_id: currentUser.id, post_id: post.id, created_at: new Date().toISOString() }];
        setDetails(prev => ({...prev, likes: optimisticLikes}));

        setIsLiking(false);
    };

    const handleCommentSubmit = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!newComment.trim() || !currentUser) return;
        
        const createdComment = addComment(post.id, currentUser.id, newComment);
        
        setDetails(prev => ({...prev, comments: [...prev.comments, createdComment]}));
        setNewComment('');
        onRefresh();
        toast({ title: 'Comentario añadido' });
    };
    
    const handleCopy = (e) => {
        e.stopPropagation();
        if(post.type === 'workout') {
            copyWorkout(post.workout_id, currentUser.id);
            toast({
                title: "Entrenamiento Copiado",
                description: "El entrenamiento se ha añadido a tu diario.",
            });
        } else if (post.type === 'meal') {
            copyMeal(post.meal_id, currentUser.id);
            toast({
                title: "Comida Copiada",
                description: "La comida se ha añadido a tu diario.",
            });
        }
    };
    
    const renderContent = () => {
        const content = (post.body || '')
            .replace(/#(\w+)/g, '<a href="#" class="text-primary font-semibold">#$1</a>')
            .replace(/@(\w+)/g, '<a href="#" class="text-primary font-semibold">@$1</a>');
        return <p className="text-sm whitespace-pre-wrap" dangerouslySetInnerHTML={{ __html: content }}></p>;
    }
    
    if(!author) {
        return null;
    }

    if (isCompact) {
        return (
            <div className="p-3 rounded-lg hover:bg-secondary cursor-pointer">
                <div className="flex items-start gap-3">
                    <img alt={authorName} className="w-10 h-10 rounded-full object-cover" src={authorAvatar} />
                    <div className="flex-1">
                        <p className="font-bold text-sm">{authorName}</p>
                        <p className="text-sm text-muted-foreground truncate">{post.body}</p>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-effect rounded-2xl p-4 sm:p-6"
        >
            <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate(`/user/${author.id}`)}>
                    <img alt={authorName} className="w-10 h-10 rounded-full object-cover" src={authorAvatar} />
                    <div>
                        <p className="font-bold text-sm">{authorName}</p>
                        <p className="text-xs text-muted-foreground">{new Date(post.created_at).toLocaleString()}</p>
                    </div>
                </div>
                <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); toast({title: "🚧 Próximamente", description: "Más opciones estarán disponibles pronto."})}}><MoreHorizontal className="w-5 h-5" /></Button>
            </div>
            
            <div className="mb-4" onClick={() => navigate(`/post/${post.id}`)}>
                {post.title && <h3 className="font-bold mb-1">{post.title}</h3>}
                {renderContent()}
                {post.type === 'workout' && <div className="mt-2 text-xs p-2 bg-secondary rounded-lg border border-border">💪 Entreno Adjunto</div>}
                {post.type === 'meal' && <div className="mt-2 text-xs p-2 bg-secondary rounded-lg border border-border">🍎 Comida Adjunta</div>}
            </div>

            <div className="flex items-center gap-4 text-muted-foreground border-t border-b border-border py-2">
                <Button variant="ghost" size="sm" onClick={handleLike} className={`flex items-center gap-2 ${isLiked ? 'text-primary' : ''}`}>
                    <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} /> 
                    <span className="text-sm font-semibold">{details.likes.length}</span>
                </Button>
                <Button variant="ghost" size="sm" className="flex items-center gap-2" onClick={(e) => { e.stopPropagation(); setShowComments(!showComments); }}>
                    <MessageCircle className="w-5 h-5" />
                    <span className="text-sm font-semibold">{details.comments.length}</span>
                </Button>
                {(post.type === 'workout' || post.type === 'meal') && (
                    <Button variant="ghost" size="sm" className="flex items-center gap-2" onClick={handleCopy}>
                        <Copy className="w-5 h-5" />
                    </Button>
                )}
                 <Button variant="ghost" size="sm" className="flex items-center gap-2 ml-auto" onClick={(e) => { e.stopPropagation(); toast({title: "🚧 Próximamente"})}}>
                    <Bookmark className="w-5 h-5" />
                </Button>
            </div>

            {showComments && (
                <div className="mt-4 space-y-3">
                    {details.comments.map(comment => {
                         const commentAuthor = users.find(u => u.id === comment.user_id);
                         if (!commentAuthor) return null;
                         const cAuthorName = commentAuthor?.name || 'Usuario';
                         const cAuthorAvatar = profiles[comment.user_id]?.avatar_url || `https://ui-avatars.com/api/?name=${cAuthorName.charAt(0)}&background=c9a227&color=0e0f11`;

                         return (
                            <div key={comment.id} className="flex items-start gap-2 text-sm">
                                <img alt={cAuthorName} className="w-8 h-8 rounded-full object-cover" src={cAuthorAvatar} />
                                <div className="bg-secondary p-2 rounded-lg flex-1">
                                    <p><span className="font-bold cursor-pointer" onClick={(e) => { e.stopPropagation(); navigate(`/user/${commentAuthor.id}`)}}>{cAuthorName}</span> {comment.body}</p>
                                </div>
                            </div>
                         );
                    })}
                    <form onSubmit={handleCommentSubmit} className="flex items-center gap-2 pt-2">
                        <input type="text" value={newComment} onChange={(e) => setNewComment(e.target.value)} onClick={(e) => e.stopPropagation()} placeholder="Añade un comentario..." className="w-full px-3 py-2 bg-input border-border rounded-lg text-sm" />
                        <Button type="submit" size="icon" className="btn-primary flex-shrink-0"><Send className="w-4 h-4"/></Button>
                    </form>
                </div>
            )}
        </motion.div>
    );
};

export default React.memo(PostCard);