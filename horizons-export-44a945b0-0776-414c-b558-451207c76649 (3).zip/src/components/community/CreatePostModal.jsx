import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Globe, Users, Lock, Dumbbell, Apple, Edit3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { createPost } from '@/lib/community';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const CreatePostModal = ({ onClose, onPostCreated, community }) => {
    const { user } = useAuth();
    const [postType, setPostType] = useState('status'); // status, workout, meal
    const [body, setBody] = useState('');
    const [visibility, setVisibility] = useState('public');
    const [isPosting, setIsPosting] = useState(false);
    
    // Mock data for workout/meal selection
    const recentWorkouts = JSON.parse(localStorage.getItem(`workouts_${user.id}`) || '[]').slice(0, 3);
    const recentMeals = JSON.parse(localStorage.getItem(`meals_${user.id}`) || '[]').slice(0, 3);

    const [attachment, setAttachment] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!body.trim() && !attachment) return;
        setIsPosting(true);

        const postData = {
            community,
            type: postType,
            body,
            visibility,
            workout_id: postType === 'workout' ? attachment?.id : null,
            meal_id: postType === 'meal' ? attachment?.id : null,
        };
        
        createPost(user.id, postData);
        
        setIsPosting(false);
        onPostCreated();
    };
    
    const visibilityOptions = [
        { id: 'public', label: 'Público', icon: Globe },
        { id: 'followers', label: 'Seguidores', icon: Users },
        { id: 'private', label: 'Privado', icon: Lock },
    ];
    
    const userName = user?.user_metadata?.full_name || user?.email?.split('@')[0] || 'Usuario';
    const userAvatar = user?.user_metadata?.avatar_url || `https://ui-avatars.com/api/?name=${userName}&background=c9a227&color=0e0f11`;

    return (
        <AnimatePresence>
            <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
                <motion.form
                    onSubmit={handleSubmit}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="bg-card border border-border rounded-2xl max-w-lg w-full relative flex flex-col max-h-[90vh]"
                >
                    <div className="p-4 sm:p-6 border-b border-border flex justify-between items-center">
                        <h2 className="text-xl font-bold">Crear en Comunidad {community === 'boost' ? 'Boost' : 'Campus'}</h2>
                        <Button variant="ghost" size="icon" type="button" onClick={onClose}><X className="w-5 h-5" /></Button>
                    </div>

                    <div className="p-4 sm:p-6 flex-1 overflow-y-auto space-y-4">
                        <div className="flex items-center gap-3">
                             <img src={userAvatar} alt={userName} className="w-10 h-10 rounded-full object-cover" />
                             <div>
                                <p className="font-bold">{userName}</p>
                                <div className="flex items-center gap-2 mt-1">
                                    {visibilityOptions.map(opt => (
                                        <Button key={opt.id} type="button" size="sm" variant={visibility === opt.id ? 'secondary' : 'ghost'} onClick={() => setVisibility(opt.id)} className="text-xs h-7">
                                            <opt.icon className="w-3 h-3 mr-1.5" />
                                            {opt.label}
                                        </Button>
                                    ))}
                                </div>
                             </div>
                        </div>

                        <textarea
                            value={body}
                            onChange={(e) => setBody(e.target.value)}
                            placeholder={community === 'boost' ? '¿Cómo va ese progreso, leyenda?' : '¿Qué estás construyendo hoy?'}
                            className="w-full h-32 p-3 bg-input border-border rounded-lg text-sm"
                        />

                        <div className="flex items-center gap-2">
                           <Button type="button" variant={postType === 'status' ? 'secondary' : 'ghost'} onClick={() => { setPostType('status'); setAttachment(null); }}> <Edit3 className="w-4 h-4 mr-2"/> Estado</Button>
                           <Button type="button" variant={postType === 'workout' ? 'secondary' : 'ghost'} onClick={() => setPostType('workout')}> <Dumbbell className="w-4 h-4 mr-2"/> Entreno</Button>
                           <Button type="button" variant={postType === 'meal' ? 'secondary' : 'ghost'} onClick={() => setPostType('meal')}> <Apple className="w-4 h-4 mr-2"/> Comida</Button>
                        </div>
                        
                        {postType === 'workout' && (
                            <div className="space-y-2">
                                <h4 className="font-semibold text-sm">Adjuntar un entrenamiento reciente:</h4>
                                {recentWorkouts.length > 0 ? recentWorkouts.map(w => (
                                    <div key={w.id} onClick={() => setAttachment(w)} className={`p-2 rounded-lg cursor-pointer border ${attachment?.id === w.id ? 'bg-primary/10 border-primary' : 'bg-secondary border-border'}`}>
                                        <p className="text-sm font-medium">{w.program_name || 'Entreno Libre'} - {new Date(w.date).toLocaleDateString()}</p>
                                    </div>
                                )) : <p className="text-xs text-muted-foreground">No hay entrenos recientes para adjuntar.</p>}
                            </div>
                        )}
                        
                        {postType === 'meal' && (
                             <div className="space-y-2">
                                <h4 className="font-semibold text-sm">Adjuntar una comida reciente:</h4>
                                {recentMeals.length > 0 ? recentMeals.map(m => (
                                    <div key={m.id} onClick={() => setAttachment(m)} className={`p-2 rounded-lg cursor-pointer border ${attachment?.id === m.id ? 'bg-primary/10 border-primary' : 'bg-secondary border-border'}`}>
                                        <p className="text-sm font-medium capitalize">{m.nombre} - {new Date(m.fecha).toLocaleDateString()}</p>
                                    </div>
                                )) : <p className="text-xs text-muted-foreground">No hay comidas recientes para adjuntar.</p>}
                            </div>
                        )}


                    </div>

                    <div className="p-4 sm:p-6 border-t border-border">
                        <Button type="submit" disabled={isPosting || (!body.trim() && !attachment)} className="w-full btn-primary">
                            {isPosting ? 'Publicando...' : 'Publicar'}
                        </Button>
                    </div>
                </motion.form>
            </div>
        </AnimatePresence>
    );
};

export default CreatePostModal;