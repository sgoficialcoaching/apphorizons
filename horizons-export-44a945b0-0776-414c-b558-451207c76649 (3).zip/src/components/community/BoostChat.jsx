import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import ChannelSidebar from './ChannelSidebar';
import ChatArea from './ChatArea';
import MembersSidebar from './MembersSidebar';
import { toast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';
import { addMinutes, isAfter, parseISO } from 'date-fns';

const BAD_WORDS = [
  'puto', 'mierda', 'cabron', 'cabrón', 'gilipollas', 'idiota', 
  'imbecil', 'imbécil', 'verga', 'pendejo', 'estupido', 'estúpido', 
  'maricon', 'maricón', 'zorra', 'bastardo', 'coño'
];

const TARGET_CATEGORIES = [
  'General', 
  'Entrenamientos', 
  'Nutrición', 
  'Mindset', 
  'Chat con Sergi Constance'
];

const BoostChat = () => {
  const { user, loading: authLoading } = useAuth();
  const [channels, setChannels] = useState([]);
  const [activeChannel, setActiveChannel] = useState(null);
  const [messages, setMessages] = useState([]);
  const [reactions, setReactions] = useState({}); // Map: message_id -> array of reactions
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [onlineUsers, setOnlineUsers] = useState([]);
  
  const processedMessageIds = useRef(new Set());
  const channelSubscriptionRef = useRef(null);

  // Fetch Channels
  useEffect(() => {
    const fetchChannels = async () => {
      const { data, error } = await supabase.from('channels').select('*');
      if (error) {
        console.error('Error fetching channels:', error);
      } else {
        const orderedChannels = [];
        const availableMap = new Map(data.map(c => [c.name, c]));
        TARGET_CATEGORIES.forEach(catName => {
            if (availableMap.has(catName)) orderedChannels.push(availableMap.get(catName));
        });
        setChannels(orderedChannels);
        if (orderedChannels.length > 0 && !activeChannel) {
            const generalChannel = orderedChannels.find(c => c.name === 'General');
            setActiveChannel(generalChannel || orderedChannels[0]);
        }
      }
    };
    fetchChannels();
  }, []);

  // Fetch Messages & Subscribe to Realtime
  useEffect(() => {
    if (!activeChannel) return;
    
    // Cleanup previous subscription if exists
    if (channelSubscriptionRef.current) {
        supabase.removeChannel(channelSubscriptionRef.current);
        channelSubscriptionRef.current = null;
    }

    processedMessageIds.current = new Set();
    setLoadingMessages(true);
    setMessages([]);
    setReactions({});

    const fetchData = async () => {
      // 1. Fetch Messages
      const { data: msgs, error: msgError } = await supabase
        .from('messages')
        .select('*')
        .eq('channel_id', activeChannel.id)
        .order('created_at', { ascending: true })
        .limit(100);

      if (msgError) console.error('Error fetching messages:', msgError);
      
      const loadedMessages = msgs || [];
      // Mark initial messages as processed to avoid "insert" event duplicates if they come in late
      loadedMessages.forEach(m => processedMessageIds.current.add(m.id));
      setMessages(loadedMessages);

      if (loadedMessages.length > 0) {
        // 2. Fetch Reactions for these messages
        const msgIds = loadedMessages.map(m => m.id);
        const { data: reacts, error: reactError } = await supabase
          .from('message_reactions')
          .select('*')
          .in('message_id', msgIds);

        if (reactError) console.error('Error fetching reactions:', reactError);

        const reactionsMap = {};
        (reacts || []).forEach(r => {
            if (!reactionsMap[r.message_id]) reactionsMap[r.message_id] = [];
            reactionsMap[r.message_id].push(r);
        });
        setReactions(reactionsMap);
      }

      setLoadingMessages(false);
    };

    fetchData();

    // 3. Realtime Subscription Setup
    const channelSub = supabase
      .channel(`chat:${activeChannel.id}`)
      .on('postgres_changes', { 
          event: 'INSERT', 
          schema: 'public', 
          table: 'messages',
          filter: `channel_id=eq.${activeChannel.id}`
      }, (payload) => {
          const newMessage = payload.new;
          // CRITICAL: Only add if we haven't seen this ID yet
          if (!processedMessageIds.current.has(newMessage.id)) {
              processedMessageIds.current.add(newMessage.id);
              setMessages(prev => [...prev, newMessage]);
          }
      })
      .on('postgres_changes', {
          event: '*',
          schema: 'public',
          table: 'message_reactions'
      }, (payload) => {
          const { eventType, new: newReaction, old: oldReaction } = payload;
          
          setReactions(prev => {
              const nextState = { ...prev };
              
              if (eventType === 'INSERT') {
                  if (!nextState[newReaction.message_id]) nextState[newReaction.message_id] = [];
                  // Check if reaction already exists (from optimistic update) to avoid duplicates
                  const exists = nextState[newReaction.message_id].some(r => r.id === newReaction.id);
                  if (!exists) {
                      // Also filter out temp reactions if the real one has arrived
                      nextState[newReaction.message_id] = [
                          ...nextState[newReaction.message_id].filter(r => !r.id.toString().startsWith('temp-')), 
                          newReaction
                      ];
                  }
              } else if (eventType === 'DELETE') {
                  const targetMsgId = oldReaction.message_id;
                  if (nextState[targetMsgId]) {
                      nextState[targetMsgId] = nextState[targetMsgId].filter(r => r.id !== oldReaction.id);
                  }
              }
              return nextState;
          });
      })
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
           // console.log(`Subscribed to ${activeChannel.name}`);
        }
      });

    channelSubscriptionRef.current = channelSub;

    return () => {
      if (channelSubscriptionRef.current) {
        supabase.removeChannel(channelSubscriptionRef.current);
      }
    };
  }, [activeChannel]);

  // Presence logic
  useEffect(() => {
    if (!user) return;
    const presenceChannel = supabase.channel('global_presence', {
        config: { presence: { key: user.id } },
    });
    presenceChannel
      .on('presence', { event: 'sync' }, () => {
         const newState = presenceChannel.presenceState();
         setOnlineUsers(Object.values(newState).map(p => p[0]).flat());
      })
      .subscribe(async (status) => {
          if (status === 'SUBSCRIBED') {
              await presenceChannel.track({
                  id: user.id,
                  name: user.user_metadata?.full_name || user.email?.split('@')[0],
                  avatar: user.user_metadata?.avatar_url,
                  online_at: new Date().toISOString(),
                  role: user.user_metadata?.role || 'Miembro'
              });
          }
      });
    return () => supabase.removeChannel(presenceChannel);
  }, [user]);

  const handleSendMessage = async (content, file) => {
    if (!activeChannel || !user) return;
    
    const { data: profile } = await supabase.from('profiles').select('banned_until').eq('id', user.id).single();
    if (profile?.banned_until && isAfter(parseISO(profile.banned_until), new Date())) {
      toast({ title: "🚫 Acceso Restringido", description: "Bloqueado temporalmente.", variant: "destructive" });
      return;
    }

    if (BAD_WORDS.some(w => content.toLowerCase().includes(w.toLowerCase()))) {
      const banUntil = addMinutes(new Date(), 120);
      await supabase.from('profiles').update({ banned_until: banUntil.toISOString() }).eq('id', user.id);
      toast({ title: "⛔ Bloqueado", description: "Lenguaje inapropiado.", variant: "destructive" });
      return;
    }

    let attachmentUrl = null, attachmentType = null;
    if (file) {
      const ext = file.name.split('.').pop();
      const path = `${user.id}/${Math.random()}.${ext}`;
      const { error } = await supabase.storage.from('chat-attachments').upload(path, file);
      if (error) { toast({ title: "Error subiendo archivo", variant: "destructive" }); return; }
      const { data } = supabase.storage.from('chat-attachments').getPublicUrl(path);
      attachmentUrl = data.publicUrl;
      attachmentType = file.type.startsWith('image/') ? 'image' : 'video';
    }

    // Insert AND Select immediately
    const { data: newMessage, error } = await supabase.from('messages').insert({
        channel_id: activeChannel.id,
        user_id: user.id,
        content: content.trim(),
        author_name: user.user_metadata?.full_name || user.email?.split('@')[0],
        author_avatar: user.user_metadata?.avatar_url,
        attachment_url: attachmentUrl,
        attachment_type: attachmentType
    }).select().single();

    if (error) {
        console.error("Error sending message:", error);
        toast({ title: "Error", description: "No se pudo enviar el mensaje.", variant: "destructive" });
        return;
    }

    // OPTIMISTIC UPDATE: Manually update local state immediately
    if (newMessage) {
        // Mark as processed so the realtime subscription ignores the "echo"
        processedMessageIds.current.add(newMessage.id);
        setMessages(prev => [...prev, newMessage]);
    }
  };

  const handleReaction = async (messageId, emoji) => {
      if (!user) return;

      const currentReactions = reactions[messageId] || [];
      const existingReaction = currentReactions.find(r => r.user_id === user.id && r.emoji === emoji);

      // OPTIMISTIC UPDATE:
      setReactions(prev => {
          const nextState = { ...prev };
          if (!nextState[messageId]) nextState[messageId] = [];

          if (existingReaction) {
              // Optimistically remove
              nextState[messageId] = nextState[messageId].filter(r => r.id !== existingReaction.id);
          } else {
              // Optimistically add (temp ID for UI rendering)
              const tempReaction = {
                  id: `temp-${Date.now()}`,
                  message_id: messageId,
                  user_id: user.id,
                  emoji: emoji,
                  created_at: new Date().toISOString()
              };
              nextState[messageId] = [...nextState[messageId], tempReaction];
          }
          return nextState;
      });

      // DATABASE ACTION:
      if (existingReaction) {
          await supabase.from('message_reactions').delete().eq('id', existingReaction.id);
      } else {
          const { error } = await supabase.from('message_reactions').insert({
              message_id: messageId,
              user_id: user.id,
              emoji: emoji
          });

          if (error) {
              console.error("Error adding reaction", error);
              // Revert logic would ideally go here if complex error handling needed
          }
      }
  };

  if (authLoading) return <div className="h-[500px] flex items-center justify-center"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] md:h-[calc(100vh-100px)] w-full overflow-hidden bg-[#313338] rounded-xl shadow-2xl border border-[#1E1F22]">
      <ChannelSidebar 
          channels={channels} 
          activeChannelId={activeChannel?.id} 
          onSelectChannel={setActiveChannel} 
          user={user}
      />
      <div className="flex flex-1 overflow-hidden">
        <ChatArea 
            channel={activeChannel} 
            messages={messages} 
            reactions={reactions}
            onSendMessage={handleSendMessage}
            onReact={handleReaction}
            loading={loadingMessages}
            user={user}
        />
        <MembersSidebar onlineUsers={onlineUsers} />
      </div>
    </div>
  );
};

export default BoostChat;