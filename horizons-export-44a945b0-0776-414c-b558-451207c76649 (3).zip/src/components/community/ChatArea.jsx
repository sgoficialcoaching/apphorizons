import React, { useEffect, useRef, useState } from 'react';
import { Hash, PlusCircle, Smile, Send, Image as ImageIcon, X, Plus } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

const COMMON_EMOJIS = ["😀", "😂", "🥰", "😎", "🔥", "💪", "💯", "🚀", "💀", "👍", "👎", "🎉", "👀", "🤔", "🤡", "💩", "❤️", "✨"];

const ChatArea = ({ channel, messages = [], reactions = {}, onSendMessage, onReact, loading, user }) => {
  const [inputValue, setInputValue] = useState('');
  const [selectedFile, setSelectedFile] = useState(null);
  const [isEmojiOpen, setIsEmojiOpen] = useState(false);
  
  const fileInputRef = useRef(null);
  const bottomRef = useRef(null);

  useEffect(() => {
    if (bottomRef.current) bottomRef.current.scrollIntoView({ behavior: 'smooth' });
  }, [messages, selectedFile, channel]);

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  const handleSend = () => {
    if (inputValue.trim() || selectedFile) {
      onSendMessage(inputValue, selectedFile);
      setInputValue('');
      setSelectedFile(null);
      if(fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file && (file.type.startsWith('image/') || file.type.startsWith('video/'))) setSelectedFile(file);
    else alert("Solo se permiten fotos y videos.");
  };

  const addEmoji = (emoji) => {
    setInputValue(prev => prev + emoji);
    setIsEmojiOpen(false);
  };

  // Group reactions by emoji type
  const getGroupedReactions = (msgId) => {
      const msgReactions = reactions[msgId] || [];
      const groups = {};
      msgReactions.forEach(r => {
          if (!groups[r.emoji]) groups[r.emoji] = { count: 0, hasReacted: false };
          groups[r.emoji].count++;
          if (r.user_id === user?.id) groups[r.emoji].hasReacted = true;
      });
      return Object.entries(groups).map(([emoji, data]) => ({ emoji, ...data }));
  };

  if (!channel) return <div className="flex-1 bg-[#313338]" />;

  const isQAChannel = channel.name === 'Chat con Sergi Constance';

  return (
    <div className="flex-1 flex flex-col bg-[#313338] min-w-0 relative">
      <ScrollArea className="flex-1 px-2 md:px-4">
        <div className="py-4 flex flex-col justify-end min-h-full">
            <div className="mb-4 md:mb-8 mt-2 md:mt-4 px-2">
                <div className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-[#41434A] flex items-center justify-center mb-2 md:mb-4">
                    <Hash className="w-6 h-6 md:w-10 md:h-10 text-white" />
                </div>
                <h1 className="text-xl md:text-3xl font-bold text-white mb-1 md:mb-2">{isQAChannel ? 'Preguntas a Sergi' : `Bienvenido a #${channel.name}`}</h1>
                <p className="text-[#B5BAC1] text-sm">{isQAChannel ? 'Espacio oficial para preguntar a Sergi.' : `Inicio de #${channel.name}.`}</p>
            </div>

            {loading && <div className="flex justify-center py-4"><div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[#5865F2]" /></div>}

            {messages.map((msg, index) => {
                const isSameAuthor = index > 0 && messages[index - 1].user_id === msg.user_id;
                const prevDate = index > 0 ? new Date(messages[index - 1].created_at) : null;
                const currentDate = new Date(msg.created_at);
                const isCloseInTime = prevDate && (currentDate - prevDate) < 5 * 60 * 1000;
                const shouldGroup = isSameAuthor && isCloseInTime;
                const isSergi = msg.author_name?.toLowerCase().includes('sergi constance') || msg.role === 'admin'; 
                const msgReactions = getGroupedReactions(msg.id);

                return (
                    <div 
                        key={msg.id} 
                        className={`group flex gap-3 md:gap-4 py-0.5 hover:bg-[#2E3035]/60 -mx-2 md:-mx-4 px-2 md:px-4 relative pr-10 ${shouldGroup ? '' : 'mt-[17px]'}`}
                    >
                        {/* Avatar / Time */}
                        {!shouldGroup ? (
                            <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-[#5865F2] flex-shrink-0 overflow-hidden cursor-pointer hover:opacity-80 transition-opacity mt-0.5">
                                {msg.author_avatar ? <img src={msg.author_avatar} alt="" className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-white font-bold text-xs">{(msg.author_name?.[0] || 'U').toUpperCase()}</div>}
                            </div>
                        ) : (
                            <div className="w-8 md:w-10 flex-shrink-0 text-[10px] text-[#949BA4] opacity-0 group-hover:opacity-100 text-right pr-2 md:pr-3 select-none pt-1">{format(currentDate, 'HH:mm')}</div>
                        )}

                        <div className="flex-1 min-w-0">
                            {/* Header info */}
                            {!shouldGroup && (
                                <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                                    <span className={`font-medium hover:underline cursor-pointer text-sm md:text-base ${isSergi ? 'text-yellow-500' : 'text-white'}`}>{msg.author_name}</span>
                                    {isSergi && <span className="bg-[#5865F2] text-[10px] text-white px-1 rounded uppercase font-bold">OP</span>}
                                    <span className="text-[10px] md:text-xs text-[#949BA4] ml-1">{format(currentDate, "d/MM/yyyy HH:mm")}</span>
                                </div>
                            )}
                            
                            {/* Message Content with Popover Trigger */}
                            <Popover>
                                <PopoverTrigger asChild>
                                    <div className="cursor-pointer">
                                        {msg.content && <p className="text-[#DBDEE1] whitespace-pre-wrap break-words leading-[1.375rem] text-sm md:text-base">{msg.content}</p>}
                                        {msg.attachment_url && (
                                            <div className="mt-2 max-w-[85%] md:max-w-sm rounded-lg overflow-hidden border border-[#26272D]">
                                                {msg.attachment_type === 'image' ? <img src={msg.attachment_url} alt="Att" className="w-full h-auto max-h-60 object-cover" /> : <video src={msg.attachment_url} controls className="w-full h-auto max-h-60" />}
                                            </div>
                                        )}
                                    </div>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-1 bg-[#2B2D31] border-[#1E1F22] flex gap-1 shadow-xl" align="start" side="top">
                                    {COMMON_EMOJIS.slice(0, 8).map(emoji => (
                                        <button key={emoji} onClick={() => onReact(msg.id, emoji)} className="p-2 hover:bg-[#35373C] rounded transition-colors text-lg">{emoji}</button>
                                    ))}
                                    <Popover>
                                        <PopoverTrigger asChild>
                                            <button className="p-2 hover:bg-[#35373C] rounded transition-colors text-[#B5BAC1]"><PlusCircle className="w-5 h-5"/></button>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-64 p-2 bg-[#2B2D31] border-[#1E1F22] shadow-xl grid grid-cols-6 gap-1" side="top">
                                            {COMMON_EMOJIS.map(emoji => (
                                                <button key={emoji} onClick={() => onReact(msg.id, emoji)} className="text-xl hover:bg-[#35373C] p-1 rounded">{emoji}</button>
                                            ))}
                                        </PopoverContent>
                                    </Popover>
                                </PopoverContent>
                            </Popover>

                            {/* Reactions Display */}
                            {(msgReactions.length > 0) && (
                                <div className="flex flex-wrap gap-1 mt-1.5">
                                    {msgReactions.map((reaction) => (
                                        <button 
                                            key={reaction.emoji}
                                            onClick={() => onReact(msg.id, reaction.emoji)}
                                            className={cn(
                                                "flex items-center gap-1.5 px-1.5 py-0.5 rounded-[4px] border transition-colors",
                                                reaction.hasReacted 
                                                    ? "bg-[#5865F2]/20 border-[#5865F2] text-[#5865F2]" 
                                                    : "bg-[#2B2D31] border-transparent hover:border-[#4E5058] text-[#B5BAC1]"
                                            )}
                                        >
                                            <span className="text-sm">{reaction.emoji}</span>
                                            <span className="text-xs font-bold">{reaction.count}</span>
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>

                        {/* Quick Action Overlay (Desktop Hover) */}
                        <div className="absolute right-4 top-0 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-[#2B2D31] shadow-sm rounded border border-[#1E1F22] p-0.5 hidden md:flex items-center">
                            <Popover>
                                <PopoverTrigger asChild>
                                    <button className="p-1 hover:bg-[#35373C] rounded text-[#B5BAC1] hover:text-[#DBDEE1]" title="Reaccionar">
                                        <Smile className="w-4 h-4" />
                                    </button>
                                </PopoverTrigger>
                                <PopoverContent className="w-64 p-2 bg-[#2B2D31] border-[#1E1F22] shadow-xl" align="end">
                                    <div className="grid grid-cols-6 gap-1">
                                        {COMMON_EMOJIS.map(emoji => (
                                            <button key={emoji} onClick={() => onReact(msg.id, emoji)} className="text-xl hover:bg-[#35373C] p-1 rounded">{emoji}</button>
                                        ))}
                                    </div>
                                </PopoverContent>
                            </Popover>
                        </div>
                    </div>
                );
            })}
            <div ref={bottomRef} className="h-px" />
        </div>
      </ScrollArea>

      <div className="px-2 md:px-4 pb-4 md:pb-6 pt-2 flex-shrink-0 bg-[#313338] z-10">
        {selectedFile && (
            <div className="mx-2 md:mx-4 mb-2 bg-[#2B2D31] p-2 md:p-3 rounded-t-lg border-b border-[#1E1F22] flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 md:w-12 md:h-12 rounded bg-[#1E1F22] flex items-center justify-center overflow-hidden">
                        {selectedFile.type.startsWith('image/') ? <img src={URL.createObjectURL(selectedFile)} className="w-full h-full object-cover" alt="prev"/> : <ImageIcon className="text-gray-400 w-5 h-5" />}
                    </div>
                    <div>
                        <p className="text-white text-sm font-medium truncate max-w-[150px]">{selectedFile.name}</p>
                    </div>
                </div>
                <button onClick={() => { setSelectedFile(null); if(fileInputRef.current) fileInputRef.current.value = ''; }} className="text-gray-400 hover:text-red-500"><X className="w-5 h-5" /></button>
            </div>
        )}
        <div className={`bg-[#383A40] px-2 md:px-4 py-2 flex items-center gap-2 md:gap-3 ${selectedFile ? 'rounded-b-lg' : 'rounded-lg'}`}>
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*,video/*" onChange={handleFileSelect} />
            <button onClick={() => fileInputRef.current?.click()} className="text-[#B5BAC1] hover:text-[#DBDEE1] bg-[#2B2D31] p-1.5 rounded-full flex-shrink-0"><PlusCircle className="w-5 h-5" /></button>
            <input value={inputValue} onChange={(e) => setInputValue(e.target.value)} onKeyDown={handleKeyDown} placeholder={isQAChannel ? "Haz una pregunta a Sergi..." : `Mensaje en #${channel.name}`} className="bg-transparent border-none outline-none text-[#DBDEE1] placeholder-[#949BA4] flex-1 h-full py-2 text-sm md:text-base min-w-0" autoComplete="off" />
            <div className="flex items-center gap-2 md:gap-3 text-[#B5BAC1] flex-shrink-0">
                <Popover open={isEmojiOpen} onOpenChange={setIsEmojiOpen}>
                    <PopoverTrigger asChild>
                        <button className="hover:text-[#DBDEE1] p-1 rounded hidden sm:block"><Smile className="w-6 h-6" /></button>
                    </PopoverTrigger>
                    <PopoverContent className="w-64 p-2 bg-[#2B2D31] border-[#1E1F22] shadow-xl" align="end" side="top">
                        <div className="grid grid-cols-6 gap-2">
                            {COMMON_EMOJIS.map(emoji => (
                                <button key={emoji} onClick={() => addEmoji(emoji)} className="text-2xl hover:bg-[#35373C] p-1 rounded transition-colors text-center">{emoji}</button>
                            ))}
                        </div>
                    </PopoverContent>
                </Popover>
                {(inputValue.trim() || selectedFile) && <button onClick={handleSend} className="text-[#5865F2] hover:text-white p-1"><Send className="w-5 h-5" /></button>}
            </div>
        </div>
      </div>
    </div>
  );
};

export default ChatArea;