import React, { useState, useEffect } from 'react';
import { Settings, User, Mail, Award, ShieldCheck, Save, Search, UserCog, LogOut } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

const ADMIN_EMAIL = 'dim.ivelinov.d@gmail.com';
const VALID_ROLES = ['Propietario', 'Superadministrador', 'Administrador', 'Miembro'];

const ChannelSidebar = ({ channels = [], activeChannelId, onSelectChannel, user }) => {
  const { toast } = useToast();
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [users, setUsers] = useState([]);
  const [currentUserProfile, setCurrentUserProfile] = useState(null);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [manualEmail, setManualEmail] = useState('');
  const [manualRole, setManualRole] = useState('Miembro');

  const userEmail = user?.email || '';
  const isAdmin = userEmail.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase();

  useEffect(() => {
    if (user?.id) {
        const fetchMyProfile = async () => {
            const { data } = await supabase
                .from('profiles')
                .select('*')
                .eq('id', user.id)
                .maybeSingle();
            
            if (data) {
                setCurrentUserProfile(data);
            } else {
                setCurrentUserProfile({
                    role: 'Miembro',
                    full_name: user.user_metadata?.full_name || 'Usuario',
                    avatar_url: user.user_metadata?.avatar_url
                });
            }
        };
        fetchMyProfile();
    }
  }, [user]);

  const fetchUsers = async () => {
    if (!isAdmin) return;
    setLoadingUsers(true);
    try {
      const { data: profiles, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setUsers(profiles || []);
    } catch (error) {
      console.error('Error fetching users:', error);
    } finally {
      setLoadingUsers(false);
    }
  };

  useEffect(() => {
    if (isProfileOpen && isAdmin) {
      fetchUsers();
    }
  }, [isProfileOpen, isAdmin]);

  const handleUpdateRole = async (userId, newRole) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ role: newRole })
        .eq('id', userId);

      if (error) throw error;

      toast({ title: 'Rol actualizado', description: `Usuario actualizado a ${newRole}` });
      setUsers(prev => prev.map(u => u.id === userId ? { ...u, role: newRole } : u));
    } catch (error) {
      console.error('Role update error:', error);
      toast({ title: 'Error', description: 'Falló la actualización.', variant: 'destructive' });
    }
  };

  const handleManualAssign = async () => {
    if (!manualEmail.trim()) return;
    const targetUser = users.find(u => u.email?.toLowerCase() === manualEmail.toLowerCase());

    if (!targetUser) {
        toast({ title: 'Usuario no encontrado', variant: 'destructive' });
        return;
    }

    await handleUpdateRole(targetUser.id, manualRole);
    setManualEmail('');
  };

  const filteredUsers = users.filter(u => 
    (u.email?.toLowerCase() || '').includes(searchTerm.toLowerCase()) || 
    (u.full_name?.toLowerCase() || '').includes(searchTerm.toLowerCase())
  );

  const displayName = currentUserProfile?.full_name || user?.user_metadata?.full_name || 'Usuario';
  const displayAvatar = currentUserProfile?.avatar_url || user?.user_metadata?.avatar_url;
  const displayRole = currentUserProfile?.role || 'Miembro';

  return (
    <div className="w-full bg-[#2B2D31] border-b border-[#1E1F22] flex flex-col md:flex-row items-stretch md:items-center flex-shrink-0 z-20 relative">
      
      {/* Mobile / Scrollable Tabs - Clean, no overlays */}
      <div className="flex-1 overflow-x-auto no-scrollbar py-2 px-2 md:px-4">
        <div className="flex items-center gap-2 pr-2 md:pr-0">
            {channels.map((channel) => {
                const isActive = activeChannelId === channel.id;
                return (
                    <button
                        key={channel.id}
                        onClick={() => onSelectChannel(channel)}
                        className={cn(
                            "px-4 py-2 rounded-full text-xs md:text-sm font-bold whitespace-nowrap transition-all select-none border border-transparent flex-shrink-0",
                            isActive 
                                ? "bg-[#5865F2] text-white shadow-md border-[#4752C4]" 
                                : "bg-[#1E1F22] text-gray-400 hover:text-gray-200 hover:bg-[#35373C]"
                        )}
                    >
                        {channel.name}
                    </button>
                );
            })}
             {/* Space spacer for mobile settings icon to prevent overlap */}
             <div className="w-10 h-1 md:hidden flex-shrink-0"></div>
        </div>
      </div>

      {/* User Profile Trigger - Right side on Desktop */}
      <div className="hidden md:flex items-center px-4 border-l border-[#1E1F22] h-14 bg-[#232428]">
        <div 
            onClick={() => setIsProfileOpen(true)}
            className="flex items-center gap-3 p-1.5 rounded-md hover:bg-[#35373C] cursor-pointer transition-colors group"
        >
            <div className="relative">
                <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center text-white overflow-hidden ring-2 ring-transparent group-hover:ring-[#5865F2]/50 transition-all">
                    {displayAvatar ? (
                        <img src={displayAvatar} alt="Avatar" className="w-full h-full object-cover" />
                    ) : (
                        <span className="font-bold text-xs">{displayName.substring(0,2).toUpperCase()}</span>
                    )}
                </div>
                <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-[#232428]"></div>
            </div>
            <div className="text-left hidden lg:block">
                <div className="text-xs font-bold text-white truncate max-w-[100px]">{displayName}</div>
                <div className="text-[10px] text-gray-400 truncate">{displayRole}</div>
            </div>
            <Settings className="w-4 h-4 text-gray-400 group-hover:text-white transition-colors" />
        </div>
      </div>

      {/* Mobile Profile Trigger - FIXED POSITION to right, no gradient overlay, moved down slightly */}
      <div className="md:hidden absolute right-2 top-1/2 -translate-y-1/2 z-20">
          <button 
            onClick={() => setIsProfileOpen(true)} 
            className="w-8 h-8 rounded-full bg-[#1E1F22]/90 flex items-center justify-center text-gray-400 border border-gray-700 shadow-xl active:scale-95 transition-transform backdrop-blur-sm"
          >
             <Settings className="w-4 h-4" />
          </button>
      </div>

      {/* Profile Dialog */}
      <Dialog open={isProfileOpen} onOpenChange={setIsProfileOpen}>
        <DialogContent className="max-w-4xl h-[85vh] bg-[#313338] border-[#1E1F22] text-white p-0 overflow-hidden flex flex-col z-50">
            <DialogHeader className="p-6 border-b border-[#1E1F22] bg-[#2B2D31]">
                <DialogTitle className="text-xl font-bold flex items-center gap-2">
                    <UserCog className="w-6 h-6 text-[#5865F2]" />
                    Configuración de Usuario
                </DialogTitle>
                <DialogDescription className="text-gray-400">
                    Gestiona tu perfil y preferencias de la comunidad.
                </DialogDescription>
            </DialogHeader>

            <Tabs defaultValue="profile" className="flex-1 flex flex-col overflow-hidden">
                <div className="px-6 pt-4 bg-[#2B2D31]">
                    <TabsList className="bg-[#1E1F22] text-gray-400">
                        <TabsTrigger value="profile" className="data-[state=active]:bg-[#35373C] data-[state=active]:text-white">Mi Perfil</TabsTrigger>
                        {isAdmin && <TabsTrigger value="admin" className="data-[state=active]:bg-[#35373C] data-[state=active]:text-yellow-500">Panel de Administrador</TabsTrigger>}
                    </TabsList>
                </div>

                <TabsContent value="profile" className="flex-1 p-6 overflow-y-auto m-0 space-y-6">
                    <div className="flex flex-col md:flex-row gap-6 items-start">
                        <div className="w-32 h-32 rounded-full bg-[#5865F2] flex items-center justify-center text-4xl font-bold text-white overflow-hidden border-4 border-[#1E1F22] shadow-xl">
                            {displayAvatar ? (
                                <img src={displayAvatar} alt="Profile" className="w-full h-full object-cover" />
                            ) : (
                                displayName.substring(0,2).toUpperCase()
                            )}
                        </div>
                        <div className="space-y-4 flex-1 w-full">
                            <div className="space-y-1">
                                <label className="text-xs uppercase font-bold text-gray-400">Nombre de Usuario</label>
                                <div className="bg-[#1E1F22] p-3 rounded-md text-white font-medium flex items-center gap-2">
                                    <User className="w-4 h-4 text-gray-500" />
                                    {displayName}
                                </div>
                            </div>
                            <div className="space-y-1">
                                <label className="text-xs uppercase font-bold text-gray-400">Correo Electrónico</label>
                                <div className="bg-[#1E1F22] p-3 rounded-md text-white font-medium flex items-center gap-2">
                                    <Mail className="w-4 h-4 text-gray-500" />
                                    {userEmail}
                                </div>
                            </div>
                            <div className="space-y-1">
                                <label className="text-xs uppercase font-bold text-gray-400">Rango / Rol</label>
                                <div className="bg-[#1E1F22] p-3 rounded-md text-yellow-500 font-bold flex items-center gap-2 border border-yellow-500/20">
                                    <Award className="w-4 h-4" />
                                    {displayRole.toUpperCase()}
                                </div>
                            </div>
                            
                            <Button variant="outline" className="w-full border-red-900/30 text-red-500 hover:bg-red-900/10 hover:text-red-400 mt-4" onClick={() => supabase.auth.signOut()}>
                                <LogOut className="w-4 h-4 mr-2" /> Cerrar Sesión
                            </Button>
                        </div>
                    </div>
                </TabsContent>

                {isAdmin && (
                    <TabsContent value="admin" className="flex-1 flex flex-col m-0 overflow-hidden">
                        <div className="p-4 bg-[#2B2D31]/50 border-b border-[#1E1F22] space-y-3">
                            <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider flex items-center gap-2">
                                <ShieldCheck className="w-4 h-4 text-green-500" /> Asignación Rápida de Rol
                            </h3>
                            <div className="flex flex-col md:flex-row gap-3">
                                <Input 
                                    placeholder="Email del usuario..." 
                                    value={manualEmail}
                                    onChange={(e) => setManualEmail(e.target.value)}
                                    className="bg-[#1E1F22] border-none text-white focus:ring-1 focus:ring-yellow-500"
                                />
                                <div className="w-full md:w-48">
                                    <Select value={manualRole} onValueChange={setManualRole}>
                                        <SelectTrigger className="bg-[#1E1F22] border-none text-white h-10">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent className="bg-[#1E1F22] border-[#2B2D31] text-white">
                                            {VALID_ROLES.map(role => (
                                                <SelectItem key={role} value={role} className="focus:bg-[#35373C] cursor-pointer">{role}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <Button onClick={handleManualAssign} className="bg-green-600 hover:bg-green-700 text-white font-bold">
                                    <Save className="w-4 h-4 mr-2" /> Guardar
                                </Button>
                            </div>
                        </div>

                        <div className="p-4 border-b border-[#1E1F22] bg-[#2B2D31]/30">
                            <div className="relative">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                                <Input 
                                    placeholder="Filtrar lista de usuarios..." 
                                    className="pl-9 bg-[#1E1F22] border-none text-white placeholder:text-gray-500"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                            </div>
                        </div>

                        <ScrollArea className="flex-1 p-4 bg-[#313338]">
                            {loadingUsers ? (
                                <div className="flex items-center justify-center h-32">
                                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-500"></div>
                                </div>
                            ) : (
                                <div className="space-y-2">
                                    {filteredUsers.map((profile) => (
                                        <div key={profile.id} className="flex items-center justify-between p-3 rounded-lg bg-[#2B2D31] border border-[#1E1F22] hover:border-white/10 transition-colors">
                                            <div className="flex items-center gap-3">
                                                <div className="w-10 h-10 rounded-full bg-[#5865F2] flex items-center justify-center text-white font-bold overflow-hidden">
                                                    {profile.avatar_url ? (
                                                        <img src={profile.avatar_url} alt="" className="w-full h-full object-cover" />
                                                    ) : (
                                                        (profile.full_name?.[0] || 'U').toUpperCase()
                                                    )}
                                                </div>
                                                <div>
                                                    <p className="font-bold text-sm text-white">{profile.full_name || 'Sin Nombre'}</p>
                                                    <p className="text-xs text-gray-400">{profile.email}</p>
                                                </div>
                                            </div>

                                            <div className="w-40">
                                                <select
                                                    value={profile.role || 'Miembro'}
                                                    onChange={(e) => handleUpdateRole(profile.id, e.target.value)}
                                                    className="w-full bg-[#1E1F22] text-white text-xs px-2 py-2 rounded border border-[#1E1F22] focus:border-yellow-500 outline-none cursor-pointer"
                                                    disabled={profile.email === ADMIN_EMAIL} 
                                                >
                                                    {VALID_ROLES.map(role => (
                                                        <option key={role} value={role}>{role}</option>
                                                    ))}
                                                </select>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </ScrollArea>
                    </TabsContent>
                )}
            </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ChannelSidebar;