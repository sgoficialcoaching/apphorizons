import React from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Crown } from 'lucide-react';

const MembersSidebar = ({ onlineUsers = [] }) => {
  const uniqueUsers = Array.from(new Map(onlineUsers.map(user => [user.id, user])).values());

  return (
    <div className="w-60 bg-[#2B2D31] hidden lg:flex flex-col h-full border-l border-[#1E1F22] shrink-0">
      <ScrollArea className="flex-1">
        <div className="p-3">
            <h3 className="text-[#949BA4] text-xs font-bold uppercase tracking-wide mb-2 px-2">
                En Línea — {uniqueUsers.length}
            </h3>
            
            <div className="space-y-0.5">
                {uniqueUsers.map((user) => (
                    <div key={user.id} className="flex items-center gap-3 px-2 py-1.5 rounded hover:bg-[#35373C] cursor-pointer group opacity-90 hover:opacity-100 transition-all">
                        <div className="relative">
                            <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center overflow-hidden">
                                {user.avatar ? (
                                    <img src={user.avatar} alt="" className="w-full h-full object-cover" />
                                ) : (
                                    <span className="text-white font-bold text-xs">
                                        {(user.name?.[0] || 'U').toUpperCase()}
                                    </span>
                                )}
                            </div>
                            <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-[#23A559] rounded-full border-[3px] border-[#2B2D31]"></div>
                        </div>
                        
                        <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5">
                                <span className={`font-medium truncate ${user.role === 'admin' ? 'text-[#F1C40F]' : 'text-[#949BA4] group-hover:text-[#DBDEE1]'}`}>
                                    {user.name || 'Usuario'}
                                </span>
                                {user.role === 'admin' && <Crown className="w-3 h-3 text-[#F1C40F]" />}
                            </div>
                        </div>
                    </div>
                ))}
                
                {uniqueUsers.length === 0 && (
                    <div className="px-2 py-4 text-center text-[#949BA4] text-xs italic">
                        Nadie conectado... 🦗
                    </div>
                )}
            </div>
        </div>
      </ScrollArea>
    </div>
  );
};

export default MembersSidebar;