import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Edit, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { getUserProfile, getFeed, toggleFollow } from '@/lib/community';
import PostCard from '@/components/community/PostCard';
import { toast } from '@/components/ui/use-toast';
import LoadingScreen from '@/components/common/LoadingScreen';

const UserProfileScreen = () => {
    const { userId } = useParams();
    const navigate = useNavigate();
    const { user: currentUser } = useAuth();

    const [profile, setProfile] = useState(null);
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);

    const refreshData = useCallback(() => {
        if (!currentUser || !userId) return;
        setLoading(true);
        try {
            const profileData = getUserProfile(userId, currentUser.id);
            if (!profileData) {
                toast({ variant: 'destructive', title: 'Error', description: 'No se pudo encontrar el perfil de usuario.'});
                navigate('/community');
                return;
            }
            const userPosts = getFeed(currentUser.id, 'all').filter(p => p.user_id === userId);
            setProfile(profileData);
            setPosts(userPosts);
        } catch (error) {
            console.error("Error loading profile:", error);
            toast({ variant: 'destructive', title: 'Error', description: 'Hubo un problema al cargar el perfil.'});
            navigate('/community');
        } finally {
            setLoading(false);
        }
    }, [userId, currentUser, navigate]);

    useEffect(() => {
        refreshData();
    }, [refreshData]);

    const handleFollow = () => {
        if (!currentUser) return;
        const result = toggleFollow(currentUser.id, userId);
        
        // Optimistic update
        setProfile(p => {
            if (!p) return null;
            const newFollowerCount = p.stats.followers + (result ? 1 : -1);
            return {
                ...p, 
                isFollowing: result, 
                stats: { ...p.stats, followers: newFollowerCount < 0 ? 0 : newFollowerCount }
            };
        });
        
        toast({ title: result ? `Ahora sigues a ${profile.name}` : `Dejaste de seguir a ${profile.name}` });
    };

    if (loading || !profile) {
        return <LoadingScreen />;
    }
    
    const isOwnProfile = currentUser.id === userId;
    
    const authorAvatar = profile.avatar_url || `https://ui-avatars.com/api/?name=${profile.name.charAt(0)}&background=c9a227&color=0e0f11`;

    return (
        <div className="space-y-6">
            <div className="absolute top-6 left-6 z-10 md:hidden">
                <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="bg-black/20 hover:bg-black/40 text-white">
                    <ArrowLeft />
                </Button>
            </div>
            
            <div className="relative h-48 md:h-64 -mx-4 -mt-4 sm:-mx-6 sm:-mt-6 lg:-mx-8 lg:-mt-8">
                <img alt="Banner de perfil de usuario" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1673887910299-65155a769eab" />
                <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent"></div>
            </div>

            <div className="relative -mt-20 px-4">
                <div className="flex flex-col md:flex-row md:items-end md:gap-6">
                    <img alt={`Avatar de ${profile.name}`} className="w-32 h-32 rounded-full object-cover border-4 border-background mx-auto md:mx-0" src={authorAvatar} />
                    <div className="flex-1 text-center md:text-left pt-4">
                        <h2 className="text-3xl font-bold">{profile.name}</h2>
                        <div className="flex justify-center md:justify-start gap-6 text-sm text-muted-foreground mt-2">
                           <span><span className="font-bold text-foreground">{profile.stats.posts}</span> posts</span>
                           <span><span className="font-bold text-foreground">{profile.stats.followers}</span> seguidores</span>
                           <span><span className="font-bold text-foreground">{profile.stats.following}</span> siguiendo</span>
                        </div>
                    </div>
                     <div className="mt-4 md:mt-0 flex justify-center">
                        {isOwnProfile ? (
                            <div className="flex gap-2">
                               <Button variant="outline" onClick={() => toast({ title: "🚧 Próximamente", description: "La edición de perfil estará disponible pronto."})}><Edit className="w-4 h-4 mr-2"/> Editar Perfil</Button>
                               <Button variant="outline" size="icon" onClick={() => navigate('/profile')}><Settings className="w-4 h-4"/></Button>
                            </div>
                        ) : (
                            <Button onClick={handleFollow} className={profile.isFollowing ? 'btn-secondary' : 'btn-primary'}>
                                {profile.isFollowing ? 'Siguiendo' : 'Seguir'}
                            </Button>
                        )}
                    </div>
                </div>
                {profile.bio && <p className="text-sm text-muted-foreground mt-4 text-center md:text-left">{profile.bio}</p>}
            </div>
            
            <div className="border-t border-border pt-6">
                <h3 className="text-xl font-bold mb-4">Publicaciones</h3>
                 <div className="space-y-6">
                    {posts.length > 0 ? (
                        posts.map(post => (
                            <PostCard key={post.id} post={post} currentUser={currentUser} onRefresh={refreshData} />
                        ))
                    ) : (
                        <p className="text-center text-muted-foreground py-10">Este usuario aún no ha publicado nada.</p>
                    )}
                 </div>
            </div>
        </div>
    );
};

export default UserProfileScreen;