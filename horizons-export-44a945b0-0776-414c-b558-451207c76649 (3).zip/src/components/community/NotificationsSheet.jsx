import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Heart, MessageCircle, UserPlus, BellRing, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { markNotificationsAsRead } from '@/lib/community';
import { useNavigate } from 'react-router-dom';

const NotificationsSheet = ({ onClose, notifications, onRefresh, userId }) => {
    const navigate = useNavigate();
    const users = JSON.parse(localStorage.getItem('users') || '[]');

    useEffect(() => {
        // This now only marks community notifications as read
        markNotificationsAsRead(userId);
        onRefresh();
    }, [userId, onRefresh]);

    const getIcon = (notif) => {
        const type = notif.type || notif.template?.category;
        switch (type) {
            case 'like': return <Heart className="w-5 h-5 text-red-500" />;
            case 'comment': return <MessageCircle className="w-5 h-5 text-blue-500" />;
            case 'follow': return <UserPlus className="w-5 h-5 text-green-500" />;
            case 'motivation':
            case 'streak':
            case 'workout':
            case 'nutrition':
                return <BellRing className="w-5 h-5 text-primary" />;
            default: return <Zap className="w-5 h-5 text-yellow-500" />;
        }
    };

    const getText = (notif) => {
        if (notif.template) { // System notification
            return <p>{notif.template.text.replace('{{name}}', 'crack').replace('{{streak}}', 'tu racha')}</p>;
        }
        // Community notification
        const actor = users.find(u => u.id === notif.actor_id);
        const actorName = actor?.name || 'Alguien';
        switch (notif.type) {
            case 'like': return <p><span className="font-bold">{actorName}</span> le ha dado like a tu publicación.</p>;
            case 'comment': return <p><span className="font-bold">{actorName}</span> ha comentado tu publicación.</p>;
            case 'follow': return <p><span className="font-bold">{actorName}</span> ha comenzado a seguirte.</p>;
            default: return 'Nueva notificación';
        }
    };
    
    const handleClick = (notif) => {
        onClose();
        const route = notif.template?.cta_route || (notif.type === 'follow' ? `/user/${notif.actor_id}` : '/community');
        navigate(route);
    }

    return (
        <AnimatePresence>
            <div className="fixed inset-0 bg-black/60 z-50" onClick={onClose}></div>
            <motion.div
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                className="fixed top-0 right-0 bottom-0 w-full max-w-md bg-card border-l border-border z-50 flex flex-col"
            >
                <div className="p-4 sm:p-6 border-b border-border flex justify-between items-center">
                    <h2 className="text-xl font-bold">Notificaciones</h2>
                    <Button variant="ghost" size="icon" onClick={onClose}><X className="w-5 h-5" /></Button>
                </div>

                <div className="flex-1 overflow-y-auto">
                    {notifications.length > 0 ? (
                        notifications.map(notif => (
                            <button key={notif.unique_id} onClick={() => handleClick(notif)} className="w-full text-left flex items-start gap-4 p-4 hover:bg-secondary transition-colors">
                                <div className="mt-1">{getIcon(notif)}</div>
                                <div className="flex-1 text-sm">
                                    {getText(notif)}
                                    <p className="text-xs text-muted-foreground">{new Date(notif.created_at || notif.scheduled_at).toLocaleString()}</p>
                                </div>
                                {notif.status === 'pending' && <div className="w-2 h-2 rounded-full bg-primary self-center"></div>}
                            </button>
                        ))
                    ) : (
                        <p className="text-center text-muted-foreground p-10">No tienes notificaciones.</p>
                    )}
                </div>
            </motion.div>
        </AnimatePresence>
    );
};

export default NotificationsSheet;