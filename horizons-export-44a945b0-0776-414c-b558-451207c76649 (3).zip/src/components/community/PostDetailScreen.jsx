import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { getPostDetails } from '@/lib/community';
import PostCard from '@/components/community/PostCard';
import LoadingScreen from '@/components/common/LoadingScreen';
import { toast } from '@/components/ui/use-toast';

const PostDetailScreen = () => {
    const { postId } = useParams();
    const navigate = useNavigate();
    const { user: currentUser } = useAuth();

    const [post, setPost] = useState(null);
    const [loading, setLoading] = useState(true);

    const refreshData = useCallback(() => {
        if (!currentUser || !postId) return;
        setLoading(true);
        try {
            const postData = getPostDetails(postId);
            if (!postData || !postData.id) {
                toast({ variant: 'destructive', title: 'Error', description: 'No se pudo encontrar la publicación.' });
                navigate('/community');
                return;
            }
            setPost(postData);
        } catch (error) {
            console.error("Error loading post:", error);
            toast({ variant: 'destructive', title: 'Error', description: 'Hubo un problema al cargar la publicación.' });
            navigate('/community');
        } finally {
            setLoading(false);
        }
    }, [postId, currentUser, navigate]);

    useEffect(() => {
        refreshData();
    }, [refreshData]);

    if (loading || !post) {
        return <LoadingScreen />;
    }

    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 max-w-2xl mx-auto">
            <div className="flex items-center gap-4">
                <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
                    <ArrowLeft />
                </Button>
                <h2 className="text-2xl font-bold">Publicación</h2>
            </div>
            
            <PostCard post={post} currentUser={currentUser} onRefresh={refreshData} />
        </motion.div>
    );
};

export default PostDetailScreen;