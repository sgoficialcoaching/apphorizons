import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { 
  LayoutDashboard, 
  MessageSquare, 
  Users, 
  Plus, 
  Trash2, 
  Search,
  LogOut,
  ShieldAlert,
  Hash,
  X,
  BadgeCheck
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';

const VALID_ROLES = ['Propietario', 'Superadministrador', 'Administrador', 'Miembro'];

const AdminDashboard = ({ isEmbedded = false, onClose }) => {
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('overview');
  
  // Data States
  const [stats, setStats] = useState({ users: 0, messages: 0, channels: 0 });
  const [channels, setChannels] = useState([]);
  const [messages, setMessages] = useState([]);
  const [usersList, setUsersList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  // Form States
  const [newChannelName, setNewChannelName] = useState('');
  const [newChannelCategory, setNewChannelCategory] = useState('General');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      // 1. Fetch Stats
      const { count: userCount } = await supabase.from('profiles').select('*', { count: 'exact', head: true });
      const { count: msgCount } = await supabase.from('messages').select('*', { count: 'exact', head: true });
      const { count: chanCount } = await supabase.from('channels').select('*', { count: 'exact', head: true });

      setStats({ users: userCount || 0, messages: msgCount || 0, channels: chanCount || 0 });

      // 2. Fetch Channels
      const { data: chanData } = await supabase.from('channels').select('*').order('created_at');
      setChannels(chanData || []);

      // 3. Fetch Recent Messages
      const { data: msgData } = await supabase.from('messages').select('*, channels(name)').order('created_at', { ascending: false }).limit(50);
      setMessages(msgData || []);

      // 4. Fetch Users (Profiles)
      const { data: userData } = await supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(100);
      setUsersList(userData || []);

    } catch (error) {
      console.error('Admin fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  // --- ACTIONS ---

  const handleCreateChannel = async () => {
    if (!newChannelName.trim()) return;

    const { error } = await supabase.from('channels').insert({
      name: newChannelName.toLowerCase().replace(/\s+/g, '-'),
      category: newChannelCategory,
      description: 'Canal creado por admin'
    });

    if (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Éxito', description: 'Canal creado correctamente' });
      setNewChannelName('');
      fetchData();
    }
  };

  const handleDeleteChannel = async (id) => {
    if (!window.confirm('¿Seguro que quieres eliminar este canal? Se borrarán todos los mensajes.')) return;
    
    // Delete messages first (if no cascade)
    await supabase.from('messages').delete().eq('channel_id', id);
    const { error } = await supabase.from('channels').delete().eq('id', id);

    if (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Canal eliminado' });
      fetchData();
    }
  };

  const handleDeleteMessage = async (id) => {
    const { error } = await supabase.from('messages').delete().eq('id', id);
    if (!error) {
      toast({ title: 'Mensaje eliminado' });
      setMessages(messages.filter(m => m.id !== id));
    }
  };

  const handleBanUser = async (userId, currentStatus) => {
    // Toggle ban status
    const newBanStatus = currentStatus ? null : new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(); // 1 year ban or null
    
    const { error } = await supabase.from('profiles').update({
        banned_until: newBanStatus
    }).eq('id', userId);

    if (error) {
        toast({ title: 'Error', description: 'No se pudo actualizar el usuario.', variant: 'destructive' });
    } else {
        toast({ title: currentStatus ? 'Usuario Desbloqueado' : 'Usuario Bloqueado' });
        // Update local state
        setUsersList(prev => prev.map(u => u.id === userId ? { ...u, banned_until: newBanStatus } : u));
    }
  };

  const handleUpdateRole = async (userId, newRole) => {
    const { error } = await supabase.from('profiles').update({
        role: newRole
    }).eq('id', userId);

    if (error) {
        toast({ title: 'Error', description: 'No se pudo cambiar el rol.', variant: 'destructive' });
    } else {
        toast({ title: 'Rol actualizado', description: `Usuario ahora es ${newRole}` });
         // Update local state
         setUsersList(prev => prev.map(u => u.id === userId ? { ...u, role: newRole } : u));
    }
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/');
  };

  // --- RENDERERS ---

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#2B2D31] p-6 rounded-xl border border-white/5 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-400 font-medium">Total Usuarios</h3>
            <Users className="w-5 h-5 text-blue-400" />
          </div>
          <p className="text-3xl font-bold text-white">{stats.users}</p>
        </div>
        <div className="bg-[#2B2D31] p-6 rounded-xl border border-white/5 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-400 font-medium">Mensajes Totales</h3>
            <MessageSquare className="w-5 h-5 text-green-400" />
          </div>
          <p className="text-3xl font-bold text-white">{stats.messages}</p>
        </div>
        <div className="bg-[#2B2D31] p-6 rounded-xl border border-white/5 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-400 font-medium">Canales Activos</h3>
            <Hash className="w-5 h-5 text-purple-400" />
          </div>
          <p className="text-3xl font-bold text-white">{stats.channels}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Messages */}
        <div className="bg-[#2B2D31] rounded-xl border border-white/5 overflow-hidden flex flex-col h-[500px]">
          <div className="p-4 border-b border-white/5 flex items-center justify-between">
            <h3 className="font-bold text-white flex items-center gap-2">
              <MessageSquare className="w-4 h-4" /> Últimos Mensajes
            </h3>
          </div>
          <ScrollArea className="flex-1">
             <div className="divide-y divide-white/5">
                {messages.map(msg => (
                  <div key={msg.id} className="p-4 hover:bg-white/5 transition-colors group">
                    <div className="flex justify-between items-start mb-1">
                        <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-white">{msg.author_name}</span>
                            <span className="text-xs text-gray-500">en #{msg.channels?.name || 'desconocido'}</span>
                        </div>
                        <span className="text-xs text-gray-600">{format(new Date(msg.created_at), 'dd/MM HH:mm')}</span>
                    </div>
                    <p className="text-gray-300 text-sm mb-2">{msg.content}</p>
                    <Button 
                      onClick={() => handleDeleteMessage(msg.id)}
                      variant="destructive" 
                      size="sm" 
                      className="h-6 text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      Eliminar
                    </Button>
                  </div>
                ))}
             </div>
          </ScrollArea>
        </div>

        {/* Quick Actions / Channels */}
        <div className="space-y-6">
            <div className="bg-[#2B2D31] p-6 rounded-xl border border-white/5">
                <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                    <Plus className="w-4 h-4" /> Crear Canal
                </h3>
                <div className="space-y-3">
                    <Input 
                        placeholder="Nombre del canal (ej: nutricion)" 
                        value={newChannelName}
                        onChange={(e) => setNewChannelName(e.target.value)}
                        className="bg-[#1E1F22] border-none text-white"
                    />
                    <select 
                        value={newChannelCategory}
                        onChange={(e) => setNewChannelCategory(e.target.value)}
                        className="w-full bg-[#1E1F22] text-white p-2 rounded-md text-sm outline-none"
                    >
                        <option value="General">General</option>
                        <option value="Entrenamiento">Entrenamiento</option>
                        <option value="Nutrición">Nutrición</option>
                        <option value="Off-Topic">Off-Topic</option>
                    </select>
                    <Button onClick={handleCreateChannel} className="w-full bg-[#5865F2] hover:bg-[#4752C4]">
                        Crear Canal
                    </Button>
                </div>
            </div>

            <div className="bg-[#2B2D31] rounded-xl border border-white/5 overflow-hidden flex flex-col h-[280px]">
               <div className="p-4 border-b border-white/5">
                  <h3 className="font-bold text-white">Canales Existentes</h3>
               </div>
               <ScrollArea className="flex-1">
                   <div className="divide-y divide-white/5">
                       {channels.map(channel => (
                           <div key={channel.id} className="p-3 flex items-center justify-between hover:bg-white/5">
                               <div className="flex items-center gap-2 text-gray-300">
                                   <Hash className="w-4 h-4 text-gray-500" />
                                   {channel.name}
                                   <span className="text-xs px-2 py-0.5 bg-black/40 rounded text-gray-500">{channel.category}</span>
                               </div>
                               <Button 
                                   onClick={() => handleDeleteChannel(channel.id)}
                                   variant="ghost" 
                                   size="icon" 
                                   className="h-8 w-8 text-red-400 hover:text-red-300 hover:bg-red-900/20"
                               >
                                   <Trash2 className="w-4 h-4" />
                               </Button>
                           </div>
                       ))}
                   </div>
               </ScrollArea>
            </div>
        </div>
      </div>
    </div>
  );

  const filteredUsers = usersList.filter(u => 
    (u.full_name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (u.email || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderUsers = () => (
    <div className="bg-[#2B2D31] rounded-xl border border-white/5 overflow-hidden flex flex-col h-[calc(100vh-200px)]">
        <div className="p-4 border-b border-white/5 flex items-center justify-between bg-[#232428]">
            <h3 className="font-bold text-white flex items-center gap-2">
                <Users className="w-4 h-4" /> Gestión de Roles y Usuarios
            </h3>
            <div className="relative w-72">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <Input 
                    placeholder="Buscar por email o nombre..." 
                    className="pl-9 bg-[#1E1F22] border-none text-white h-9 focus:ring-1 focus:ring-[#5865F2]" 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
        </div>
        <div className="overflow-auto flex-1">
            <table className="w-full text-left text-sm text-gray-400">
                <thead className="bg-[#1E1F22] text-xs uppercase font-medium sticky top-0 z-10">
                    <tr>
                        <th className="px-6 py-3">Usuario</th>
                        <th className="px-6 py-3">Email</th>
                        <th className="px-6 py-3">Rol Actual</th>
                        <th className="px-6 py-3">Asignar Rol</th>
                        <th className="px-6 py-3 text-right">Acciones</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                    {filteredUsers.map(user => (
                        <tr key={user.id} className="hover:bg-white/5 transition-colors">
                            <td className="px-6 py-4 font-medium text-white flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center text-white font-bold text-xs overflow-hidden">
                                    {user.avatar_url ? (
                                        <img src={user.avatar_url} alt="" className="w-full h-full object-cover" />
                                    ) : (
                                        (user.full_name || 'U').substring(0,2).toUpperCase()
                                    )}
                                </div>
                                {user.full_name || 'Sin nombre'}
                            </td>
                            <td className="px-6 py-4">{user.email}</td>
                            <td className="px-6 py-4">
                                <span className={`px-2 py-1 rounded text-xs border ${
                                    user.role === 'Propietario' ? 'bg-red-500/10 text-red-400 border-red-500/20' :
                                    user.role === 'Superadministrador' ? 'bg-orange-500/10 text-orange-400 border-orange-500/20' :
                                    user.role === 'Administrador' ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20' :
                                    'bg-gray-700/50 text-gray-300 border-gray-600/30'
                                }`}>
                                    {user.role || 'Miembro'}
                                </span>
                            </td>
                            <td className="px-6 py-4">
                                <select 
                                    className="bg-[#1E1F22] text-white text-xs p-1.5 rounded outline-none border border-white/10 focus:border-[#5865F2]"
                                    value={user.role || 'Miembro'}
                                    onChange={(e) => handleUpdateRole(user.id, e.target.value)}
                                    disabled={user.email === 'dim.ivelinov.d@gmail.com'}
                                >
                                    {VALID_ROLES.map(role => (
                                        <option key={role} value={role}>{role}</option>
                                    ))}
                                </select>
                            </td>
                            <td className="px-6 py-4 text-right">
                                {user.email !== 'dim.ivelinov.d@gmail.com' && (
                                    <Button 
                                        onClick={() => handleBanUser(user.id, user.banned_until)}
                                        variant="ghost" 
                                        size="sm"
                                        className={user.banned_until ? "text-green-400 hover:text-green-300 hover:bg-green-900/20" : "text-red-400 hover:text-red-300 hover:bg-red-900/20"}
                                    >
                                        {user.banned_until ? 'Desbloquear' : 'Bloquear'}
                                    </Button>
                                )}
                            </td>
                        </tr>
                    ))}
                    {filteredUsers.length === 0 && (
                        <tr>
                            <td colSpan="5" className="px-6 py-8 text-center text-gray-500">
                                No se encontraron usuarios con ese criterio.
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    </div>
  );

  return (
    <div className={`${isEmbedded ? 'h-full bg-[#2B2D31]' : 'min-h-screen bg-[#1E1F22]'} text-white font-sans flex flex-col md:flex-row`}>
       {/* Sidebar - Made lighter in embedded mode or same */}
       <aside className={`w-full md:w-64 flex-shrink-0 border-r border-white/5 ${isEmbedded ? 'bg-[#2B2D31]' : 'bg-[#2B2D31]'}`}>
          <div className="p-6">
              <h1 className="text-xl font-black italic tracking-tighter flex items-center gap-2">
                 <ShieldAlert className="text-[var(--neon-yellow)]" />
                 {isEmbedded ? 'ADMIN' : 'ADMIN PANEL'}
              </h1>
          </div>
          <nav className="px-3 space-y-1">
             <Button 
                variant="ghost" 
                className={`w-full justify-start ${activeTab === 'overview' ? 'bg-[#404249] text-white' : 'text-gray-400 hover:text-white hover:bg-[#35373C]'}`}
                onClick={() => setActiveTab('overview')}
             >
                <LayoutDashboard className="w-4 h-4 mr-3" />
                Resumen
             </Button>
             <Button 
                variant="ghost" 
                className={`w-full justify-start ${activeTab === 'users' ? 'bg-[#404249] text-white' : 'text-gray-400 hover:text-white hover:bg-[#35373C]'}`}
                onClick={() => setActiveTab('users')}
             >
                <BadgeCheck className="w-4 h-4 mr-3" />
                Roles y Usuarios
             </Button>
          </nav>
          
          <div className="absolute bottom-4 left-0 md:left-auto md:w-64 px-4 pb-4 md:pb-0">
             {!isEmbedded && (
                <Button onClick={handleLogout} variant="destructive" className="w-full justify-start">
                    <LogOut className="w-4 h-4 mr-3" />
                    Cerrar Sesión
                </Button>
             )}
          </div>
       </aside>

       {/* Content */}
       <main className={`flex-1 p-6 overflow-hidden flex flex-col ${isEmbedded ? 'bg-[#313338]' : 'h-screen'}`}>
          <header className="mb-6 flex justify-between items-center flex-shrink-0">
              <div>
                  <h2 className="text-2xl font-bold">
                      {activeTab === 'overview' && 'Panel de Control'}
                      {activeTab === 'users' && 'Gestión de Roles'}
                  </h2>
                  <p className="text-gray-400 text-sm">Bienvenido de nuevo, Admin.</p>
              </div>
              
              {isEmbedded ? (
                <Button onClick={onClose} variant="destructive" size="sm" className="gap-2">
                    <X className="w-4 h-4" /> Cerrar Panel
                </Button>
              ) : (
                <Button onClick={() => navigate('/')} variant="outline" className="border-white/20 text-white hover:bg-white/10">
                    Volver a la App
                </Button>
              )}
          </header>

          {loading ? (
              <div className="flex items-center justify-center h-64">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#5865F2]"></div>
              </div>
          ) : (
              <div className="flex-1 overflow-hidden">
                 {activeTab === 'overview' && renderOverview()}
                 {activeTab === 'users' && renderUsers()}
              </div>
          )}
       </main>
    </div>
  );
};

export default AdminDashboard;