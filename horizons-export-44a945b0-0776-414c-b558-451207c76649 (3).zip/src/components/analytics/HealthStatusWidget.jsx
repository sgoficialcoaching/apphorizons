import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, TrendingUp, AlertTriangle, Zap } from 'lucide-react';

const HealthStatusWidget = ({ trends }) => {
    const { adherence, strength, weight, energy } = trends || {};

    const getStatus = () => {
        if (!adherence || !strength || !weight || !energy) {
            return {
                title: 'Datos Insuficientes',
                description: 'Sigue registrando para obtener tu estado de salud.',
                Icon: AlertTriangle,
                color: 'text-yellow-400',
                bgColor: 'bg-yellow-400/10'
            };
        }

        const adherenceScore = adherence.change > -10 ? 1 : 0;
        const strengthScore = strength.value === 'ascendente' ? 1 : 0;
        const energyScore = energy.avg > 3 ? 1 : 0;
        
        const totalScore = adherenceScore + strengthScore + energyScore;

        if (totalScore === 3) {
            return {
                title: 'Estado Físico Óptimo',
                description: '¡Vas por el camino correcto! Tu adherencia, fuerza y energía están en un punto excelente.',
                Icon: ShieldCheck,
                color: 'text-green-400',
                bgColor: 'bg-green-400/10'
            };
        }
        if (totalScore >= 1) {
            return {
                title: 'En Progreso Sólido',
                description: 'Estás construyendo una buena base. Sigue así para alcanzar tu máximo potencial.',
                Icon: TrendingUp,
                color: 'text-blue-400',
                bgColor: 'bg-blue-400/10'
            };
        }
        return {
            title: 'Necesita Atención',
            description: 'Es un buen momento para re-evaluar. Revisa tu adherencia y descanso.',
            Icon: AlertTriangle,
            color: 'text-orange-400',
            bgColor: 'bg-orange-400/10'
        };
    };

    const status = getStatus();

    return (
        <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-6 rounded-xl flex items-center gap-6 ${status.bgColor} border border-dashed ${status.color.replace('text-', 'border-')}/30`}
        >
            <status.Icon className={`w-12 h-12 flex-shrink-0 ${status.color}`} />
            <div>
                <h3 className="text-xl font-bold">{status.title}</h3>
                <p className="text-muted-foreground mt-1">{status.description}</p>
            </div>
        </motion.div>
    );
};

export default HealthStatusWidget;