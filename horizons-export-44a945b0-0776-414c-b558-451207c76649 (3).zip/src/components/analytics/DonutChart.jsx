import React from 'react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';
import { motion } from 'framer-motion';

const CustomDonutChart = ({ data }) => {
    
  if (!data || data.length === 0) {
    return <div className="w-full h-full flex items-center justify-center text-muted-foreground">No hay datos disponibles.</div>;
  }
    
  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const { name, value, payload: itemPayload } = payload[0];
      const grams = itemPayload.grams || itemPayload.value;
      return (
        <div className="p-3 bg-background/80 backdrop-blur-sm text-foreground rounded-lg shadow-lg border border-border">
          <p className="font-bold text-sm">{`${name}: ${grams.toFixed(1)}`}{itemPayload.grams ? 'g' : ''}</p>
          {itemPayload.percentage && <p className="text-xs text-muted-foreground">{`${value.toFixed(1)}% del total`}</p>}
        </div>
      );
    }
    return null;
  };
  
  const totalValue = data.reduce((sum, entry) => sum + entry.value, 0);

  return (
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            dataKey={data[0]?.percentage ? "percentage" : "value"}
            nameKey="name"
            cx="50%"
            cy="50%"
            innerRadius="65%"
            outerRadius="85%"
            fill="#8884d8"
            paddingAngle={5}
            cornerRadius={8}
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color || `hsl(var(--primary) / ${1 - index*0.2})`} />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} wrapperStyle={{ outline: 'none' }}/>
          <Legend iconType="circle" wrapperStyle={{paddingTop: '20px'}} />
          <text
              x="50%"
              y="50%"
              textAnchor="middle"
              dominantBaseline="middle"
              className="fill-foreground text-2xl font-bold"
          >
              {totalValue.toFixed(0)}
          </text>
          <text
              x="50%"
              y="50%"
              dy="20"
              textAnchor="middle"
              className="fill-muted-foreground text-sm"
          >
              {data[0]?.percentage ? '% Total' : 'Volumen'}
          </text>
        </PieChart>
      </ResponsiveContainer>
  );
};

export default CustomDonutChart;