import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

const TrendCard = ({ title, trend, children }) => {
    const getTrendInfo = () => {
        if (!trend || !trend.value) {
            return {
                Icon: Minus,
                text: 'Datos insuficientes',
                color: 'text-muted-foreground'
            };
        }
        switch (trend.value) {
            case 'ascendente':
                return {
                    Icon: TrendingUp,
                    text: `En ascenso (${trend.change.toFixed(1)}%)`,
                    color: 'text-green-400'
                };
            case 'descendente':
                return {
                    Icon: TrendingDown,
                    text: `En descenso (${trend.change.toFixed(1)}%)`,
                    color: 'text-red-400'
                };
            default:
                return {
                    Icon: Minus,
                    text: 'Estable',
                    color: 'text-blue-400'
                };
        }
    };

    const { Icon, text, color } = getTrendInfo();

    return (
        <motion.div 
            className="glass-effect p-4 sm:p-6 rounded-xl flex flex-col"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ y: -5, transition: { duration: 0.2 } }}
        >
            <div className="flex justify-between items-start mb-2">
                <h3 className="text-lg font-bold">{title}</h3>
                <div className={`flex items-center gap-1.5 text-xs font-semibold ${color}`}>
                    <Icon className="w-4 h-4" />
                    <span>{text}</span>
                </div>
            </div>
            <div className="flex-grow h-64 -mx-4 -mb-4">
                {children}
            </div>
        </motion.div>
    );
};

export default TrendCard;