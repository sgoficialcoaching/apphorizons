import React from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';

const CustomLineChart = ({ data, lines, xAxisKey = 'date' }) => {

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="p-3 bg-background/80 backdrop-blur-sm text-foreground rounded-lg shadow-lg border border-border">
          <p className="font-bold mb-2 text-sm">{label}</p>
          {payload.map((p) => (
            <p key={p.name} style={{ color: p.color }} className="text-xs font-medium">
              {`${p.name}: ${p.value !== null ? Math.round(p.value) : 'N/A'}`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };
  
  const hasRightAxis = lines.some(line => line.yAxisId === 'right');

  return (
      <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 5, right: hasRightAxis ? 20 : 5, left: -20, bottom: 20 }}>
              <defs>
                  {lines.map((line) => (
                      <linearGradient key={line.key} id={`color${line.key}`} x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={line.color} stopOpacity={0.4}/>
                          <stop offset="95%" stopColor={line.color} stopOpacity={0}/>
                      </linearGradient>
                  ))}
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border) / 0.5)" />
              <XAxis dataKey={xAxisKey} stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis yAxisId="left" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} allowDecimals={false}/>
              {hasRightAxis && <YAxis yAxisId="right" orientation="right" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} allowDecimals={false} />}
              <Tooltip content={<CustomTooltip />} wrapperStyle={{ outline: 'none' }} />
              <Legend iconType="circle" verticalAlign="bottom" wrapperStyle={{paddingTop: '20px'}}/>
              {lines.map((line) => (
                  <Area 
                    key={line.key}
                    type="monotone" 
                    dataKey={line.key} 
                    name={line.name}
                    stroke={line.color} 
                    fill={`url(#color${line.key})`}
                    strokeWidth={2} 
                    dot={false}
                    activeDot={{ r: 5, strokeWidth: 2, stroke: line.color, fill: 'hsl(var(--background))' }}
                    yAxisId={line.yAxisId || 'left'}
                    connectNulls
                  />
              ))}
          </AreaChart>
      </ResponsiveContainer>
  );
};

export default CustomLineChart;