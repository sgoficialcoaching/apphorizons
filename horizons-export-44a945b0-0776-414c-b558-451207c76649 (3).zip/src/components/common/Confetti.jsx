import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const ConfettiPiece = ({ x, y, angle, color }) => {
  const variants = {
    initial: {
      x,
      y,
      opacity: 1,
      rotate: angle,
      scale: 1,
    },
    animate: {
      y: y + 200,
      x: x + (Math.random() - 0.5) * 100,
      opacity: 0,
      rotate: angle + (Math.random() - 0.5) * 360,
      scale: 0.5,
      transition: {
        duration: 2 + Math.random() * 2,
        ease: 'easeOut',
      },
    },
  };

  return (
    <motion.div
      variants={variants}
      initial="initial"
      animate="animate"
      className="absolute w-2 h-4"
      style={{ backgroundColor: color }}
    />
  );
};

const Confetti = ({ count = 100, onComplete, colors = ['#C9A227', '#FBBF24', '#F59E0B', '#FFFFFF'] }) => {
  const [pieces, setPieces] = useState([]);

  useEffect(() => {
    const newPieces = Array.from({ length: count }).map((_, index) => ({
      id: index,
      x: Math.random() * window.innerWidth,
      y: -20,
      angle: Math.random() * 360,
      color: colors[Math.floor(Math.random() * colors.length)],
    }));
    setPieces(newPieces);

    const timer = setTimeout(() => {
      setPieces([]);
      if (onComplete) onComplete();
    }, 4000); 

    return () => clearTimeout(timer);
  }, [count, onComplete, colors]);

  return (
    <div className="fixed inset-0 pointer-events-none z-[200]">
      <AnimatePresence>
        {pieces.map((piece) => (
          <ConfettiPiece key={piece.id} {...piece} />
        ))}
      </AnimatePresence>
    </div>
  );
};

export default Confetti;