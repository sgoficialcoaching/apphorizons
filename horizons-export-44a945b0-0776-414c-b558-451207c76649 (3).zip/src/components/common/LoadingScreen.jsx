import React from 'react';
import { motion } from 'framer-motion';

const LoadingScreen = ({ initialTransition = false }) => {
  if (initialTransition) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background z-[200]">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <motion.div
            animate={{
              scale: [1, 1.1, 1],
              rotate: [0, 180, 360],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="w-16 h-16 sm:w-20 sm:h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-primary to-amber-400 flex items-center justify-center shadow-lg"
          >
            <span className="text-2xl sm:text-3xl font-bold text-primary-foreground">SC</span>
          </motion.div>
          <p className="text-muted-foreground">Cargando...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="w-full h-full flex items-center justify-center p-16">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1, transition: { delay: 0.2 } }}
        className="text-center"
      >
        <motion.div
          animate={{
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-amber-400 flex items-center justify-center shadow-md"
        >
          <span className="text-xl font-bold text-primary-foreground">SC</span>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default LoadingScreen;