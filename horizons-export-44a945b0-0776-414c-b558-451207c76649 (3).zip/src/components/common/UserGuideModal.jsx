import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { X, Dumbbell, Apple, Trophy, Zap, Target, ArrowRight, Activity, BookOpen, Users, BarChart2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const GuideSection = ({ icon: Icon, title, children, delay, action }) => (
    <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay }}
        className="flex flex-col sm:flex-row gap-4 p-4 rounded-xl bg-black/40 border border-[#FF10F0]/20 hover:border-[#FF10F0]/50 transition-colors group"
    >
        <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-[#FF10F0]/10 flex items-center justify-center group-hover:bg-[#FF10F0]/20 transition-colors shadow-[0_0_15px_rgba(255,16,240,0.15)]">
            <Icon className="w-6 h-6 text-[#FF10F0]" />
        </div>
        <div className="flex-1">
            <h4 className="font-bold text-white mb-1 flex items-center gap-2 text-lg uppercase italic tracking-wide">
                {title}
            </h4>
            <p className="text-sm text-gray-400 leading-relaxed mb-3">
                {children}
            </p>
            {action && (
                <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={action.onClick}
                    className="text-xs h-8 bg-[#FF10F0]/10 text-[#FF10F0] hover:bg-[#FF10F0] hover:text-black border border-[#FF10F0]/30 transition-all"
                >
                    {action.label} <ArrowRight className="w-3 h-3 ml-1" />
                </Button>
            )}
        </div>
    </motion.div>
);

const UserGuideModal = ({ onClose }) => {
    const navigate = useNavigate();

    const handleNavigate = (path) => {
        onClose();
        navigate(path);
    };

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 safe-area-bottom bg-black/90 backdrop-blur-sm" onClick={onClose}>
            <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="w-full max-w-2xl max-h-[85vh] overflow-hidden bg-[#09090b] border border-[#FF10F0]/30 rounded-3xl shadow-[0_0_50px_rgba(255,16,240,0.15)] flex flex-col relative"
                onClick={e => e.stopPropagation()}
            >
                {/* Header */}
                <div className="relative h-32 shrink-0 overflow-hidden">
                    <img 
                        src="https://sergiconstance-9fn0dyoiqm.live-website.com/wp-content/uploads/2025/11/ShottingAtlas-157-scaled.jpg" 
                        alt="Guide Header"
                        className="absolute inset-0 w-full h-full object-cover opacity-50"
                        style={{ objectPosition: '50% 20%' }} 
                    />
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#09090b]" />
                    <div className="absolute bottom-4 left-6 right-6 flex justify-between items-end">
                        <div>
                             <div className="bg-[#FF10F0] text-black text-[10px] font-black px-2 py-1 rounded inline-block mb-2 shadow-[0_0_10px_rgba(255,16,240,0.6)]">
                                MANUAL DE USUARIO
                            </div>
                            <h2 className="text-3xl font-black italic text-white leading-none">
                                DOMINA LA APP
                            </h2>
                        </div>
                    </div>
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        className="absolute top-4 right-4 bg-black/50 hover:bg-[#FF10F0] hover:text-black transition-colors text-white rounded-full"
                        onClick={onClose}
                    >
                        <X className="w-5 h-5" />
                    </Button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar">
                    <GuideSection 
                        icon={Zap} 
                        title="El Dashboard" 
                        delay={0.1}
                        action={{ label: "Entendido", onClick: onClose }}
                    >
                        Tu centro de mando. Revisa tu "Rendimiento" diario, que combina tu estado de ánimo, racha y actividad. Usa las "Acciones Rápidas" para empezar a entrenar al instante.
                    </GuideSection>

                    <GuideSection 
                        icon={Dumbbell} 
                        title="Entrenamiento Boost" 
                        delay={0.2}
                        action={{ label: "Ir a Entrenamientos", onClick: () => handleNavigate('/boost') }}
                    >
                        Accede a la pestaña <strong>BOOST</strong> para ver tu programa. Selecciona tu nivel (Principiante, Intermedio, Avanzado). Usa el "Modo Entrenamiento" para registrar pesos y cronometrar descansos.
                    </GuideSection>

                    <GuideSection 
                        icon={Apple} 
                        title="Nutrición Inteligente" 
                        delay={0.3}
                        action={{ label: "Gestionar Nutrición", onClick: () => handleNavigate('/nutrition') }}
                    >
                        Configura tus macros en el Perfil. En el Dashboard, verás tus anillos de progreso. Usa el <strong>Escáner IA</strong> para registrar comidas con solo una foto o busca en la base de datos.
                    </GuideSection>

                    <GuideSection 
                        icon={BarChart2} 
                        title="Progreso y Récords" 
                        delay={0.4}
                        action={{ label: "Ver Analytics", onClick: () => handleNavigate('/analytics') }}
                    >
                        Tus mejores marcas (PRs) se guardan automáticamente. Consulta el widget de "Historial de Hitos" para ver tus levantamientos legendarios y días de mayor volumen.
                    </GuideSection>
                    
                    <GuideSection 
                        icon={Users} 
                        title="Comunidad y Retos" 
                        delay={0.5}
                        action={{ label: "Ir a Comunidad", onClick: () => handleNavigate('/community') }}
                    >
                        Únete a los retos activos para ganar puntos extra. Completar tu plan semanal aumenta tu racha y desbloquea insignias exclusivas. Comparte tu progreso.
                    </GuideSection>
                </div>

                {/* Footer */}
                <div className="p-6 pt-2 shrink-0 border-t border-[#FF10F0]/10 bg-[#09090b]">
                    <Button 
                        className="w-full h-12 font-black text-lg uppercase tracking-wider bg-[#FF10F0] text-black hover:bg-[#FF10F0]/90 shadow-[0_0_20px_rgba(255,16,240,0.4)] border-none"
                        onClick={onClose}
                    >
                        ¡Entendido, Vamos!
                    </Button>
                </div>
            </motion.div>
        </div>
    );
};

export default UserGuideModal;