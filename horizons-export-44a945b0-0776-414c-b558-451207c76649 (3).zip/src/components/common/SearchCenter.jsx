import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, X, User, Dumbbell, Apple, MessageSquare, Clock } from 'lucide-react';
import { performSearch, getRecentSearches, addRecentSearch } from '@/lib/search';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import PostCard from '@/components/community/PostCard';
import { toast } from '@/components/ui/use-toast';
import { checkSubscriptionStatus } from '@/lib/subscription';

const useDebounce = (value, delay) => {
    const [debouncedValue, setDebouncedValue] = useState(value);
    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedValue(value);
        }, delay);
        return () => {
            clearTimeout(handler);
        };
    }, [value, delay]);
    return debouncedValue;
};

const SearchCenter = ({ isOpen, onClose }) => {
    const [query, setQuery] = useState('');
    const [activeFilters, setActiveFilters] = useState([]);
    const [results, setResults] = useState([]);
    const [loading, setLoading] = useState(false);
    const [recentSearches, setRecentSearches] = useState([]);
    const { user: currentUser } = useAuth();
    const navigate = useNavigate();
    const inputRef = useRef(null);

    const subscriptionStatus = useMemo(() => currentUser ? checkSubscriptionStatus(currentUser.id) : null, [currentUser]);

    const debouncedQuery = useDebounce(query, 300);

    useEffect(() => {
        if (isOpen) {
            setRecentSearches(getRecentSearches());
            setTimeout(() => inputRef.current?.focus(), 100);
        } else {
            setQuery('');
            setResults([]);
            setActiveFilters([]);
        }
    }, [isOpen]);

    const handleSearch = useCallback(async () => {
        if (debouncedQuery.length < 1) {
            setResults([]);
            return;
        }
        setLoading(true);
        const searchResults = await performSearch(debouncedQuery, { types: activeFilters }, subscriptionStatus);
        setResults(searchResults);
        setLoading(false);
    }, [debouncedQuery, activeFilters, subscriptionStatus]);

    useEffect(() => {
        handleSearch();
    }, [handleSearch]);

    const toggleFilter = (filter) => {
        setActiveFilters(prev =>
            prev.includes(filter)
                ? prev.filter(f => f !== filter)
                : [...prev, filter]
        );
    };

    const handleResultClick = (path) => {
        addRecentSearch(query);
        navigate(path);
        onClose();
    };
    
    const filters = [
        { id: 'users', label: 'Usuarios', icon: User },
        { id: 'exercises', label: 'Ejercicios', icon: Dumbbell },
        { id: 'recipes', label: 'Recetas', icon: Apple },
        { id: 'posts', label: 'Posts', icon: MessageSquare },
    ];
    
    const users = useMemo(() => JSON.parse(localStorage.getItem('users') || '[]'), []);
    
    const renderResultItem = (item) => {
        switch (item.type) {
            case 'user':
                const avatar = item.data.avatar_url || `https://ui-avatars.com/api/?name=${item.data.name?.charAt(0)}&background=c9a227&color=0e0f11`;
                return (
                    <div onClick={() => handleResultClick(`/user/${item.data.id}`)} className="flex items-center gap-4 p-3 rounded-lg hover:bg-secondary cursor-pointer">
                        <img-replace alt={item.data.name} className="w-12 h-12 rounded-full object-cover" src={avatar} />
                        <div>
                            <p className="font-bold">{item.data.name}</p>
                            <p className="text-sm text-muted-foreground">{item.data.bio?.substring(0, 40) || 'Usuario de la comunidad'}{item.data.bio?.length > 40 && '...'}</p>
                        </div>
                    </div>
                );
            case 'exercise':
                return (
                    <div onClick={() => handleResultClick(`/exercise/${item.data.id}`)} className="p-3 rounded-lg hover:bg-secondary cursor-pointer">
                        <p className="font-bold">{item.data.name}</p>
                        <p className="text-sm text-muted-foreground capitalize">{item.data.muscleGroup}</p>
                    </div>
                );
            case 'recipe':
                return (
                    <div onClick={() => handleResultClick(`/recipe/${item.data.id}`)} className="flex items-center gap-4 p-3 rounded-lg hover:bg-secondary cursor-pointer">
                         <img-replace alt={item.data.name} className="w-16 h-16 rounded-lg object-cover" src="https://images.unsplash.com/photo-1540189549336-e6e99c3679fe" />
                        <div>
                            <p className="font-bold">{item.data.name}</p>
                            <p className="text-sm text-muted-foreground">{item.data.kcalPerServing} kcal</p>
                        </div>
                    </div>
                );
            case 'post':
                const postAuthor = users.find(u => u.id === item.data.user_id);
                if (!postAuthor) return null;
                return <div onClick={() => handleResultClick(`/post/${item.data.id}`)}><PostCard post={item.data} currentUser={currentUser} onRefresh={() => {}} isCompact={true} /></div>;
            default:
                return null;
        }
    };

    const EmptyState = () => {
        const filter = activeFilters[0];
        let text = "Intenta con otra búsqueda o cambia los filtros.";
        let cta = null;

        if (filter === 'users') text = "Invita a tus amigos o busca por su nombre completo.";
        if (filter === 'exercises') text = "No se encontró el ejercicio. ¿Quizás con otro nombre?";
        if (filter === 'recipes') {
            text = "No encontramos esa receta.";
            cta = <Button onClick={() => { navigate('/nutrition'); onClose(); }} className="mt-4">Añadir Receta</Button>;
        }
        if (filter === 'posts') {
            text = "No hay publicaciones que coincidan.";
            cta = <Button onClick={() => { navigate('/community'); onClose(); }} className="mt-4">Ir a la Comunidad</Button>;
        }

        return (
            <div className="text-center p-8 text-muted-foreground">
                <p className="font-semibold">No se encontraron resultados para "{query}"</p>
                <p className="text-sm mt-1">{text}</p>
                {cta}
            </div>
        );
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex justify-center items-start pt-4 sm:pt-16"
                    onClick={onClose}
                >
                    <motion.div
                        initial={{ scale: 0.95, y: -20 }}
                        animate={{ scale: 1, y: 0 }}
                        exit={{ scale: 0.95, y: -20 }}
                        className="bg-background rounded-2xl w-full max-w-2xl h-full sm:h-auto sm:max-h-[80vh] flex flex-col glass-effect"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="p-4 border-b border-border">
                            <div className="relative">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                                <input
                                    ref={inputRef}
                                    type="text"
                                    placeholder="Buscar usuarios, ejercicios, recetas..."
                                    value={query}
                                    onChange={(e) => setQuery(e.target.value)}
                                    className="w-full bg-input rounded-lg pl-10 pr-4 py-2"
                                />
                            </div>
                            <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
                                {filters.map(filter => (
                                    <Button
                                        key={filter.id}
                                        variant={activeFilters.includes(filter.id) ? 'default' : 'secondary'}
                                        size="sm"
                                        onClick={() => toggleFilter(filter.id)}
                                        className="flex-shrink-0"
                                    >
                                        <filter.icon className="w-4 h-4 mr-2" />
                                        {filter.label}
                                    </Button>
                                ))}
                            </div>
                        </div>

                        <div className="flex-1 overflow-y-auto p-4 space-y-4">
                            {loading ? (
                                <div className="text-center p-8">Cargando...</div>
                            ) : results.length > 0 ? (
                                results.slice(0, 20).map(item => (
                                    <div key={item.id}>{renderResultItem(item)}</div>
                                ))
                            ) : debouncedQuery.length > 0 ? (
                                <EmptyState />
                            ) : recentSearches.length > 0 ? (
                                <div className="space-y-2">
                                    <h3 className="text-sm font-semibold text-muted-foreground px-2">Búsquedas Recientes</h3>
                                    {recentSearches.map((term, i) => (
                                        <div key={i} onClick={() => setQuery(term)} className="flex items-center gap-3 p-2 rounded-lg hover:bg-secondary cursor-pointer">
                                            <Clock className="w-4 h-4 text-muted-foreground" />
                                            <p>{term}</p>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-center p-8 text-muted-foreground">
                                    <p>Busca cualquier cosa en la app.</p>
                                </div>
                            )}
                        </div>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};

export default SearchCenter;