import React from 'react';
import { AlertTriangle } from 'lucide-react';

const BoostiesWarning = () => {
  return (
    <div className="mt-8 p-4 bg-secondary/50 rounded-lg text-center border border-dashed border-yellow-500/50">
      <div className="flex items-center justify-center gap-2">
        <AlertTriangle className="w-5 h-5 text-yellow-500" />
        <h4 className="font-bold text-yellow-500">Aviso sobre el Uso de Boosties</h4>
      </div>
      <p className="text-xs text-muted-foreground mt-2 max-w-2xl mx-auto">
        Si se detecta la obtención de Boosties de forma alterada, desproporcionada o mediante la finalización de entrenamientos/nutrición no realizados, se solicitarán detalles a los perfiles que incumplan las normas de la comunidad para asegurar un juego limpio.
      </p>
    </div>
  );
};

export default BoostiesWarning;