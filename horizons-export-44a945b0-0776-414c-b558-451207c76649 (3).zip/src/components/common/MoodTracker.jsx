import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Zap } from 'lucide-react';

const EnergyOrb = ({ level, isActive, isSelected, onHover, onClick }) => {
    const intensity = level / 5;
    const baseColor = "hsl(var(--primary))";
    const activeColor = `hsl(45, 100%, 50%)`;

    return (
        <motion.div
            className="w-12 h-12 flex items-center justify-center cursor-pointer"
            onMouseEnter={() => onHover(level)}
            onClick={() => onClick(level)}
            whileHover={{ scale: 1.1 }}
            transition={{ type: 'spring', stiffness: 300 }}
        >
            <div className="relative w-full h-full">
                <motion.div
                    className="absolute inset-0 rounded-full border-2 border-secondary"
                    animate={{ borderColor: isSelected ? baseColor : 'hsl(var(--secondary))' }}
                />
                <AnimatePresence>
                    {isActive && (
                        <motion.div
                            className="absolute inset-0 rounded-full"
                            style={{
                                background: `radial-gradient(circle, ${activeColor}, ${baseColor})`,
                            }}
                            initial={{ opacity: 0, scale: 0.5 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.5 }}
                        />
                    )}
                </AnimatePresence>
                 {isSelected && (
                    <motion.div
                        className="absolute inset-0 rounded-full border-2 border-primary"
                        animate={{
                            scale: [1, 1.2, 1],
                            opacity: [0, 0.5, 0],
                        }}
                        transition={{
                            duration: 1.5,
                            repeat: Infinity,
                            ease: "easeInOut",
                        }}
                    />
                )}
            </div>
        </motion.div>
    );
};

const MoodTracker = ({ onMoodSubmit }) => {
  const [hoveredLevel, setHoveredLevel] = useState(0);
  const [selectedLevel, setSelectedLevel] = useState(0);

  const labels = ["Vacío", "Bajo", "Normal", "Bien", "¡A tope!"];

  const handleSelect = (level) => {
    setSelectedLevel(level);
  };
  
  const handleSubmit = () => {
    if (selectedLevel > 0) {
      onMoodSubmit(selectedLevel);
    }
  };

  return (
    <motion.div 
      className="glass-effect rounded-xl p-6 text-center"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20, transition: { duration: 0.3 } }}
    >
      <h3 className="text-2xl font-bold mb-2">¿Cómo está tu energía hoy?</h3>
      <p className="text-sm text-muted-foreground mb-6">Tu respuesta nos ayuda a ajustar el día.</p>
      
      <div 
        className="flex justify-center space-x-3 mb-6"
        onMouseLeave={() => setHoveredLevel(selectedLevel)}
      >
        {[1, 2, 3, 4, 5].map((level) => (
          <EnergyOrb
            key={level}
            level={level}
            isActive={hoveredLevel >= level}
            isSelected={selectedLevel === level}
            onHover={setHoveredLevel}
            onClick={handleSelect}
          />
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.p
          key={hoveredLevel}
          className="text-lg font-semibold text-primary h-7"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
        >
          {labels[(hoveredLevel > 0 ? hoveredLevel : selectedLevel) - 1] || 'Selecciona un nivel'}
        </motion.p>
      </AnimatePresence>
      
      <Button 
        onClick={handleSubmit} 
        disabled={selectedLevel === 0} 
        className="w-full mt-4 btn-primary"
        size="lg"
      >
        <Zap className="w-4 h-4 mr-2" />
        Confirmar Energía
      </Button>
    </motion.div>
  );
};

export default MoodTracker;