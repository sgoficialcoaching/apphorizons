import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Star, Dumbbell, Utensils } from 'lucide-react';
import { Button } from '@/components/ui/button';

const BoostsWelcomeModal = ({ onClose }) => {
  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="bg-card border border-border rounded-2xl p-8 max-w-md w-full relative"
        >
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="absolute top-4 right-4"
          >
            <X className="w-5 h-5" />
          </Button>

          <div className="text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-primary to-amber-400 flex items-center justify-center">
              <Star className="w-8 h-8 text-primary-foreground" />
            </div>
            <h2 className="text-2xl font-bold gradient-text mb-2">¡Bienvenido a los Boosts!</h2>
            <p className="text-muted-foreground mb-6">
              Los "Boosts" son tu recompensa por ser una leyenda. Gánalos y canjéalos por premios increíbles.
            </p>
          </div>

          <div className="space-y-4 mb-8">
            <div className="flex items-center gap-4 p-3 bg-secondary rounded-lg">
              <div className="w-10 h-10 flex-shrink-0 bg-primary/10 rounded-lg flex items-center justify-center">
                <Dumbbell className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="font-semibold">Completa tu entreno diario</p>
                <p className="text-sm font-bold text-primary">+30 Boosts</p>
              </div>
            </div>
            <div className="flex items-center gap-4 p-3 bg-secondary rounded-lg">
              <div className="w-10 h-10 flex-shrink-0 bg-primary/10 rounded-lg flex items-center justify-center">
                <Utensils className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="font-semibold">Completa tu nutrición diaria</p>
                <p className="text-sm font-bold text-primary">+30 Boosts</p>
              </div>
            </div>
          </div>

          <Button onClick={onClose} className="w-full btn-primary">
            ¡Entendido!
          </Button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default BoostsWelcomeModal;