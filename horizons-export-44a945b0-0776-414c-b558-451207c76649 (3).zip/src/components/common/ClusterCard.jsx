import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';

const ClusterCard = ({ title, icon: Icon, action, imageUrl, imageAlt, backgroundPosition = 'center' }) => {
    return (
        <motion.div
            whileHover={{ y: -8, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="group relative h-[400px] w-full overflow-hidden rounded-[2.5rem] cursor-pointer bg-[#121214] border border-white/5 shadow-2xl"
            onClick={action}
        >
            {/* Background Image with Gradient Overlay */}
            <div className="absolute inset-0 z-0">
                <img 
                    src={imageUrl} 
                    alt={imageAlt} 
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-60 group-hover:opacity-40"
                    style={{ objectPosition: backgroundPosition }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent" />
            </div>

            {/* Content */}
            <div className="absolute inset-0 z-10 flex flex-col justify-end p-8">
                <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/20 backdrop-blur-md border border-primary/30 text-primary transition-colors group-hover:bg-primary group-hover:text-black">
                    <Icon size={28} strokeWidth={2} />
                </div>
                
                <h3 className="font-bebas text-4xl text-white mb-2 tracking-wide group-hover:text-primary transition-colors">
                    {title}
                </h3>
                
                <div className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-muted-foreground group-hover:text-white transition-colors">
                    <span>Explorar</span>
                    <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
                </div>
            </div>

            {/* Decorative Border Glow on Hover */}
            <div className="absolute inset-0 rounded-[2.5rem] border-2 border-transparent transition-colors duration-300 group-hover:border-primary/30 pointer-events-none" />
        </motion.div>
    );
};

export default ClusterCard;