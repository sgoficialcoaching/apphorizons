import React, { useCallback } from 'react';
    import { motion, AnimatePresence } from 'framer-motion';
    import { ShoppingCart as ShoppingCartIcon, X } from 'lucide-react';
    import { useCart } from '@/hooks/useCart';
    import { Button } from '@/components/ui/button';
    import { initializeCheckout } from '@/api/EcommerceApi';
    import { useToast } from '@/components/ui/use-toast';
    
    const ShoppingCart = ({ isCartOpen, setIsCartOpen }) => {
      const { toast } = useToast();
      const { cartItems, removeFromCart, updateQuantity, getCartTotal, clearCart } = useCart();
    
      const handleCheckout = useCallback(async () => {
        if (cartItems.length === 0) {
          toast({
            title: 'Your cart is empty',
            description: 'Add some products to your cart before checking out.',
            variant: 'destructive',
          });
          return;
        }
    
        try {
          const items = cartItems.map(item => ({
            variant_id: item.variant.id,
            quantity: item.quantity,
          }));
    
          const successUrl = `${window.location.origin}/success`;
          const cancelUrl = window.location.href;
    
          const { url } = await initializeCheckout({ items, successUrl, cancelUrl });
    
          clearCart();
          window.location.href = url;
        } catch (error) {
          toast({
            title: 'Checkout Error',
            description: 'There was a problem initializing checkout. Please try again.',
            variant: 'destructive',
          });
        }
      }, [cartItems, clearCart, toast]);
    
      return (
        <AnimatePresence>
          {isCartOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 z-[100]"
              onClick={() => setIsCartOpen(false)}
            >
              <motion.div
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                className="absolute right-0 top-0 h-full w-full max-w-md bg-card shadow-2xl flex flex-col"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center justify-between p-4 sm:p-6 border-b border-border">
                  <h2 className="text-xl sm:text-2xl font-bold text-foreground">Shopping Cart</h2>
                  <Button onClick={() => setIsCartOpen(false)} variant="ghost" size="icon" className="text-muted-foreground hover:bg-secondary">
                    <X />
                  </Button>
                </div>
                <div className="flex-grow p-4 sm:p-6 overflow-y-auto space-y-4">
                  {cartItems.length === 0 ? (
                    <div className="text-center text-muted-foreground h-full flex flex-col items-center justify-center">
                      <ShoppingCartIcon size={48} className="mb-4" />
                      <p>Your cart is empty.</p>
                    </div>
                  ) : (
                    cartItems.map(item => (
                      <div key={item.variant.id} className="flex items-center gap-4 bg-secondary/50 p-3 rounded-lg">
                        <img src={item.product.image} alt={item.product.title} className="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded-md" />
                        <div className="flex-grow">
                          <h3 className="font-semibold text-foreground text-sm sm:text-base">{item.product.title}</h3>
                          <p className="text-xs sm:text-sm text-muted-foreground">{item.variant.title}</p>
                          <p className="text-sm text-primary font-bold">
                            {item.variant.sale_price_formatted || item.variant.price_formatted}
                          </p>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <div className="flex items-center border border-border rounded-md">
                            <Button onClick={() => updateQuantity(item.variant.id, Math.max(1, item.quantity - 1))} size="sm" variant="ghost" className="px-2 text-foreground hover:bg-background h-8">-</Button>
                            <span className="px-2 text-foreground text-sm">{item.quantity}</span>
                            <Button onClick={() => updateQuantity(item.variant.id, item.quantity + 1)} size="sm" variant="ghost" className="px-2 text-foreground hover:bg-background h-8">+</Button>
                          </div>
                          <Button onClick={() => removeFromCart(item.variant.id)} size="sm" variant="ghost" className="text-red-500 hover:text-red-400 text-xs">Remove</Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
                {cartItems.length > 0 && (
                  <div className="p-4 sm:p-6 border-t border-border">
                    <div className="flex justify-between items-center mb-4 text-foreground">
                      <span className="text-md sm:text-lg font-medium">Total</span>
                      <span className="text-xl sm:text-2xl font-bold">{getCartTotal()}</span>
                    </div>
                    <Button onClick={handleCheckout} className="w-full btn-primary py-3 text-md sm:text-lg">
                      Proceed to Checkout
                    </Button>
                  </div>
                )}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      );
    };
    
    export default ShoppingCart;