import React from 'react';
import { motion } from 'framer-motion';
import { Dumbbell, Heart, Coffee, Rocket } from 'lucide-react';

const WeekView = ({ currentDate, schedule, onDayClick, boostedDay }) => {
    const startOfWeek = new Date(currentDate);
    const dayOfWeek = currentDate.getDay();
    const diff = currentDate.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1);
    startOfWeek.setDate(diff);

    const days = Array.from({ length: 7 }).map((_, i) => {
        const date = new Date(startOfWeek);
        date.setDate(startOfWeek.getDate() + i);
        return date;
    });

    const getDayInfo = (dayIndex) => {
        if (!schedule) return { type: 'Rest', activityName: 'Descanso', icon: <Coffee className="w-5 h-5" /> };
        const activity = schedule[dayIndex % 7] || 'Rest';
        if (activity.toLowerCase().includes('cardio')) {
            return { type: 'Cardio', activityName: activity, icon: <Heart className="w-5 h-5" /> };
        } else if (activity.toLowerCase().includes('rest')) {
            return { type: 'Rest', activityName: 'Descanso', icon: <Coffee className="w-5 h-5" /> };
        } else {
            return { type: 'Workout', activityName: activity, icon: <Dumbbell className="w-5 h-5" /> };
        }
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-7 gap-2">
            {days.map((date, index) => {
                const dayInfo = getDayInfo(index);
                const isToday = new Date().toDateString() === date.toDateString();
                const isBoosted = boostedDay === date.toISOString().split('T')[0];

                return (
                    <motion.div
                        key={date.toISOString()}
                        onClick={() => dayInfo.type !== 'Rest' && onDayClick(date)}
                        className={`relative rounded-lg p-3 cursor-pointer transition-all
                            ${isToday ? 'bg-primary text-primary-foreground shadow-lg' : 'bg-secondary hover:bg-primary/10'}
                            ${dayInfo.type === 'Rest' ? 'opacity-60 cursor-not-allowed' : ''}
                            ${isBoosted ? 'ring-2 ring-fuchsia-500' : ''}
                        `}
                        whileHover={{ y: dayInfo.type !== 'Rest' ? -3 : 0 }}
                    >
                        {isBoosted && <Rocket className="absolute top-2 right-2 w-4 h-4 text-fuchsia-500" />}
                        <div className="flex justify-between items-center">
                            <span className="text-xs font-bold">{date.toLocaleDateString('es-ES', { weekday: 'short' }).toUpperCase()}</span>
                            <span className={`text-xl font-black ${isToday ? 'text-black' : ''}`}>{date.getDate()}</span>
                        </div>
                        <div className="mt-4 flex flex-col items-start gap-2">
                            {dayInfo.icon}
                            <span className="text-sm font-semibold truncate w-full">{dayInfo.activityName}</span>
                        </div>
                    </motion.div>
                );
            })}
        </div>
    );
};

export default WeekView;