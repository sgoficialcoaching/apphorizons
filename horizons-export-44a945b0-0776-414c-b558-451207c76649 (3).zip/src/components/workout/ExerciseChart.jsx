import React from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const ExerciseChart = ({ historyData }) => {
    // Mock data generator if history is empty
    const data = historyData?.length > 0 ? historyData : [
        { session: 'S1', weight: 40 },
        { session: 'S2', weight: 42.5 },
        { session: 'S3', weight: 42.5 },
        { session: 'S4', weight: 45 },
        { session: 'S5', weight: 47.5 }, // Current goal?
    ];

    return (
        <div className="h-24 w-full mt-2 bg-black/20 rounded-lg border border-white/5 p-2 relative overflow-hidden">
             <div className="absolute top-2 left-3 z-10">
                <p className="text-[9px] font-bold text-muted-foreground uppercase">Progreso Estimado</p>
            </div>
            <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data}>
                    <defs>
                        <linearGradient id="colorWeight" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#007AFF" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#007AFF" stopOpacity={0}/>
                        </linearGradient>
                    </defs>
                    <Area 
                        type="monotone" 
                        dataKey="weight" 
                        stroke="#007AFF" 
                        strokeWidth={2}
                        fillOpacity={1} 
                        fill="url(#colorWeight)" 
                    />
                </AreaChart>
            </ResponsiveContainer>
        </div>
    );
};

export default ExerciseChart;