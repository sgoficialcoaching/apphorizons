import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const CreateExerciseModal = ({ onClose, onSubmit, muscleGroups }) => {
    const [name, setName] = useState('');
    const [muscleGroup, setMuscleGroup] = useState(muscleGroups[0] || '');
    const [prMetric, setPrMetric] = useState('peso');

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!name.trim() || !muscleGroup) {
            toast({
                title: 'Campos incompletos',
                description: 'Por favor, introduce un nombre y un grupo muscular.',
                variant: 'destructive',
            });
            return;
        }
        onSubmit({
            name,
            muscleGroup,
            prMetric,
            videoUrl: '', // Default empty video URL
            rest_time_sec: 90, // Default rest time
        });
    };

    return (
        <AnimatePresence>
            <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
                <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="bg-card border border-border rounded-2xl max-w-lg w-full relative flex flex-col"
                >
                    <div className="p-6 border-b border-border flex justify-between items-center">
                        <h2 className="text-xl font-bold">Crear Nuevo Ejercicio</h2>
                        <Button variant="ghost" size="icon" onClick={onClose}><X className="w-5 h-5" /></Button>
                    </div>

                    <form onSubmit={handleSubmit} className="p-6 space-y-4">
                        <div>
                            <label className="text-sm font-medium text-muted-foreground mb-2 block">Nombre del Ejercicio</label>
                            <input
                                type="text"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                className="w-full px-4 py-3 bg-input border-border rounded-xl"
                                placeholder="Ej: Press de Banca Inclinado"
                                required
                            />
                        </div>
                        <div>
                            <label className="text-sm font-medium text-muted-foreground mb-2 block">Grupo Muscular</label>
                            <select
                                value={muscleGroup}
                                onChange={(e) => setMuscleGroup(e.target.value)}
                                className="w-full px-4 py-3 bg-input border-border rounded-xl capitalize"
                                required
                            >
                                {muscleGroups.map(group => (
                                    <option key={group} value={group} className="capitalize">{group}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="text-sm font-medium text-muted-foreground mb-2 block">Métrica de PR</label>
                            <select
                                value={prMetric}
                                onChange={(e) => setPrMetric(e.target.value)}
                                className="w-full px-4 py-3 bg-input border-border rounded-xl"
                                required
                            >
                                <option value="peso">Peso Máximo</option>
                                <option value="reps">Máximas Repeticiones</option>
                                <option value="1RM">1RM (Estimado)</option>
                            </select>
                        </div>
                        <Button type="submit" className="w-full btn-primary py-3">
                            <Save className="w-4 h-4 mr-2" />
                            Guardar Ejercicio
                        </Button>
                    </form>
                </motion.div>
            </div>
        </AnimatePresence>
    );
};

export default CreateExerciseModal;