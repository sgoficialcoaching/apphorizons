import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Minus, Plus, X, Minimize2, Maximize2, SkipForward } from 'lucide-react';
import { cn } from '@/lib/utils';

const RestTimer = ({ endTime, minimized, onMinimize, onClose, onAdd }) => {
    const [timeLeft, setTimeLeft] = useState(0);

    useEffect(() => {
        const timer = setInterval(() => {
            const remaining = Math.max(0, Math.ceil((endTime - Date.now()) / 1000));
            setTimeLeft(remaining);
            if (remaining <= 0) {
                 if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
                clearInterval(timer);
            }
        }, 100);
        return () => clearInterval(timer);
    }, [endTime]);

    const formatTime = (seconds) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    };

    // Minimized View (Floating Bubble)
    if (minimized) {
        return (
            <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                className="fixed bottom-28 right-4 z-[60]"
                drag
                dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
            >
                <div 
                    className="bg-black/90 border border-[var(--neon-blue)] rounded-full h-14 min-w-[120px] px-5 flex items-center justify-between gap-3 shadow-[0_0_20px_rgba(0,122,255,0.3)] cursor-pointer backdrop-blur-md"
                    onClick={onMinimize}
                >
                    <div className="w-2.5 h-2.5 rounded-full bg-[var(--neon-blue)] animate-pulse shadow-[0_0_10px_var(--neon-blue)]" />
                    <span className="font-mono font-black text-xl tabular-nums text-white tracking-tight">
                        {formatTime(timeLeft)}
                    </span>
                </div>
            </motion.div>
        );
    }

    // Full View (Optimized for Mobile)
    return (
        <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 400, damping: 40 }}
            className="fixed bottom-0 left-0 right-0 z-[60]"
        >
            <div className="mx-auto bg-[#0d0d0f] border-t border-[var(--neon-blue)]/30 shadow-[0_-10px_50px_rgba(0,0,0,0.8)] rounded-t-3xl p-5 pb-8 safe-area-bottom">
                
                {/* Header */}
                <div className="flex items-center justify-between mb-4">
                     <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={onMinimize} 
                        className="h-8 w-8 text-muted-foreground hover:text-white bg-white/5 rounded-full"
                    >
                        <Minimize2 className="w-4 h-4" />
                    </Button>
                    
                    <div className="flex flex-col items-center">
                        <div className="w-12 h-1 bg-white/10 rounded-full mb-2" />
                        <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--neon-blue)]">Descanso</span>
                    </div>

                    <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={onClose} 
                        className="h-8 w-8 text-muted-foreground hover:text-red-400 bg-white/5 rounded-full"
                    >
                        <X className="w-4 h-4" />
                    </Button>
                </div>

                {/* Big Timer */}
                <div className="text-center mb-6 relative">
                     {/* Background Ring Effect */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-40 h-40 bg-[var(--neon-blue)]/5 rounded-full blur-2xl pointer-events-none" />
                    
                    <div className={cn(
                        "text-7xl font-black font-mono tracking-tighter tabular-nums text-white drop-shadow-[0_0_15px_rgba(0,122,255,0.5)] transition-colors duration-300",
                        timeLeft < 10 && "text-red-500 drop-shadow-[0_0_15px_rgba(239,68,68,0.5)]"
                    )}>
                        {formatTime(timeLeft)}
                    </div>
                    {timeLeft === 0 ? (
                         <p className="text-[var(--neon-blue)] font-bold mt-2 animate-bounce uppercase tracking-wide text-xs">¡Vuelve a la barra!</p>
                    ) : (
                        <p className="text-muted-foreground/50 text-[10px] font-bold uppercase tracking-widest mt-1">Recuperando Energía</p>
                    )}
                </div>

                {/* Controls - Grid Layout for Mobile Overflow Protection */}
                <div className="grid grid-cols-3 gap-3 w-full max-w-sm mx-auto">
                    <Button 
                        variant="secondary" 
                        className="h-12 bg-white/5 hover:bg-white/10 border border-white/5 font-bold text-xs"
                        onClick={() => onAdd(-10)}
                    >
                        -10s
                    </Button>
                    <Button 
                        className="h-12 bg-[var(--neon-blue)] text-black font-black uppercase tracking-wider text-xs shadow-[0_0_15px_rgba(0,122,255,0.4)] hover:bg-white border-none"
                        onClick={onClose}
                    >
                        Saltar
                    </Button>
                    <Button 
                        variant="secondary" 
                        className="h-12 bg-white/5 hover:bg-white/10 border border-white/5 font-bold text-xs"
                        onClick={() => onAdd(30)}
                    >
                        +30s
                    </Button>
                </div>
            </div>
        </motion.div>
    );
};

export default RestTimer;