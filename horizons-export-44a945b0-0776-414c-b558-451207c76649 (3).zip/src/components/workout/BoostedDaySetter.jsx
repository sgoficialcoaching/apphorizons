import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Rocket, Calendar as CalendarIcon, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { setBoostedDay, getBoostedDay } from '@/lib/database';

const Calendar = ({ currentDate, onDateSelect, setViewDate }) => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);

    const startDay = firstDayOfMonth.getDay() === 0 ? 6 : firstDayOfMonth.getDay() - 1;
    const daysInMonth = lastDayOfMonth.getDate();

    const days = Array.from({ length: startDay }, () => null).concat(
        Array.from({ length: daysInMonth }, (_, i) => new Date(year, month, i + 1))
    );

    const weekdays = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

    return (
        <div className="bg-card p-4 rounded-lg w-full max-w-sm mx-auto border border-white/10">
            <div className="flex justify-between items-center mb-4">
                <Button variant="ghost" size="icon" onClick={() => setViewDate(new Date(year, month - 1, 1))}>
                    <ChevronLeft className="w-4 h-4" />
                </Button>
                <h3 className="text-lg font-bold text-center capitalize">
                    {currentDate.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })}
                </h3>
                <Button variant="ghost" size="icon" onClick={() => setViewDate(new Date(year, month + 1, 1))}>
                    <ChevronRight className="w-4 h-4" />
                </Button>
            </div>
            <div className="grid grid-cols-7 gap-1 text-center text-xs font-bold text-muted-foreground mb-2">
                {weekdays.map(day => <div key={day}>{day}</div>)}
            </div>
            <div className="grid grid-cols-7 gap-1">
                {days.map((day, index) => {
                    if (!day) return <div key={`empty-${index}`} className="h-10 rounded-md"></div>;
                    
                    const isToday = day.toDateString() === new Date().toDateString();
                    return (
                        <motion.div
                            key={day.toISOString()}
                            onClick={() => onDateSelect(day)}
                            className={`h-10 p-1.5 rounded-md cursor-pointer flex items-center justify-center text-sm font-semibold transition-colors bg-secondary hover:bg-primary hover:text-primary-foreground ${isToday ? 'ring-2 ring-primary' : ''}`}
                            whileHover={{ scale: 1.1 }}
                        >
                            {day.getDate()}
                        </motion.div>
                    );
                })}
            </div>
        </div>
    );
};

const CountdownDisplay = ({ boostedDay, onClear }) => {
    const targetDate = new Date(boostedDay.date);
    const now = new Date();
    targetDate.setHours(0,0,0,0);
    now.setHours(0,0,0,0);

    const diffTime = targetDate - now;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    useEffect(() => {
        if (diffDays < 0) {
            onClear();
        }
    }, [diffDays, onClear]);

    if (diffDays < 0) {
        return null;
    }

    const particles = Array.from({ length: 20 });

    return (
        <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative text-center p-6 bg-gradient-to-br from-primary/10 to-background rounded-2xl overflow-hidden border border-primary/20"
        >
            <div className="absolute inset-0 pointer-events-none">
                {particles.map((_, i) => (
                    <motion.div
                        key={i}
                        className="absolute rounded-full bg-primary/50"
                        initial={{ 
                            x: `${Math.random() * 100}%`, 
                            y: `${Math.random() * 100}%`,
                            scale: Math.random() * 0.5 + 0.2,
                            opacity: 0
                        }}
                        animate={{
                            y: ['100%', '-20%'],
                            opacity: [1, 0],
                        }}
                        transition={{
                            duration: Math.random() * 5 + 5,
                            repeat: Infinity,
                            delay: Math.random() * 5,
                            ease: "linear"
                        }}
                        style={{
                            width: `${Math.random() * 4 + 2}px`,
                            height: `${Math.random() * 4 + 2}px`,
                        }}
                    />
                ))}
            </div>

            <Button variant="ghost" size="icon" className="absolute top-2 right-2 z-10" onClick={onClear}>
                <X className="w-4 h-4" />
            </Button>
            
            <div className="relative z-10">
                <motion.div
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
                >
                    <Rocket className="w-12 h-12 mx-auto text-primary mb-3 drop-shadow-[0_0_10px_hsl(var(--primary))]" />
                </motion.div>
                <h3 className="text-xl font-bold">¡CUENTA ATRÁS BOOSTED!</h3>
                <p className="text-sm text-muted-foreground mb-4 truncate">{boostedDay.eventName || 'Tu día clave'}</p>
                
                <div className="font-black text-7xl my-2 text-transparent bg-clip-text bg-gradient-to-r from-primary to-amber-400 drop-shadow-[0_0_5px_hsl(var(--primary)/0.5)]">
                    {diffDays}
                </div>
                <p className="text-lg font-bold tracking-widest text-muted-foreground">{diffDays === 1 ? 'DÍA' : 'DÍAS'}</p>
            </div>
        </motion.div>
    );
};


const BoostedDaySetter = ({ userId }) => {
    const [boostedDay, setBoostedDayState] = useState(() => getBoostedDay(userId));
    const [isCalendarOpen, setCalendarOpen] = useState(false);
    const [viewDate, setViewDate] = useState(new Date());
    const [eventName, setEventName] = useState('');

    useEffect(() => {
        if (!userId) return;
        const storedBoostedDay = getBoostedDay(userId);
        setBoostedDayState(storedBoostedDay);
        if(storedBoostedDay){
            setEventName(storedBoostedDay.eventName || '');
        }
    }, [userId]);

    const handleDateSelect = (date) => {
        const dateString = date.toISOString().split('T')[0];
        setBoostedDay(userId, dateString, eventName);
        setBoostedDayState({ date: dateString, eventName });
        setCalendarOpen(false);
        toast({ title: '¡Día Boosted Fijado!', description: `¡A tope para el ${eventName || date.toLocaleDateString()}!` });
    };

    const handleClear = () => {
        setBoostedDay(userId, null, null);
        setBoostedDayState(null);
        setEventName('');
        toast({ title: "Día Boosted eliminado" });
    };

    return (
        <div className="glass-effect p-6 rounded-2xl mt-6 border border-white/5">
            <AnimatePresence mode="wait">
                {boostedDay ? (
                    <CountdownDisplay key="countdown" boostedDay={boostedDay} onClear={handleClear} />
                ) : (
                    <motion.div
                        key="setter"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                    >
                        <div className="flex items-center gap-3 mb-4">
                            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                                <Rocket className="w-6 h-6 text-primary" />
                            </div>
                            <h3 className="text-2xl font-bold">Fijar Día Boosted</h3>
                        </div>
                        <p className="text-sm text-muted-foreground mb-4">
                            Marca el día clave en tu calendario. El día que tienes que estar en tu mejor versión.
                        </p>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                            <input
                                type="text"
                                placeholder="Nombre del Evento (Opcional)"
                                value={eventName}
                                onChange={(e) => setEventName(e.target.value)}
                                className="w-full bg-secondary border-none rounded-xl px-4 py-3 text-sm font-medium focus:ring-2 focus:ring-primary"
                            />
                            <Button onClick={() => setCalendarOpen(true)} className="w-full btn-primary h-12">
                                <CalendarIcon className="w-4 h-4 mr-2" /> Seleccionar Fecha
                            </Button>
                        </div>

                        <AnimatePresence>
                            {isCalendarOpen && (
                                <motion.div
                                    initial={{ opacity: 0, height: 0 }}
                                    animate={{ opacity: 1, height: 'auto' }}
                                    exit={{ opacity: 0, height: 0 }}
                                    className="mt-4 overflow-hidden"
                                >
                                    <Calendar 
                                        currentDate={viewDate}
                                        onDateSelect={handleDateSelect}
                                        setViewDate={setViewDate}
                                    />
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default BoostedDaySetter;