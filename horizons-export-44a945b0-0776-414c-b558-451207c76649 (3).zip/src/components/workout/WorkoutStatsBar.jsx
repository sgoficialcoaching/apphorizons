import React from 'react';
import { motion } from 'framer-motion';
import { Activity, Clock, Flame, Dumbbell } from 'lucide-react';

const StatItem = ({ icon: Icon, value, label, color }) => (
    <div className="flex flex-col items-center justify-center min-w-[70px]">
        <div className="flex items-center gap-1.5 mb-0.5">
            <Icon className={`w-3.5 h-3.5 ${color}`} />
            <span className="text-sm font-black text-white tabular-nums tracking-tight">{value}</span>
        </div>
        <span className="text-[9px] text-muted-foreground uppercase tracking-wider font-bold">{label}</span>
    </div>
);

const WorkoutStatsBar = ({ duration, calories, volume, setsDone }) => {
    // Format duration mm:ss
    const formatTime = (seconds) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    };

    return (
        <motion.div 
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="flex items-center justify-between px-2 py-3 bg-black/40 border-b border-white/5 backdrop-blur-sm overflow-x-auto no-scrollbar"
        >
            <StatItem 
                icon={Clock} 
                value={formatTime(duration)} 
                label="Tiempo" 
                color="text-blue-400" 
            />
            <div className="w-px h-6 bg-white/10 mx-2" />
            <StatItem 
                icon={Flame} 
                value={calories} 
                label="Kcal" 
                color="text-orange-500" 
            />
             <div className="w-px h-6 bg-white/10 mx-2" />
            <StatItem 
                icon={Dumbbell} 
                value={`${(volume / 1000).toFixed(1)}k`} 
                label="Volumen" 
                color="text-purple-400" 
            />
             <div className="w-px h-6 bg-white/10 mx-2" />
            <StatItem 
                icon={Activity} 
                value={setsDone} 
                label="Series" 
                color="text-green-400" 
            />
        </motion.div>
    );
};

export default WorkoutStatsBar;