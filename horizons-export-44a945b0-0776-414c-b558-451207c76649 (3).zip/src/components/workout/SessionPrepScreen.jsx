import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    ArrowLeft, ArrowRight, Play, Search, Dumbbell, 
    Battery, BatteryMedium, BatteryLow, Zap, Target,
    Filter, Check, X, Flame, ChevronRight, Activity,
    Timer, BrainCircuit, ShieldCheck, ChevronLeft, RefreshCw, Sparkles, Undo2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { getExercises, createWorkout, createExercise } from '@/lib/database';
import { getTodaysPPLWorkout, initializePPLExercises } from '@/lib/ppl';
import { cn } from '@/lib/utils';
import { CircularProgressbarWithChildren, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

// --- ANIMATION VARIANTS ---
const pageVariants = {
    initial: (direction) => ({
        x: direction > 0 ? 100 : -100,
        opacity: 0
    }),
    animate: {
        x: 0,
        opacity: 1,
        transition: {
            x: { type: "spring", stiffness: 300, damping: 30 },
            opacity: { duration: 0.2 }
        }
    },
    exit: (direction) => ({
        x: direction < 0 ? 100 : -100,
        opacity: 0,
        transition: {
            x: { type: "spring", stiffness: 300, damping: 30 },
            opacity: { duration: 0.2 }
        }
    })
};

// --- SUB-COMPONENTS ---

const StepIndicator = ({ currentStep, totalSteps }) => (
    <div className="flex items-center justify-center space-x-1.5 mb-6 px-4">
        {Array.from({ length: totalSteps }).map((_, idx) => {
            const stepNum = idx + 1;
            const isActive = stepNum === currentStep;
            const isCompleted = stepNum < currentStep;
            
            return (
                <div key={idx} className="flex-1 flex flex-col items-center">
                    <motion.div 
                        className={cn(
                            "w-full h-1.5 rounded-full transition-colors duration-300",
                            isActive ? "bg-[var(--neon-yellow)] shadow-[0_0_10px_var(--neon-yellow)]" : (isCompleted ? "bg-green-500" : "bg-white/10")
                        )}
                        initial={false}
                        animate={{ scaleY: isActive ? 1.5 : 1 }}
                    />
                </div>
            );
        })}
    </div>
);

const EnergySelector = ({ value, onChange }) => {
    const options = [
        { level: 'low', icon: BatteryLow, label: 'Baja', color: 'text-red-400', bg: 'bg-red-500/10 border-red-500/20' },
        { level: 'medium', icon: BatteryMedium, label: 'Media', color: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/20' },
        { level: 'high', icon: Battery, label: 'Alta', color: 'text-green-400', bg: 'bg-green-500/10 border-green-500/20' },
        { level: 'beast', icon: Zap, label: 'Beast', color: 'text-[var(--neon-yellow)]', bg: 'bg-yellow-500/10 border-yellow-500/20' },
    ];

    return (
        <div className="grid grid-cols-2 gap-3">
            {options.map((opt) => (
                <motion.button
                    key={opt.level}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => onChange(opt.level)}
                    className={cn(
                        "p-4 rounded-2xl border flex flex-col items-center justify-center gap-2 transition-all duration-200",
                        value === opt.level 
                            ? `border-[var(--neon-yellow)] bg-[var(--neon-yellow)]/20 shadow-[0_0_15px_rgba(255,214,0,0.3)]` 
                            : "border-white/5 bg-black/40 hover:bg-white/5"
                    )}
                >
                    <opt.icon className={cn("w-8 h-8", opt.color)} />
                    <span className={cn("text-xs font-bold uppercase tracking-wider", opt.color)}>{opt.label}</span>
                </motion.button>
            ))}
        </div>
    );
};

const WarmupTimer = ({ duration, onComplete }) => {
    const [timeLeft, setTimeLeft] = useState(duration);
    const [isActive, setIsActive] = useState(false);

    useEffect(() => {
        let interval = null;
        if (isActive && timeLeft > 0) {
            interval = setInterval(() => {
                setTimeLeft(timeLeft => timeLeft - 1);
            }, 1000);
        } else if (timeLeft === 0) {
            setIsActive(false);
            onComplete();
        }
        return () => clearInterval(interval);
    }, [isActive, timeLeft, onComplete]);

    const formatTime = (time) => {
        const minutes = Math.floor(time / 60);
        const seconds = time % 60;
        return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
    };

    const percentage = (timeLeft / duration) * 100;

    return (
        <div className="flex flex-col items-center justify-center py-6">
            <div className="w-48 h-48 relative mb-6">
                <CircularProgressbarWithChildren 
                    value={percentage}
                    styles={buildStyles({
                        pathColor: '#FFD600', // var(--neon-yellow)
                        trailColor: 'rgba(255,255,255,0.1)',
                        pathTransitionDuration: 0.5
                    })}
                >
                    <div className="text-center">
                        <span className="text-4xl font-black font-mono tracking-tighter text-white">
                            {formatTime(timeLeft)}
                        </span>
                        <p className="text-[10px] uppercase tracking-widest text-muted-foreground mt-1">Tiempo Restante</p>
                    </div>
                </CircularProgressbarWithChildren>
            </div>
            
            <div className="flex gap-4">
                <Button 
                    variant={isActive ? "secondary" : "default"}
                    onClick={() => setIsActive(!isActive)}
                    className="w-32 font-bold"
                >
                    {isActive ? "Pausar" : "Iniciar"}
                </Button>
                <Button 
                    variant="ghost" 
                    onClick={onComplete}
                    className="text-xs text-muted-foreground hover:text-white"
                >
                    Saltar
                </Button>
            </div>
        </div>
    );
};

// --- MAIN SCREEN ---

const SessionPrepScreen = () => {
    const navigate = useNavigate();
    const { user } = useAuth();
    const { date, level } = useParams();

    // State
    const [step, setStep] = useState(1);
    const [direction, setDirection] = useState(0);
    const [isLoading, setIsLoading] = useState(true);
    
    // Data
    const [allExercises, setAllExercises] = useState([]);
    const [originalPPL, setOriginalPPL] = useState([]); // Store original PPL for reset
    
    // Selections
    const [energyLevel, setEnergyLevel] = useState('medium');
    const [workoutFocus, setWorkoutFocus] = useState('hypertrophy');
    const [selectedExercises, setSelectedExercises] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [activeFilter, setActiveFilter] = useState('all');
    
    // Warmup State
    const [warmupComplete, setWarmupComplete] = useState(false);
    const [activeWarmupIndex, setActiveWarmupIndex] = useState(0);
    const [pplName, setPplName] = useState('Rutina Personalizada');

    const warmupRoutine = [
        { name: "Movilidad de Hombros", duration: 60, icon: <Activity className="w-5 h-5 text-orange-400" /> },
        { name: "Sentadilla Profunda (Estática)", duration: 45, icon: <Dumbbell className="w-5 h-5 text-blue-400" /> },
        { name: "Activación de Core", duration: 30, icon: <ShieldCheck className="w-5 h-5 text-green-400" /> }
    ];

    // Load Data Immediately & Init PPL
    useEffect(() => {
        const loadData = () => {
            initializePPLExercises();
            const exercises = getExercises();
            setAllExercises(exercises);

            if (user) {
                // Determine Day Index based on date param if provided, else use today
                // For simplicity here, leveraging PPL logic which uses today's date internally relative to config start
                // We'll trust getTodaysPPLWorkout handles the correct day or adapt logic if strictly date param needed
                const pplWorkout = getTodaysPPLWorkout(user.id);
                
                if (pplWorkout && pplWorkout.type !== 'Rest') {
                    setPplName(pplWorkout.name);
                    
                    // Map PPL items to selectedExercises format
                    const preSelected = pplWorkout.items.map(item => {
                        // Find matching DB exercise or create mock if missing
                        const match = exercises.find(e => e.id === item.exercise_id) || 
                                     exercises.find(e => e.name === item.exercise_name);
                        
                        return match ? { ...match, isRecommended: true } : {
                             id: item.exercise_id, 
                             name: item.exercise_name, 
                             muscleGroup: 'General', 
                             isRecommended: true 
                        };
                    });
                    
                    setSelectedExercises(preSelected);
                    setOriginalPPL(preSelected);
                }
            }
            
            setIsLoading(false);
        };
        loadData();
    }, [user, date]);

    // Derived Filters
    const filteredExercises = useMemo(() => {
        let result = allExercises;
        
        if (activeFilter !== 'all') {
            result = result.filter(ex => ex.muscleGroup?.toLowerCase() === activeFilter.toLowerCase());
        }
        
        if (searchQuery.trim()) {
            const q = searchQuery.toLowerCase();
            result = result.filter(ex => ex.name.toLowerCase().includes(q));
        }
        
        return result;
    }, [allExercises, activeFilter, searchQuery]);

    const categories = ['all', ...new Set(allExercises.map(e => e.muscleGroup?.toLowerCase()).filter(Boolean))];

    // Handlers
    const nextStep = () => {
        if (step === 2 && selectedExercises.length === 0) {
            toast({ title: "Selección requerida", description: "Selecciona al menos un ejercicio.", variant: "destructive" });
            return;
        }
        if (step === 4 && !warmupComplete) {
             toast({ title: "Calentamiento sugerido", description: "Se recomienda completar al menos un ejercicio de activación.", variant: "default" });
        }

        setDirection(1);
        setStep(prev => Math.min(prev + 1, 5));
    };

    const prevStep = () => {
        setDirection(-1);
        setStep(prev => Math.max(prev - 1, 1));
    };

    const toggleExercise = (exercise) => {
        setSelectedExercises(prev => {
            const exists = prev.find(e => e.id === exercise.id);
            if (exists) {
                // If removing, just filter out
                return prev.filter(e => e.id !== exercise.id);
            } else {
                // If adding, mark as custom selection (not recommended by default PPL unless originally there)
                const isOriginallyRecommended = originalPPL.some(p => p.id === exercise.id);
                return [...prev, { ...exercise, isRecommended: isOriginallyRecommended }];
            }
        });
    };
    
    const resetToOriginalPPL = () => {
        setSelectedExercises(originalPPL);
        toast({ title: "Rutina Restaurada", description: "Se han vuelto a cargar los ejercicios recomendados." });
    };

    const handleStartWorkout = () => {
        if (!user) return;
        
        // In Step 2, user might have mixed recommended and custom exercises
        // We create sets. PPL logic usually has set counts. Here we default or use intelligence.
        const sets = selectedExercises.flatMap(ex => (
            Array(3).fill(null).map((_, i) => ({
                exercise_id: ex.id,
                set_index: i + 1
            }))
        ));
        
        // Create any missing custom exercises if they were purely UI mocks (edge case safety)
        // (Assuming toggleExercise uses real DB objects from allExercises)

        const workout = createWorkout(user.id, {
            programId: 'custom_session_ppl',
            programName: `Sesión: ${pplName}`,
            sets: sets
        });

        if (workout) {
            navigate(`/workout/${workout.id}`);
        }
    };

    // --- RENDER STEPS ---

    const renderStep1 = () => (
        <div className="space-y-8 pb-footer-safe">
            <div className="text-center space-y-2">
                <h2 className="text-2xl font-black italic uppercase text-white">Estado Inicial</h2>
                <p className="text-muted-foreground text-sm">Ajustaremos el volumen según tu energía.</p>
            </div>

            <div className="space-y-4">
                <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground ml-1">Nivel de Energía</label>
                <EnergySelector value={energyLevel} onChange={setEnergyLevel} />
            </div>

            <div className="space-y-4">
                <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground ml-1">Enfoque de Hoy</label>
                <div className="grid grid-cols-1 gap-2">
                    {['Fuerza (Bajas Reps)', 'Hipertrofia (Volumen)', 'Resistencia (Altas Reps)'].map((focus) => (
                        <button
                            key={focus}
                            onClick={() => setWorkoutFocus(focus.split(' ')[0].toLowerCase())}
                            className={cn(
                                "w-full p-4 rounded-xl text-left border transition-all flex items-center justify-between",
                                workoutFocus === focus.split(' ')[0].toLowerCase()
                                    ? "bg-white/10 border-[var(--neon-yellow)] text-white"
                                    : "bg-transparent border-white/5 text-muted-foreground hover:bg-white/5"
                            )}
                        >
                            <span className="font-bold text-sm">{focus}</span>
                            {workoutFocus === focus.split(' ')[0].toLowerCase() && <Check className="w-4 h-4 text-[var(--neon-yellow)]" />}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );

    const renderStep2 = () => {
        const hasChanges = JSON.stringify(selectedExercises.map(e=>e.id).sort()) !== JSON.stringify(originalPPL.map(e=>e.id).sort());
        
        return (
            <div className="h-full flex flex-col">
                <div className="text-center mb-4 flex-none space-y-1">
                    <h2 className="text-xl font-black italic uppercase text-white">Selección</h2>
                    <div className="flex items-center justify-center gap-2">
                        <span className="text-xs font-bold text-[var(--neon-yellow)] uppercase tracking-wider">{pplName}</span>
                        {hasChanges && <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded text-muted-foreground">Personalizada</span>}
                    </div>
                </div>

                {/* Recommendations Banner */}
                {originalPPL.length > 0 && (
                    <div className="flex-none mb-4 flex items-center justify-between bg-[var(--neon-yellow)]/5 border border-[var(--neon-yellow)]/20 p-3 rounded-xl">
                        <div className="flex items-center gap-2">
                            <Sparkles className="w-4 h-4 text-[var(--neon-yellow)]" />
                            <p className="text-xs text-[var(--neon-yellow)] font-medium">Rutina recomendada cargada</p>
                        </div>
                        {hasChanges && (
                            <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={resetToOriginalPPL}
                                className="h-6 text-[10px] hover:bg-[var(--neon-yellow)]/10 hover:text-[var(--neon-yellow)] px-2"
                            >
                                <Undo2 className="w-3 h-3 mr-1" /> Resetear
                            </Button>
                        )}
                    </div>
                )}

                {/* Search & Filter */}
                <div className="flex-none space-y-3 mb-4">
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input 
                            placeholder="Buscar ejercicio..." 
                            className="pl-9 bg-secondary/50 border-white/5 h-10 rounded-full text-sm focus:border-[var(--neon-yellow)] transition-colors"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </div>
                    <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                        {categories.map(cat => (
                            <button
                                key={cat}
                                onClick={() => setActiveFilter(cat)}
                                className={cn(
                                    "px-3 py-1.5 rounded-full text-[10px] uppercase font-bold tracking-wider whitespace-nowrap border transition-colors",
                                    activeFilter === cat 
                                        ? "bg-[var(--neon-yellow)] text-black border-[var(--neon-yellow)]" 
                                        : "bg-transparent border-white/10 text-muted-foreground hover:border-white/30"
                                )}
                            >
                                {cat === 'all' ? 'Todos' : cat}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Grid */}
                <div className="flex-1 overflow-y-auto pr-1 space-y-2 min-h-0 pb-footer-safe">
                    {/* Show Selected First if searching, else just list filtered */}
                    {filteredExercises.map((ex) => {
                        const isSelected = selectedExercises.some(s => s.id === ex.id);
                        const isRecommended = originalPPL.some(p => p.id === ex.id);
                        
                        return (
                            <motion.button
                                key={ex.id}
                                layoutId={ex.id}
                                onClick={() => toggleExercise(ex)}
                                className={cn(
                                    "w-full p-3 rounded-xl border flex items-center gap-3 transition-all relative overflow-hidden group",
                                    isSelected 
                                        ? "bg-[var(--neon-yellow)]/10 border-[var(--neon-yellow)] shadow-[inset_0_0_10px_rgba(255,214,0,0.1)]" 
                                        : "bg-card/50 border-white/5 hover:bg-white/5"
                                )}
                            >
                                {isRecommended && (
                                    <div className="absolute top-0 right-0 bg-[var(--neon-yellow)] w-3 h-3 rounded-bl-lg z-10" title="Recomendado" />
                                )}
                                
                                <div className={cn(
                                    "w-10 h-10 rounded-lg flex items-center justify-center border transition-colors",
                                    isSelected ? "bg-[var(--neon-yellow)] border-[var(--neon-yellow)] text-black" : "bg-black border-white/10 text-muted-foreground group-hover:border-white/30"
                                )}>
                                    {isSelected ? <Check className="w-5 h-5" /> : <Dumbbell className="w-5 h-5" />}
                                </div>
                                <div className="flex-1 text-left">
                                    <h4 className={cn("font-bold text-sm leading-none mb-1", isSelected ? "text-white" : "text-gray-300")}>{ex.name}</h4>
                                    <div className="flex items-center gap-2">
                                        <p className="text-[10px] text-muted-foreground uppercase">{ex.muscleGroup}</p>
                                        {isRecommended && <span className="text-[9px] text-[var(--neon-yellow)] font-bold bg-[var(--neon-yellow)]/10 px-1.5 rounded">BOOST</span>}
                                    </div>
                                </div>
                            </motion.button>
                        );
                    })}
                    {filteredExercises.length === 0 && (
                        <div className="text-center py-10 text-muted-foreground text-sm">
                            No se encontraron ejercicios.
                        </div>
                    )}
                    
                    <div className="pt-2 text-center pb-20">
                         <span className="text-xs font-mono text-[var(--neon-yellow)]">{selectedExercises.length} seleccionados</span>
                    </div>
                </div>
            </div>
        );
    };

    const renderStep3 = () => (
        <div className="h-full flex flex-col">
            <div className="text-center space-y-2 mb-6">
                <h2 className="text-2xl font-black italic uppercase text-white">Previsualización</h2>
                <p className="text-muted-foreground text-sm">Confirma el plan de ataque.</p>
            </div>

            <div className="flex-1 overflow-y-auto space-y-4 pr-1 pb-footer-safe">
                <div className="bg-white/5 rounded-2xl p-4 border border-white/5 space-y-4">
                     <div className="flex items-center gap-3 mb-2">
                        <div className="p-2 bg-[var(--neon-yellow)]/20 rounded-lg text-[var(--neon-yellow)]">
                            <Target className="w-5 h-5" />
                        </div>
                        <div>
                            <p className="text-xs text-muted-foreground uppercase">Objetivo Principal</p>
                            <p className="font-bold text-white capitalize">{workoutFocus}</p>
                        </div>
                    </div>
                    
                    <div className="h-px bg-white/5 my-2" />

                    <div className="space-y-3">
                        {selectedExercises.map((ex, i) => (
                            <div key={i} className="flex items-center gap-4 bg-black/40 p-3 rounded-xl border border-white/5">
                                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-white/10 flex items-center justify-center text-xs font-bold text-muted-foreground">{i+1}</span>
                                <div className="flex-1">
                                    <p className="text-sm font-bold text-white">{ex.name}</p>
                                    <p className="text-[10px] text-muted-foreground uppercase">{ex.muscleGroup}</p>
                                </div>
                                <div className="text-right">
                                    <p className="text-xs font-bold text-[var(--neon-yellow)]">3 Series</p>
                                    <p className="text-[10px] text-muted-foreground">8-12 Reps</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="bg-[var(--neon-yellow)]/10 p-4 rounded-xl border border-[var(--neon-yellow)]/20 mb-20">
                     <p className="text-xs text-[var(--neon-yellow)] leading-relaxed text-center font-medium">
                        "La preparación es la clave del éxito. Visualiza cada repetición."
                    </p>
                </div>
            </div>
        </div>
    );

    const renderStep4 = () => {
        const currentExercise = warmupRoutine[activeWarmupIndex];
        return (
            <div className="h-full flex flex-col pb-footer-safe">
                 <div className="text-center space-y-2 mb-4">
                    <h2 className="text-2xl font-black italic uppercase text-white">Calentamiento</h2>
                    <p className="text-muted-foreground text-sm">Activa tu cuerpo antes de la carga.</p>
                </div>

                <div className="flex-1 flex flex-col items-center justify-center">
                    <AnimatePresence mode="wait">
                        <motion.div 
                            key={activeWarmupIndex}
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -20 }}
                            className="w-full"
                        >
                            <div className="bg-black/40 rounded-3xl border border-white/10 p-6 relative overflow-hidden">
                                <div className="absolute top-0 left-0 right-0 h-1 bg-white/10">
                                    <motion.div 
                                        className="h-full bg-green-500"
                                        initial={{ width: 0 }}
                                        animate={{ width: `${((activeWarmupIndex + 1) / warmupRoutine.length) * 100}%` }}
                                    />
                                </div>
                                
                                <div className="text-center mb-6 mt-4">
                                    <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-3 text-white border border-white/10">
                                        {currentExercise.icon}
                                    </div>
                                    <h3 className="text-xl font-bold text-white">{currentExercise.name}</h3>
                                    <p className="text-xs text-muted-foreground uppercase tracking-wider">Ejercicio {activeWarmupIndex + 1} de {warmupRoutine.length}</p>
                                </div>

                                <WarmupTimer 
                                    duration={currentExercise.duration}
                                    onComplete={() => {
                                        if (activeWarmupIndex < warmupRoutine.length - 1) {
                                            setActiveWarmupIndex(prev => prev + 1);
                                        } else {
                                            setWarmupComplete(true);
                                            nextStep();
                                        }
                                    }}
                                />
                            </div>
                        </motion.div>
                    </AnimatePresence>
                </div>
            </div>
        );
    };

    const renderStep5 = () => (
        <div className="h-full flex flex-col items-center justify-center text-center space-y-8 pb-footer-safe">
            <motion.div 
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", bounce: 0.5 }}
                className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(34,197,94,0.3)]"
            >
                <Check className="w-12 h-12 text-black" strokeWidth={4} />
            </motion.div>

            <div className="space-y-2">
                <h2 className="text-3xl font-black italic uppercase text-white">¡Todo Listo!</h2>
                <p className="text-muted-foreground text-sm max-w-xs mx-auto">
                    Has completado la preparación. Tu cuerpo y mente están listos para romper límites.
                </p>
            </div>

            <div className="grid grid-cols-2 gap-4 w-full">
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                    <p className="text-[10px] text-muted-foreground uppercase font-bold">Estado</p>
                    <p className="text-green-400 font-bold flex items-center justify-center gap-1">
                        <Flame className="w-4 h-4" /> Activado
                    </p>
                </div>
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                    <p className="text-[10px] text-muted-foreground uppercase font-bold">Ejercicios</p>
                    <p className="text-white font-bold">{selectedExercises.length} Seleccionados</p>
                </div>
            </div>

            <div className="w-full bg-gradient-to-r from-blue-900/20 to-purple-900/20 p-4 rounded-xl border border-white/10 mt-4">
                <BrainCircuit className="w-6 h-6 text-purple-400 mx-auto mb-2" />
                <p className="text-xs text-purple-200 italic">
                    "Concéntrate en la técnica, no solo en el peso. La calidad construye el músculo."
                </p>
            </div>
        </div>
    );

    if (isLoading) {
        return (
            <div className="min-h-screen bg-background flex items-center justify-center">
                <div className="animate-pulse flex flex-col items-center gap-4">
                    <div className="w-12 h-12 rounded-full border-2 border-[var(--neon-yellow)] border-t-transparent animate-spin" />
                    <p className="text-xs text-muted-foreground uppercase tracking-widest">Iniciando Sistema...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-background flex flex-col relative overflow-hidden">
             {/* Background Gradients */}
            <div className="absolute top-[-20%] left-[-20%] w-[500px] h-[500px] bg-[var(--neon-yellow)]/10 blur-[120px] rounded-full pointer-events-none" />
            
            {/* Header */}
            <header className="flex-none p-4 pt-6 flex items-center justify-between relative z-10 safe-area-top">
                <Button variant="ghost" size="icon" onClick={() => step > 1 ? prevStep() : navigate(-1)}>
                    {step > 1 ? <ChevronLeft className="w-6 h-6" /> : <ArrowLeft className="w-6 h-6" />}
                </Button>
                <span className="text-xs font-black uppercase tracking-widest text-muted-foreground bg-white/5 px-3 py-1 rounded-full border border-white/5">
                    Fase {step} de 5
                </span>
                <div className="w-10" /> {/* Spacer */}
            </header>

            <StepIndicator currentStep={step} totalSteps={5} />

            {/* Content Area */}
            <div className="flex-1 overflow-hidden relative px-6">
                <AnimatePresence custom={direction} mode="wait">
                    <motion.div
                        key={step}
                        custom={direction}
                        variants={pageVariants}
                        initial="initial"
                        animate="animate"
                        exit="exit"
                        className="h-full"
                    >
                        {step === 1 && renderStep1()}
                        {step === 2 && renderStep2()}
                        {step === 3 && renderStep3()}
                        {step === 4 && renderStep4()}
                        {step === 5 && renderStep5()}
                    </motion.div>
                </AnimatePresence>
            </div>

            {/* Footer Navigation */}
            <div className="fixed bottom-0 left-0 right-0 p-6 bg-background/80 backdrop-blur-lg border-t border-white/5 z-20 safe-area-bottom">
                <div className="max-w-md mx-auto">
                    {step < 5 ? (
                        <div className="flex gap-4">
                             {step > 1 && (
                                <Button 
                                    className="w-14 h-14 rounded-full flex-shrink-0 bg-white/5 border border-white/10 hover:bg-white/10 p-0"
                                    onClick={prevStep}
                                >
                                    <ChevronLeft className="w-6 h-6" />
                                </Button>
                             )}
                            <Button 
                                className="w-full h-14 text-lg font-bold uppercase tracking-widest text-black bg-[var(--neon-yellow)] hover:bg-white border-none shadow-[0_0_20px_rgba(255,214,0,0.3)] flex-1"
                                onClick={nextStep}
                            >
                                Siguiente <ChevronRight className="w-5 h-5 ml-2" />
                            </Button>
                        </div>
                    ) : (
                        <Button 
                            className="w-full h-14 text-lg font-black uppercase tracking-widest shadow-[0_0_30px_var(--neon-yellow)] shadow-[var(--neon-yellow)]/30 hover:shadow-[0_0_50px_var(--neon-yellow)]/50 transition-all bg-[var(--neon-yellow)] text-black hover:bg-white border-none"
                            onClick={handleStartWorkout}
                        >
                            <Play className="w-5 h-5 mr-2 fill-black" />
                            COMENZAR ENTRENAMIENTO
                        </Button>
                    )}
                </div>
            </div>
        </div>
    );
};

export default SessionPrepScreen;