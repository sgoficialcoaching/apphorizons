import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, Reorder, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Dumbbell, X, GripVertical, RefreshCw, PlayCircle, Info, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { getTodaysPPLWorkout, initializePPLExercises } from '@/lib/ppl';
import { getExercises, createWorkout, createExercise } from '@/lib/database';
import { toast } from '@/components/ui/use-toast';

// Utility to ensure unique IDs for the Reorder component
const generateUniqueId = () => `id-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

const ReplacementDrawer = ({ isOpen, onClose, targetExercise, onReplace }) => {
    const [alternatives, setAlternatives] = useState([]);

    useEffect(() => {
        if (isOpen && targetExercise) {
            const allEx = getExercises();
            // Find exercises with same muscle group but different name
            const filtered = allEx.filter(e => 
                e.muscleGroup?.toLowerCase() === targetExercise.muscleGroup?.toLowerCase() &&
                e.id !== targetExercise.id
            );
            setAlternatives(filtered);
        }
    }, [isOpen, targetExercise]);

    return (
        <AnimatePresence>
            {isOpen && (
                <>
                    <motion.div 
                        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                        className="fixed inset-0 bg-black/80 z-50"
                        onClick={onClose}
                    />
                    <motion.div
                        initial={{ y: "100%" }}
                        animate={{ y: 0 }}
                        exit={{ y: "100%" }}
                        transition={{ type: "spring", damping: 25, stiffness: 300 }}
                        className="fixed bottom-0 left-0 right-0 z-[60] bg-[#111] border-t border-white/10 rounded-t-3xl max-h-[80vh] flex flex-col shadow-[0_-10px_40px_rgba(0,0,0,0.7)] safe-area-bottom"
                    >
                        <div className="p-6 border-b border-white/10 flex justify-between items-center bg-[#111] rounded-t-3xl">
                            <div>
                                <h3 className="text-xl font-bold text-white">Alternativas Tácticas</h3>
                                <p className="text-xs text-muted-foreground uppercase tracking-wider">Grupo: <span className="text-primary">{targetExercise?.muscleGroup}</span></p>
                            </div>
                            <Button variant="ghost" size="icon" onClick={onClose}><X className="w-6 h-6" /></Button>
                        </div>
                        
                        <div className="p-4 overflow-y-auto flex-1 space-y-3 bg-[#111]">
                            {alternatives.length > 0 ? (
                                alternatives.map(alt => (
                                    <motion.button
                                        key={alt.id}
                                        whileHover={{ scale: 1.02, backgroundColor: "#222" }}
                                        whileTap={{ scale: 0.98 }}
                                        onClick={() => onReplace(alt)}
                                        className="w-full flex items-center p-4 rounded-xl bg-[#1a1a1a] border border-white/5 hover:border-primary/50 transition-all group text-left"
                                    >
                                        <div className="w-12 h-12 rounded-lg bg-black border border-white/10 flex items-center justify-center mr-4 group-hover:border-primary/50 transition-colors">
                                            <RefreshCw className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                                        </div>
                                        <div className="flex-1">
                                            <h4 className="font-bold text-white group-hover:text-primary transition-colors">{alt.name}</h4>
                                            <p className="text-xs text-muted-foreground line-clamp-1">{alt.description || "Sin descripción"}</p>
                                        </div>
                                        <div className="opacity-0 group-hover:opacity-100 text-primary text-xs font-bold uppercase tracking-wider transition-opacity">
                                            Seleccionar
                                        </div>
                                    </motion.button>
                                ))
                            ) : (
                                <div className="text-center p-8 text-muted-foreground">
                                    <AlertTriangle className="w-12 h-12 mx-auto mb-4 opacity-50" />
                                    <p>No se encontraron alternativas directas.</p>
                                </div>
                            )}
                        </div>
                    </motion.div>
                </>
            )}
        </AnimatePresence>
    );
};

const WorkoutPreviewScreen = () => {
    const { date } = useParams();
    const navigate = useNavigate();
    const { user } = useAuth();
    const [workoutItems, setWorkoutItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeSwapIndex, setActiveSwapIndex] = useState(null);
    const [pplInfo, setPplInfo] = useState(null);

    useEffect(() => {
        if (user) {
            initializePPLExercises();
            const ppl = getTodaysPPLWorkout(user.id);
            
            if (ppl) {
                setPplInfo({ name: ppl.name, description: ppl.description });
                const dbExercises = getExercises();
                
                const hydratedItems = ppl.items.map(item => {
                    const dbEx = dbExercises.find(e => e.id === item.exercise_id) || 
                                 dbExercises.find(e => e.name === item.exercise_name);
                    
                    return {
                        ...item,
                        uniqueId: generateUniqueId(),
                        dbData: dbEx || { 
                            name: item.exercise_name, 
                            muscleGroup: 'General',
                            id: item.exercise_id
                        }
                    };
                });
                setWorkoutItems(hydratedItems);
            }
            setLoading(false);
        }
    }, [user]);

    const handleReplace = (newExercise) => {
        if (activeSwapIndex === null) return;

        const updatedItems = [...workoutItems];
        const oldItem = updatedItems[activeSwapIndex];
        
        updatedItems[activeSwapIndex] = {
            ...oldItem,
            exercise_id: newExercise.id,
            exercise_name: newExercise.name,
            dbData: newExercise
        };

        setWorkoutItems(updatedItems);
        setActiveSwapIndex(null);
        toast({
            title: "Ejercicio Actualizado",
            description: `${oldItem.exercise_name} reemplazado por ${newExercise.name}`,
            className: "bg-green-600 border-none text-white"
        });
    };

    const handleStartWorkout = () => {
        if (!user) return;

        try {
            const dbExercises = getExercises();
            const finalSets = [];

            workoutItems.forEach(item => {
                let dbEx = item.dbData;
                if (!dbExercises.find(e => e.id === dbEx.id)) {
                     dbEx = createExercise({
                        name: item.exercise_name,
                        muscleGroup: 'fullbody',
                        description: item.description,
                        prMetric: 'peso',
                        rest_time_sec: 90
                    });
                }

                for (let i = 0; i < item.series; i++) {
                    finalSets.push({
                        exercise_id: dbEx.id,
                        set_index: i + 1
                    });
                }
            });

            const newWorkout = createWorkout(user.id, {
                programId: 'prog_ppl_custom',
                programName: pplInfo?.name ? `PPL: ${pplInfo.name} (Editado)` : 'Entrenamiento Personalizado',
                sets: finalSets
            });

            if (newWorkout) {
                navigate(`/workout/${newWorkout.id}`);
            }
        } catch (error) {
            console.error(error);
            toast({ variant: 'destructive', title: 'Error', description: 'No se pudo iniciar el entrenamiento.' });
        }
    };

    if (loading) return null;

    return (
        <div className="min-h-screen bg-background pb-safe relative">
            <div className="relative z-10 p-4 sm:p-6">
                <header className="flex items-center justify-between mb-8 pt-2">
                     <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
                        <ArrowLeft />
                    </Button>
                    <div className="text-center">
                        <h1 className="text-xl md:text-3xl font-black uppercase tracking-tighter italic text-white">
                            MISIÓN DE HOY
                        </h1>
                        <p className="text-[10px] md:text-sm text-primary font-bold tracking-widest uppercase">{pplInfo?.name || "Rutina Diaria"}</p>
                    </div>
                    <div className="w-10" /> 
                </header>

                <div className="mb-6 bg-[#1a1a1a] p-4 rounded-2xl border border-white/5 flex items-center gap-3">
                     <Info className="w-5 h-5 text-primary flex-shrink-0" />
                     <p className="text-sm text-muted-foreground leading-tight">
                        Arrastra para reordenar. Pulsa <span className="text-white font-bold"><RefreshCw className="inline w-3 h-3"/></span> para reemplazar.
                     </p>
                </div>

                <Reorder.Group axis="y" values={workoutItems} onReorder={setWorkoutItems} className="space-y-4">
                    {workoutItems.map((item, index) => (
                        <Reorder.Item 
                            key={item.uniqueId} 
                            value={item}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            whileDrag={{ scale: 1.05, boxShadow: "0 10px 30px rgba(0,0,0,0.5)", zIndex: 50 }}
                            className="relative"
                        >
                            <motion.div 
                                className="bg-[#1a1a1a] p-0 rounded-2xl border border-white/5 overflow-hidden group touch-manipulation"
                                layoutId={`card-${item.uniqueId}`}
                            >
                                <div className="flex items-center p-4 gap-3 sm:gap-4">
                                    {/* Drag Handle - Bigger target */}
                                    <div className="cursor-grab active:cursor-grabbing text-muted-foreground hover:text-white transition-colors p-2 -ml-2">
                                        <GripVertical className="w-6 h-6" />
                                    </div>

                                    {/* Exercise Info */}
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-2 mb-1">
                                            <h3 className="font-bold text-base sm:text-lg truncate text-white group-hover:text-primary transition-colors">{item.exercise_name}</h3>
                                        </div>
                                        <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-[10px] sm:text-xs text-muted-foreground font-mono">
                                            <span className="bg-[#111] px-2 py-0.5 rounded border border-white/5 whitespace-nowrap">{item.series} SERIES</span>
                                            <span className="bg-[#111] px-2 py-0.5 rounded border border-white/5 whitespace-nowrap">{item.reps_target || '8-12'} REPS</span>
                                            <span className="capitalize text-primary/80 whitespace-nowrap">{item.dbData?.muscleGroup}</span>
                                        </div>
                                    </div>

                                    {/* Swap Action - Bigger target */}
                                    <motion.button
                                        whileHover={{ scale: 1.1, rotate: 180 }}
                                        whileTap={{ scale: 0.9 }}
                                        transition={{ duration: 0.3 }}
                                        onClick={() => setActiveSwapIndex(index)}
                                        className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#222] border border-white/10 flex flex-shrink-0 items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/50 hover:bg-primary/10 transition-all shadow-lg"
                                    >
                                        <RefreshCw className="w-5 h-5 sm:w-6 sm:h-6" />
                                    </motion.button>
                                </div>
                            </motion.div>
                        </Reorder.Item>
                    ))}
                </Reorder.Group>

                {/* Extra spacer to clear fixed button, increased for higher button placement */}
                <div className="h-48 sm:h-32" /> 
            </div>

            {/* Floating Action Bar - Confirmation Button */}
            <div className="fixed bottom-24 left-4 right-4 md:bottom-0 md:left-0 md:right-0 md:p-4 z-40 md:bg-[#000] md:border-t md:border-white/10 shadow-none md:shadow-[0_-5px_20px_rgba(0,0,0,0.5)] safe-area-bottom">
                <div className="max-w-4xl mx-auto">
                    <Button 
                        onClick={handleStartWorkout} 
                        className="w-full h-14 text-lg font-black uppercase tracking-widest shadow-[0_0_30px_rgba(255,214,0,0.2)] hover:shadow-[0_0_50px_rgba(255,214,0,0.4)] transition-all btn-primary"
                    >
                        <PlayCircle className="w-6 h-6 mr-2 fill-black" />
                        Confirmar & Entrenar
                    </Button>
                </div>
            </div>

            <ReplacementDrawer 
                isOpen={activeSwapIndex !== null}
                onClose={() => setActiveSwapIndex(null)}
                targetExercise={activeSwapIndex !== null ? workoutItems[activeSwapIndex].dbData : null}
                onReplace={handleReplace}
            />
        </div>
    );
};

export default WorkoutPreviewScreen;