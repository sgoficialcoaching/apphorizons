import React from 'react';
import { motion } from 'framer-motion';
import { Check, Dumbbell, Dumbbell as Barbell, TrendingUp } from 'lucide-react';

const LevelCard = ({ level, title, description, isSelected, onSelect, isDisabled, challengeActive }) => {
    const cardVariants = {
        initial: { scale: 1, y: 0 },
        hover: { scale: 1.03, y: -5, transition: { type: 'spring', stiffness: 300 } }
    };

    return (
        <motion.div
            variants={cardVariants}
            initial="initial"
            whileHover={!isDisabled ? "hover" : "initial"}
            onClick={() => !isDisabled && onSelect(level)}
            className={`relative p-6 rounded-2xl border-2 transition-all duration-300 cursor-pointer overflow-hidden
                ${isSelected ? 'border-primary bg-primary/10 shadow-lg' : 'border-border bg-card hover:border-primary/50'}
                ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''}
            `}
        >
            {isSelected && (
                <motion.div layoutId="check" className="absolute -top-3 -right-3 bg-primary text-primary-foreground rounded-full p-1.5 z-10">
                    <Check className="w-5 h-5" />
                </motion.div>
            )}
            <div className="flex items-center gap-4 mb-3">
                <div className={`p-3 rounded-lg bg-gradient-to-br ${
                    level === 'beginner' ? 'from-green-500/20 to-green-600/20 text-green-400' :
                    level === 'intermediate' ? 'from-yellow-500/20 to-yellow-600/20 text-yellow-400' :
                    'from-red-500/20 to-red-600/20 text-red-400'
                }`}>
                    {level === 'beginner' ? <Dumbbell /> : level === 'intermediate' ? <Barbell /> : <TrendingUp />}
                </div>
                <h3 className="text-2xl font-bold">{title}</h3>
            </div>
            <p className="text-sm text-muted-foreground">{description}</p>
            {isDisabled && challengeActive && (
                 <div className="absolute bottom-0 left-0 right-0 p-2 bg-primary/20 text-center">
                    <p className="font-bold text-xs text-primary-foreground">Nivel Advanced activo por el Reto Boost</p>
                 </div>
            )}
        </motion.div>
    );
};

export default LevelCard;