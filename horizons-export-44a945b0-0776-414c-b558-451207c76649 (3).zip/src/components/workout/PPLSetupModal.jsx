import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Check, Zap, Calendar, BarChart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { saveUserPPLConfig, FREQUENCIES } from '@/lib/ppl';
import { toast } from '@/components/ui/use-toast';

const PPLSetupModal = ({ userId, onClose, onComplete }) => {
    const [step, setStep] = useState(1);
    const [frequency, setFrequency] = useState(null);
    const [level, setLevel] = useState(null);

    const handleSave = () => {
        if (!frequency || !level) return;
        
        saveUserPPLConfig(userId, {
            frequency,
            level,
            startDate: new Date().toISOString()
        });

        toast({
            title: "¡Módulo PPL Activado!",
            description: "Tu estructura Push-Pull-Legs se ha generado correctamente.",
            className: "bg-green-600 text-white border-none"
        });
        
        if (onComplete) onComplete();
        onClose();
    };

    return (
        <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/90 backdrop-blur-md z-[100] flex items-center justify-center p-4"
        >
            <motion.div 
                initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }}
                className="bg-[#121214] border border-white/10 w-full max-w-2xl rounded-3xl overflow-hidden shadow-2xl"
            >
                <div className="p-6 border-b border-white/5 flex justify-between items-center">
                    <div>
                        <h2 className="text-2xl font-black text-white italic tracking-tighter">CONFIGURADOR <span className="text-primary">PPL</span></h2>
                        <p className="text-xs text-muted-foreground">PUSH • PULL • LEGS SYSTEM</p>
                    </div>
                    <Button variant="ghost" size="icon" onClick={onClose}><X className="w-5 h-5" /></Button>
                </div>

                <div className="p-8">
                    {step === 1 && (
                        <div className="space-y-6">
                            <div className="text-center mb-8">
                                <Calendar className="w-12 h-12 text-primary mx-auto mb-4" />
                                <h3 className="text-xl font-bold text-white">¿Con qué frecuencia entrenarás?</h3>
                                <p className="text-muted-foreground text-sm">Sé realista. La constancia vence a la intensidad.</p>
                            </div>
                            
                            <div className="grid gap-3">
                                {Object.entries(FREQUENCIES).map(([key, data]) => (
                                    <button
                                        key={key}
                                        onClick={() => setFrequency(key)}
                                        className={`p-4 rounded-xl border-2 text-left transition-all ${frequency === key ? 'border-primary bg-primary/10' : 'border-white/5 bg-white/5 hover:bg-white/10'}`}
                                    >
                                        <div className="flex justify-between items-center">
                                            <span className="font-bold text-white">{data.label}</span>
                                            {frequency === key && <Check className="text-primary w-5 h-5" />}
                                        </div>
                                        <p className="text-xs text-muted-foreground mt-1">Estructura: {data.structure.join(' - ')}</p>
                                    </button>
                                ))}
                            </div>
                            
                            <Button 
                                onClick={() => setStep(2)} 
                                disabled={!frequency}
                                className="w-full mt-4 btn-primary"
                            >
                                Siguiente
                            </Button>
                        </div>
                    )}

                    {step === 2 && (
                        <div className="space-y-6">
                             <div className="text-center mb-8">
                                <BarChart className="w-12 h-12 text-primary mx-auto mb-4" />
                                <h3 className="text-xl font-bold text-white">Nivel de Experiencia</h3>
                                <p className="text-muted-foreground text-sm">Esto ajustará el volumen de tus series.</p>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                {[1, 2, 3].map((lvl) => (
                                    <button
                                        key={lvl}
                                        onClick={() => setLevel(lvl)}
                                        className={`p-6 rounded-xl border-2 flex flex-col items-center justify-center gap-2 transition-all ${level === lvl ? 'border-primary bg-primary/10' : 'border-white/5 bg-white/5 hover:bg-white/10'}`}
                                    >
                                        <span className="text-3xl font-black text-white">{lvl}</span>
                                        <span className="text-xs uppercase tracking-widest text-muted-foreground">
                                            {lvl === 1 ? 'Iniciación' : lvl === 2 ? 'Intermedio' : 'Avanzado'}
                                        </span>
                                    </button>
                                ))}
                            </div>

                            <div className="flex gap-3 mt-8">
                                <Button variant="outline" onClick={() => setStep(1)} className="flex-1">Atrás</Button>
                                <Button 
                                    onClick={handleSave} 
                                    disabled={!level}
                                    className="flex-1 btn-primary"
                                >
                                    Generar Ciclo
                                </Button>
                            </div>
                        </div>
                    )}
                </div>
            </motion.div>
        </motion.div>
    );
};

export default PPLSetupModal;