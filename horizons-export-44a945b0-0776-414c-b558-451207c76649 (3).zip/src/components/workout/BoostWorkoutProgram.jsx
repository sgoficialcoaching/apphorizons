import React, { useState, useEffect, useMemo, Suspense, lazy } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Zap, Trophy, ArrowRight, Target } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';
import LoadingScreen from '@/components/common/LoadingScreen';
import BoostedDaySetter from '@/components/workout/BoostedDaySetter';
import { getBoostedDay, getActiveRoutine, getBoostChallengeStatus } from '@/lib/database';

// Lazy load components
const BoostChallengeModal = lazy(() => import('@/components/challenge/BoostChallengeModal'));
const WeekView = lazy(() => import('@/components/workout/WeekView'));
const MonthView = lazy(() => import('@/components/workout/MonthView'));
const YearView = lazy(() => import('@/components/workout/YearView'));

const BoostWorkoutProgram = ({ userId }) => {
    const navigate = useNavigate();
    const [view, setView] = useState('week');
    const [currentDate, setCurrentDate] = useState(new Date());
    const [showChallengeModal, setShowChallengeModal] = useState(false);
    
    // Use state instead of useMemo to allow re-fetching without unmounting
    const [challengeStatus, setChallengeStatus] = useState(null);

    // Initial fetch and listener for updates
    useEffect(() => {
        if (!userId) return;
        
        const fetchStatus = () => {
            setChallengeStatus(getBoostChallengeStatus(userId));
        };

        fetchStatus();

        // Listen for the custom event dispatched by the modal
        window.addEventListener('boost_challenge_updated', fetchStatus);
        
        return () => {
            window.removeEventListener('boost_challenge_updated', fetchStatus);
        };
    }, [userId]);

    const activeRoutine = useMemo(() => {
        if (!userId) return null;
        return getActiveRoutine(userId);
    }, [userId]);

    const effectiveLevel = challengeStatus?.isActive ? 'advanced' : activeRoutine;

    const boostedDayInfo = useMemo(() => {
        if (!userId) return null;
        return getBoostedDay(userId);
    }, [userId]);
    const boostedDay = boostedDayInfo ? new Date(boostedDayInfo.date).toISOString().split('T')[0] : null;

    const schedule = useMemo(() => {
        if (!effectiveLevel) return Array(7).fill('rest');
        const programs = {
            beginner:     ['workout', 'workout', 'workout', 'cardio', 'workout', 'workout', 'rest'],
            intermediate: ['workout', 'workout', 'workout', 'workout', 'workout', 'cardio', 'rest'],
            advanced:     ['workout', 'workout', 'workout', 'rest', 'workout', 'workout', 'workout'],
        };
        return programs[effectiveLevel] || programs['beginner'];
    }, [effectiveLevel]);

    const handleDayClick = (date) => {
        const levelForPath = effectiveLevel;
        if (levelForPath) {
            navigate(`/session-prep/${date.toISOString().split('T')[0]}/${levelForPath}`);
        } else {
             toast({
                title: "Plan no detectado",
                description: "No se ha podido determinar un plan de entrenamiento activo.",
                variant: "default",
            });
        }
    };
    
    const handleMonthClick = (monthIndex) => {
        setCurrentDate(new Date(currentDate.getFullYear(), monthIndex, 1));
        setView('month');
    };

    const ChallengeBanner = () => (
        <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setShowChallengeModal(true)}
            className="relative w-full h-48 md:h-56 rounded-2xl overflow-hidden cursor-pointer group shadow-[0_0_20px_rgba(255,214,0,0.15)] border border-[var(--neon-yellow)]/30"
        >
            <img 
                src="https://sergiconstance-9fn0dyoiqm.live-website.com/wp-content/uploads/2025/12/ShottingAtlas-137-1-scaled.jpg" 
                alt="Boost Challenge"
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black via-black/70 to-transparent" />
            
            <div className="absolute inset-0 p-6 flex flex-col justify-center items-start">
                <div className="bg-[var(--neon-yellow)] text-black text-[10px] font-black px-2 py-0.5 rounded mb-3 flex items-center gap-1 uppercase tracking-widest shadow-[0_0_10px_rgba(255,214,0,0.4)]">
                    <Trophy className="w-3 h-3" /> Programa Oficial
                </div>
                <h3 className="text-3xl font-black text-white italic uppercase leading-none mb-1 drop-shadow-lg">
                    BOOST CHALLENGE
                </h3>
                <p className="text-gray-300 text-sm font-medium mb-4 max-w-md drop-shadow-md">
                    El sistema definitivo de 12 semanas para transformar tu físico y mentalidad.
                </p>
                <Button className="btn-primary h-9 text-xs font-bold uppercase tracking-wider">
                    Unirse al Reto <ArrowRight className="w-3 h-3 ml-1" />
                </Button>
            </div>
        </motion.div>
    );

    return (
        <div className="space-y-8 mb-8">
            {/* Show Challenge Banner if NOT active */}
            {challengeStatus && !challengeStatus.isActive && <ChallengeBanner />}

            {/* Calendar Section - Only show if we have a routine/challenge active */}
            {(effectiveLevel) ? (
                <div className="glass-effect p-6 rounded-2xl border border-white/5">
                     <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
                        <div>
                             <h3 className="text-xl font-bold flex items-center gap-2 text-primary">
                                 <Zap className="w-5 h-5 fill-current" /> Calendario Inteligente
                             </h3>
                             <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider">
                                 {challengeStatus?.isActive ? 'MODO: RETO BOOST (Activo)' : `PLAN: ${effectiveLevel.toUpperCase()}`}
                             </p>
                        </div>
                        <div className="flex bg-secondary rounded-lg p-1">
                            <Button variant={view === 'week' ? 'default' : 'ghost'} size="sm" onClick={() => setView('week')} className="h-8 text-xs">Semana</Button>
                            <Button variant={view === 'month' ? 'default' : 'ghost'} size="sm" onClick={() => setView('month')} className="h-8 text-xs">Mes</Button>
                            <Button variant={view === 'year' ? 'default' : 'ghost'} size="sm" onClick={() => setView('year')} className="h-8 text-xs">Año</Button>
                        </div>
                    </div>
    
                    <AnimatePresence mode="wait">
                        <motion.div
                            key={view}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            transition={{ duration: 0.3 }}
                        >
                            <Suspense fallback={<LoadingScreen />}>
                                {view === 'week' && <WeekView currentDate={currentDate} schedule={schedule} onDayClick={handleDayClick} boostedDay={boostedDay} />}
                                {view === 'month' && <MonthView currentDate={currentDate} schedule={schedule} onDayClick={handleDayClick} boostedDay={boostedDay} />}
                                {view === 'year' && <YearView currentDate={currentDate} onMonthClick={handleMonthClick} setCurrentDate={setCurrentDate} />}
                            </Suspense>
                        </motion.div>
                    </AnimatePresence>
                </div>
            ) : (
                // If no plan is active and we just showed the banner, add some helper text below
                challengeStatus && !challengeStatus.isActive && (
                    <div className="text-center p-8 border border-dashed border-white/10 rounded-2xl bg-white/5">
                        <Target className="w-10 h-10 text-muted-foreground mx-auto mb-2" />
                        <h4 className="text-lg font-bold text-muted-foreground">Sin Plan Activo</h4>
                        <p className="text-xs text-muted-foreground/60">Selecciona el Boost Challenge arriba para comenzar tu transformación.</p>
                    </div>
                )
            )}
            
            <BoostedDaySetter userId={userId} />

            <Suspense fallback={null}>
                {showChallengeModal && <BoostChallengeModal onClose={() => setShowChallengeModal(false)} />}
            </Suspense>
        </div>
    );
};

export default BoostWorkoutProgram;