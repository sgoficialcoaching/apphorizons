import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    Dumbbell, Grip, Target, Layers, 
    AlertCircle, Timer, Info, CheckCircle2, ChevronDown 
} from 'lucide-react';
import { cn } from '@/lib/utils';

const ExerciseInfoCard = ({ exercise, isOpen, onToggle }) => {
    if (!exercise) return null;

    // Helper to get muscle image based on muscle group
    const getMuscleImage = (group) => {
        const altText = `Anatomía muscular ${group || 'general'}, músculos activados resaltados en rojo`;
        switch(group?.toLowerCase()) {
            case 'pecho':
                return <img className="w-full h-full object-cover opacity-80 mix-blend-luminosity" alt={altText} src="https://images.unsplash.com/photo-1685506489242-1821b7a83711" />;
            case 'espalda':
                return <img className="w-full h-full object-cover opacity-80 mix-blend-luminosity" alt={altText} src="https://images.unsplash.com/photo-1697698233268-6c92154ab228" />;
            case 'piernas':
                return <img className="w-full h-full object-cover opacity-80 mix-blend-luminosity" alt={altText} src="https://images.unsplash.com/photo-1508387150737-7ce104ed3b0a" />;
            case 'hombros':
                return <img className="w-full h-full object-cover opacity-80 mix-blend-luminosity" alt={altText} src="https://images.unsplash.com/photo-1605553703718-e24d6004a0dc" />;
            case 'brazos':
                 return <img className="w-full h-full object-cover opacity-80 mix-blend-luminosity" alt={altText} src="https://images.unsplash.com/photo-1603928726698-a015a1015d0e" />;
            default:
                 return <img className="w-full h-full object-cover opacity-80 mix-blend-luminosity" alt={altText} src="https://images.unsplash.com/photo-1501885061301-593ddd21e205" />;
        }
    };

    // Helper for equipment icon
    const getEquipmentIcon = (eq) => {
        const text = eq?.toLowerCase() || '';
        if (text.includes('barra')) return <Dumbbell className="w-4 h-4" />; // Using Dumbbell as proxy for barbell
        if (text.includes('mancuerna')) return <Dumbbell className="w-4 h-4" />;
        if (text.includes('polea') || text.includes('máquina')) return <Layers className="w-4 h-4" />;
        return <Target className="w-4 h-4" />;
    };

    return (
        <div className="border-t border-white/5 bg-black/40">
            <button 
                onClick={onToggle}
                className={cn(
                    "w-full flex items-center justify-between p-3 text-xs font-bold uppercase tracking-widest transition-all duration-300",
                    isOpen ? "text-[var(--neon-blue)] bg-[var(--neon-blue)]/5" : "text-muted-foreground hover:text-white"
                )}
            >
                <span className="flex items-center gap-2">
                    <Info className="w-4 h-4" />
                    Información Técnica
                </span>
                <ChevronDown className={cn("w-4 h-4 transition-transform duration-300", isOpen && "rotate-180")} />
            </button>

            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                    >
                        <div className="p-4 space-y-6 text-sm">
                            
                            {/* Visual & Quick Stats */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {/* Anatomy Visual */}
                                <div className="relative aspect-video rounded-xl overflow-hidden bg-black border border-white/10 shadow-lg">
                                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent z-10" />
                                    {getMuscleImage(exercise.muscleGroup)}
                                    <div className="absolute bottom-2 left-3 z-20">
                                        <p className="text-[10px] uppercase font-black tracking-wider text-muted-foreground">Zona Objetivo</p>
                                        <p className="text-white font-bold capitalize">{exercise.muscleGroup}</p>
                                    </div>
                                </div>

                                {/* Core Stats */}
                                <div className="space-y-3">
                                    <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                                        <p className="text-[10px] text-muted-foreground uppercase mb-1 flex items-center gap-1">
                                            {getEquipmentIcon(exercise.equipment)} Equipamiento
                                        </p>
                                        <p className="text-white font-medium">{exercise.equipment || 'General'}</p>
                                    </div>
                                    <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                                        <p className="text-[10px] text-muted-foreground uppercase mb-1 flex items-center gap-1">
                                            <Grip className="w-3 h-3" /> Agarre Recomendado
                                        </p>
                                        <p className="text-white font-medium">{exercise.grip || 'Neutro / Estándar'}</p>
                                    </div>
                                    <div className="flex gap-2">
                                        <div className="bg-white/5 p-2 rounded-lg border border-white/5 flex-1 text-center">
                                            <p className="text-[10px] text-muted-foreground uppercase mb-0.5">Reps</p>
                                            <p className="text-[var(--neon-blue)] font-bold">{exercise.recommended_reps || '8-12'}</p>
                                        </div>
                                        <div className="bg-white/5 p-2 rounded-lg border border-white/5 flex-1 text-center">
                                            <p className="text-[10px] text-muted-foreground uppercase mb-0.5">Tempo</p>
                                            <p className="text-[var(--neon-blue)] font-bold">{exercise.tempo || '2-0-2'}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Description */}
                            {exercise.description && (
                                <p className="text-muted-foreground leading-relaxed italic border-l-2 border-[var(--neon-blue)] pl-3">
                                    "{exercise.description}"
                                </p>
                            )}

                            {/* Execution Steps */}
                            {exercise.instructions && exercise.instructions.length > 0 && (
                                <div>
                                    <h4 className="font-bold text-white mb-3 flex items-center gap-2">
                                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                                        Ejecución Técnica
                                    </h4>
                                    <ol className="relative border-l border-white/10 ml-2 space-y-4">
                                        {exercise.instructions.map((step, idx) => (
                                            <li key={idx} className="pl-4 relative">
                                                <div className="absolute -left-[5px] top-1.5 w-2.5 h-2.5 rounded-full bg-[var(--neon-blue)]" />
                                                <p className="text-muted-foreground text-sm leading-snug">{step}</p>
                                            </li>
                                        ))}
                                    </ol>
                                </div>
                            )}

                            {/* Common Errors */}
                            {exercise.common_errors && exercise.common_errors.length > 0 && (
                                <div className="bg-red-900/10 border border-red-500/20 rounded-xl p-4">
                                    <h4 className="font-bold text-red-400 mb-2 flex items-center gap-2 text-xs uppercase tracking-wider">
                                        <AlertCircle className="w-4 h-4" />
                                        Errores Comunes
                                    </h4>
                                    <ul className="space-y-2">
                                        {exercise.common_errors.map((error, idx) => (
                                            <li key={idx} className="flex items-start gap-2 text-red-200/80 text-xs">
                                                <span className="text-red-500 font-bold">•</span>
                                                {error}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            )}

                            {/* Muscles List */}
                            {exercise.muscles_worked && (
                                <div>
                                    <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-2">Activación Muscular</p>
                                    <div className="flex flex-wrap gap-2">
                                        {exercise.muscles_worked.map((m, i) => (
                                            <span key={i} className="text-[10px] bg-white/5 border border-white/10 px-2 py-1 rounded-md text-gray-300">
                                                {m}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                            )}

                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default ExerciseInfoCard;