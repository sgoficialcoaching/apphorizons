import React from 'react';
import { motion } from 'framer-motion';
import { Dumbbell, Heart, Coffee, Rocket } from 'lucide-react';

const MonthView = ({ currentDate, schedule, onDayClick, boostedDay }) => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);

    const startDay = firstDayOfMonth.getDay() === 0 ? 6 : firstDayOfMonth.getDay() - 1;
    const daysInMonth = lastDayOfMonth.getDate();

    const days = Array.from({ length: startDay }, () => null).concat(
        Array.from({ length: daysInMonth }, (_, i) => new Date(year, month, i + 1))
    );
    
    const weekdays = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

    const getDayInfo = (date) => {
        if (!date || !schedule) return { type: 'Rest', activityName: 'Descanso', icon: <Coffee className="w-4 h-4" /> };
        const dayOfWeek = date.getDay() === 0 ? 6 : date.getDay() - 1;
        const activity = schedule[dayOfWeek % 7] || 'Rest';
        if (activity.toLowerCase().includes('cardio')) {
            return { type: 'Cardio', activityName: activity, icon: <Heart className="w-4 h-4" /> };
        } else if (activity.toLowerCase().includes('rest')) {
            return { type: 'Rest', activityName: 'Descanso', icon: <Coffee className="w-4 h-4" /> };
        } else {
            return { type: 'Workout', activityName: activity, icon: <Dumbbell className="w-4 h-4" /> };
        }
    };
    
    return (
        <div>
            <div className="grid grid-cols-7 gap-1 text-center text-xs font-bold text-muted-foreground mb-2">
                {weekdays.map(day => <div key={day}>{day}</div>)}
            </div>
            <div className="grid grid-cols-7 gap-1">
                {days.map((day, index) => {
                    if (!day) return <div key={`empty-${index}`} className="h-20 rounded-md bg-background/50"></div>;
                    
                    const dayInfo = getDayInfo(day);
                    const isToday = day.toDateString() === new Date().toDateString();
                    const isBoosted = boostedDay === day.toISOString().split('T')[0];

                    return (
                        <motion.div
                            key={day.toISOString()}
                            onClick={() => dayInfo.type !== 'Rest' && onDayClick(day)}
                            className={`relative h-20 p-1.5 rounded-md cursor-pointer flex flex-col justify-between transition-colors
                                ${isToday ? 'bg-primary text-primary-foreground' : 'bg-secondary hover:bg-primary/10'}
                                ${dayInfo.type === 'Rest' ? 'opacity-60 cursor-not-allowed' : ''}
                                ${isBoosted ? 'ring-2 ring-fuchsia-500' : ''}
                            `}
                            whileHover={{ y: dayInfo.type !== 'Rest' ? -2 : 0 }}
                        >
                            {isBoosted && <Rocket className="absolute top-1 right-1 w-3 h-3 text-fuchsia-500" />}
                            <span className={`font-bold text-sm ${isToday ? 'text-black' : ''}`}>{day.getDate()}</span>
                            <div className={`flex items-center gap-1 text-xs ${isToday ? 'text-black' : 'text-muted-foreground'}`}>
                                {dayInfo.icon}
                                <span className="hidden sm:inline truncate">{dayInfo.activityName}</span>
                            </div>
                        </motion.div>
                    );
                })}
            </div>
        </div>
    );
};

export default MonthView;