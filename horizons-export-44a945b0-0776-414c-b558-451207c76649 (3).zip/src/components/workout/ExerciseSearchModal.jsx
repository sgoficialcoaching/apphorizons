import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Search, X } from 'lucide-react';
import { getExerciseById } from '@/lib/database';

const ExerciseSearchModal = ({ onClose, onSelectExercise }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const allExercises = useMemo(() => JSON.parse(localStorage.getItem('exercises') || '[]'), []);
    
    const filteredExercises = useMemo(() => {
        if (!searchTerm) return allExercises.slice(0, 50); // Limit initial display
        return allExercises.filter(ex => 
            ex.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
            ex.muscleGroup.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [searchTerm, allExercises]);

    return (
        <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
            onClick={onClose}
        >
            <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                className="glass-effect rounded-2xl w-full max-w-lg h-[80vh] flex flex-col p-6"
                onClick={e => e.stopPropagation()}
            >
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-bold">Buscar Ejercicio</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-secondary"><X/></button>
                </div>
                
                <div className="relative mb-4">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground"/>
                    <input 
                        type="text"
                        placeholder="Escribe para buscar..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        className="w-full pl-10 pr-4 py-2 bg-input rounded-lg border-border"
                        autoFocus
                    />
                </div>

                <div className="flex-1 overflow-y-auto pr-2">
                    <div className="space-y-2">
                        {filteredExercises.map(ex => (
                            <div 
                                key={ex.id}
                                onClick={() => onSelectExercise(ex.id)}
                                className="p-3 rounded-lg hover:bg-secondary cursor-pointer flex justify-between items-center"
                            >
                                <div>
                                    <p className="font-semibold">{ex.name}</p>
                                    <p className="text-sm text-muted-foreground capitalize">{ex.muscleGroup}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </motion.div>
        </motion.div>
    );
};

export default ExerciseSearchModal;