import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { getWorkoutPreferences, saveWorkoutPreferences, getExercises } from '@/lib/database';
import { useAuth } from '@/hooks/useAuth';
import { toast } from '@/components/ui/use-toast';
import { Bike, Sparkles, Expand as Stretch, Save } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const PreferenceSelector = ({ title, icon, options, selected, onSelect }) => (
    <div className="glass-effect p-6 rounded-lg">
        <div className="flex items-center gap-3 mb-4">
            {icon}
            <h3 className="text-xl font-bold">{title}</h3>
        </div>
        <div className="space-y-2">
            {options.map(option => (
                <button
                    key={option.id}
                    onClick={() => onSelect(option)}
                    className={`w-full text-left p-3 rounded-lg transition-colors ${selected.id === option.id ? 'bg-primary text-primary-foreground' : 'hover:bg-secondary'}`}
                >
                    {option.name}
                </button>
            ))}
        </div>
    </div>
);

const WorkoutPreferences = ({ onSave }) => {
    const { user } = useAuth();
    const [preferences, setPreferences] = useState(null);
    const [exerciseOptions, setExerciseOptions] = useState({ cardio: [], mobility: [], stretching: [] });
    const [isSaving, setIsSaving] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        if (user) {
            const prefs = getWorkoutPreferences(user.id);
            setPreferences(prefs);

            const allExercises = getExercises();
            // Simple categorization for mock purposes
            setExerciseOptions({
                cardio: [{id: 'cardio_bike', name: 'Bici Estática'}, {id: 'cardio_run', name: 'Correr en Cinta'}, {id: 'cardio_elliptical', name: 'Elíptica'}],
                mobility: [{id: 'mob_1', name: 'Círculos de Cadera'}, {id: 'mob_2', name: 'Rotaciones de Torso'}, {id: 'mob_3', name: 'Gato-Vaca'}],
                stretching: [{id: 'stretch_1', name: 'Estiramiento de Isquios'}, {id: 'stretch_2', name: 'Estiramiento de Cuádriceps'}, {id: 'stretch_3', name: 'Estiramiento de Pecho'}],
            });
        }
    }, [user]);

    const handleSelect = (type, value) => {
        setPreferences(prev => ({
            ...prev,
            [type]: value
        }));
    };

    const handleSave = () => {
        if (!user) return;
        setIsSaving(true);
        saveWorkoutPreferences(user.id, preferences);
        toast({
            title: 'Preferencias Guardadas',
            description: 'Tus elecciones para la preparación de entreno han sido actualizadas.',
        });
        setIsSaving(false);
        if(onSave) onSave();
    };

    if (!preferences) {
        return <div>Cargando preferencias...</div>;
    }

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
        >
            <div className="text-center">
                <h2 className="text-2xl font-bold">Preferencias de Preparación</h2>
                <p className="text-muted-foreground">Elige tus ejercicios favoritos para calentar. Aparecerán por defecto en tus sesiones.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <PreferenceSelector
                    title="Cardio"
                    icon={<Bike className="w-6 h-6 text-primary" />}
                    options={exerciseOptions.cardio}
                    selected={preferences.cardio}
                    onSelect={(val) => handleSelect('cardio', val)}
                />
                <PreferenceSelector
                    title="Movilidad"
                    icon={<Sparkles className="w-6 h-6 text-primary" />}
                    options={exerciseOptions.mobility}
                    selected={preferences.mobility}
                    onSelect={(val) => handleSelect('mobility', val)}
                />
                <PreferenceSelector
                    title="Estiramiento"
                    icon={<Stretch className="w-6 h-6 text-primary" />}
                    options={exerciseOptions.stretching}
                    selected={preferences.stretching}
                    onSelect={(val) => handleSelect('stretching', val)}
                />
            </div>

            <div className="flex justify-center">
                <Button onClick={handleSave} disabled={isSaving} size="lg" className="btn-primary">
                    <Save className="w-5 h-5 mr-2" />
                    {isSaving ? 'Guardando...' : 'Guardar Preferencias'}
                </Button>
            </div>
        </motion.div>
    );
};

export default WorkoutPreferences;