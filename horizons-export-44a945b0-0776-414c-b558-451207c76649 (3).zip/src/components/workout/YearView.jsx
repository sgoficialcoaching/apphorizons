import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const YearView = ({ currentDate, onMonthClick, setCurrentDate }) => {
    const year = currentDate.getFullYear();
    const months = Array.from({ length: 12 }).map((_, i) => 
        new Date(year, i).toLocaleString('es-ES', { month: 'long' })
    );
    const today = new Date();
    const currentMonth = today.getFullYear() === year ? today.getMonth() : -1;

    return (
        <div className="bg-card p-4 rounded-lg">
            <div className="flex justify-between items-center mb-4">
                 <Button variant="ghost" size="icon" onClick={() => setCurrentDate(new Date(year - 1, 0, 1))}>
                    <ChevronLeft className="w-4 h-4" />
                </Button>
                <h3 className="text-xl font-bold text-center">{year}</h3>
                <Button variant="ghost" size="icon" onClick={() => setCurrentDate(new Date(year + 1, 0, 1))}>
                    <ChevronRight className="w-4 h-4" />
                </Button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {months.map((month, index) => (
                    <motion.div
                        key={month}
                        onClick={() => onMonthClick(index)}
                        className={`p-4 text-center rounded-lg cursor-pointer font-semibold transition-colors ${index === currentMonth ? 'bg-primary text-primary-foreground' : 'bg-secondary hover:bg-secondary/80'}`}
                        whileHover={{ scale: 1.05 }}
                    >
                        <span className="capitalize">{month}</span>
                    </motion.div>
                ))}
            </div>
        </div>
    );
};

export default YearView;